/**
 * WCUP Account — Frontend JavaScript
 * ============================================================
 *  شامل:
 *    - Tab System
 *    - Password Toggles
 *    - Avatar (Upload + Delete)
 *    - Notices (Dismiss)
 *    - Download Toggles
 *    - Password Strength
 *    - Notifications
 *    - Wishlist (Toggle + Count + Toast)
 *    - Toast System (حرفه‌ای)
 *
 *  @version 3.0.0
 */

(function () {
    'use strict';

    /* ============================================================
     *  TOAST SYSTEM — پاپ‌آپ حرفه‌ای
     * ============================================================ */
    var Toast = (function () {

        var icons = {
            success: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
            error:   '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
            info:    '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
            warning: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>',
        };

        function getContainer() {
            var c = document.getElementById('wcup-toast-container');
            if (!c) {
                c = document.createElement('div');
                c.id = 'wcup-toast-container';
                c.className = 'wcup-toast-container';
                document.body.appendChild(c);
            }
            return c;
        }

        function escapeHtml(text) {
            var div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function dismiss(toast) {
            if (!toast || toast.classList.contains('is-hiding')) return;
            toast.classList.add('is-hiding');

            setTimeout(function () {
                if (toast.parentNode) toast.parentNode.removeChild(toast);
            }, 350);
        }

        function show(message, type, duration) {
            if (!message) return;

            type     = type || 'info';
            duration = duration || 3000;

            var container = getContainer();
            var toast = document.createElement('div');
            toast.className = 'wcup-toast-notification wcup-toast-notification--' + type;

            toast.innerHTML =
                '<span class="wcup-toast-icon">' + (icons[type] || icons.info) + '</span>' +
                '<span class="wcup-toast-text">' + escapeHtml(message) + '</span>' +
                '<button type="button" class="wcup-toast-close" aria-label="بستن">' +
                    '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
                        '<line x1="18" y1="6" x2="6" y2="18"></line>' +
                        '<line x1="6" y1="6" x2="18" y2="18"></line>' +
                    '</svg>' +
                '</button>' +
                '<div class="wcup-toast-progress" style="animation-duration:' + duration + 'ms;"></div>';

            container.appendChild(toast);

            /* انیمیشن ورود */
            requestAnimationFrame(function () {
                toast.classList.add('is-visible');
            });

            /* دکمهٔ بستن */
            var closeBtn = toast.querySelector('.wcup-toast-close');
            if (closeBtn) {
                closeBtn.addEventListener('click', function () {
                    dismiss(toast);
                });
            }

            /* تایمر */
            var timer = setTimeout(function () {
                dismiss(toast);
            }, duration);

            /* Hover → مکث */
            toast.addEventListener('mouseenter', function () {
                clearTimeout(timer);
                var p = toast.querySelector('.wcup-toast-progress');
                if (p) p.style.animationPlayState = 'paused';
            });

            toast.addEventListener('mouseleave', function () {
                var p = toast.querySelector('.wcup-toast-progress');
                if (p) p.style.animationPlayState = 'running';
                timer = setTimeout(function () {
                    dismiss(toast);
                }, 1500);
            });

            return toast;
        }

        return {
            show: show,
            success: function (msg, dur) { return show(msg, 'success', dur); },
            error:   function (msg, dur) { return show(msg, 'error', dur); },
            info:    function (msg, dur) { return show(msg, 'info', dur); },
            warning: function (msg, dur) { return show(msg, 'warning', dur); },
        };
    })();

    /* در دسترس قرار دادن سراسری */
    window.wcupToast = Toast;


    /* ============================================================
     *  اعداد فارسی
     * ============================================================ */
    function toFaNum(num) {
        var en = ['0','1','2','3','4','5','6','7','8','9'];
        var fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
        return String(num).split('').map(function (d) {
            return en.indexOf(d) > -1 ? fa[en.indexOf(d)] : d;
        }).join('');
    }


    /* ============================================================
     *  ۱) تب‌ها
     * ============================================================ */
    function initTabs() {
        document.querySelectorAll('[data-tabs-group]').forEach(function (group) {
            var tabs   = group.querySelectorAll('[data-tab]');
            var panels = group.querySelectorAll('[data-panel]');

            tabs.forEach(function (tab) {
                tab.addEventListener('click', function () {
                    var target = tab.getAttribute('data-tab');

                    tabs.forEach(function (t) { t.classList.remove('is-active'); });
                    panels.forEach(function (p) { p.classList.remove('is-active'); });

                    tab.classList.add('is-active');
                    var panel = group.querySelector('[data-panel="' + target + '"]');
                    if (panel) panel.classList.add('is-active');
                });
            });
        });
    }


    /* ============================================================
     *  ۲) نمایش/مخفی رمز عبور
     * ============================================================ */
    function initPasswordToggles() {
        document.querySelectorAll('[data-toggle-pass]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var target = btn.getAttribute('data-toggle-pass');
                var input  = document.getElementById(target);
                if (!input) return;

                var isPass = input.type === 'password';
                input.type = isPass ? 'text' : 'password';
                btn.classList.toggle('is-visible', isPass);
            });
        });
    }


    /* ============================================================
     *  ۳) آواتار (آپلود + حذف)
     * ============================================================ */
    function initAvatar() {
        var input      = document.getElementById('wcup-avatar-input');
        var preview    = document.getElementById('wcup-ea-avatar-preview');
        var previewDiv = document.querySelector('.wcup-ea-avatar-preview');
        var removeBtn  = document.getElementById('wcup-ea-avatar-remove');

        /* کلیک روی پیش‌نمایش → فایل پیکر */
        if (previewDiv && input) {
            previewDiv.style.cursor = 'pointer';
            previewDiv.addEventListener('click', function () {
                input.click();
            });
        }

        /* پیش‌نمایش */
        if (input && preview) {
            input.addEventListener('change', function () {
                var file = input.files && input.files[0];
                if (!file) return;

                if (!file.type.match(/^image\//)) {
                    Toast.error('فقط فایل تصویری مجاز است.');
                    input.value = '';
                    return;
                }

                if (file.size > 2 * 1024 * 1024) {
                    Toast.error('حجم تصویر نباید بیشتر از ۲ مگابایت باشد.');
                    input.value = '';
                    return;
                }

                var reader = new FileReader();
                reader.onload = function (e) {
                    preview.src = e.target.result;
                };
                reader.readAsDataURL(file);
            });
        }

        /* حذف با AJAX */
        if (removeBtn && preview) {
            removeBtn.addEventListener('click', function () {
                if (!confirm('از حذف عکس پروفایل مطمئنی؟')) return;

                var data = window.wcupAvatarData;
                if (!data || !data.ajaxUrl) return;

                removeBtn.disabled = true;
                removeBtn.classList.add('is-loading');

                var xhr = new XMLHttpRequest();
                xhr.open('POST', data.ajaxUrl, true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');

                xhr.onload = function () {
                    removeBtn.disabled = false;
                    removeBtn.classList.remove('is-loading');

                    try {
                        var res = JSON.parse(xhr.responseText);
                        if (!res || !res.success) {
                            Toast.error((res && res.data && res.data.message) || 'حذف انجام نشد.');
                            return;
                        }
                        if (res.data.default_url) preview.src = res.data.default_url;
                        removeBtn.style.display = 'none';

                        Toast.success('عکس پروفایل حذف شد.');
                    } catch (e) {
                        Toast.error('پاسخ نامعتبر از سرور.');
                    }
                };

                xhr.onerror = function () {
                    removeBtn.disabled = false;
                    removeBtn.classList.remove('is-loading');
                    Toast.error('خطای شبکه.');
                };

                xhr.send('action=wcup_delete_avatar&nonce=' + encodeURIComponent(data.nonce));
            });
        }
    }


    /* ============================================================
     *  ۴) بستن اطلاعیه‌ها
     * ============================================================ */
    function initNotices() {
        document.querySelectorAll('.wcup-notice-close').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var noticeId = btn.getAttribute('data-notice-id');
                var notice   = btn.closest('.wcup-notice');
                var data     = window.wcupNoticeData;

                if (!data || !notice) return;

                btn.disabled = true;

                var xhr = new XMLHttpRequest();
                xhr.open('POST', data.ajaxUrl, true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');

                xhr.onload = function () {
                    try {
                        var res = JSON.parse(xhr.responseText);
                        if (res && res.success) {
                            notice.style.transition = 'opacity .25s, transform .25s, max-height .3s';
                            notice.style.opacity = '0';
                            notice.style.transform = 'translateY(-8px)';
                            notice.style.maxHeight = '0';
                            notice.style.overflow = 'hidden';
                            setTimeout(function () {
                                if (notice.parentNode) notice.parentNode.removeChild(notice);
                            }, 300);
                        } else {
                            btn.disabled = false;
                        }
                    } catch (e) {
                        btn.disabled = false;
                    }
                };

                xhr.send('action=wcup_dismiss_notice&notice_id=' + encodeURIComponent(noticeId) + '&nonce=' + encodeURIComponent(data.nonce));
            });
        });
    }


    /* ============================================================
     *  ۵) تاگل پنل دانلود
     * ============================================================ */
    function initDownloadToggles() {
        document.querySelectorAll('.wcup-vo-downloads-toggle').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var panelId = btn.getAttribute('aria-controls');
                var panel   = document.getElementById(panelId);
                if (!panel) return;

                var isOpen = !panel.hidden;
                panel.hidden = isOpen;
                btn.setAttribute('aria-expanded', isOpen ? 'false' : 'true');
                btn.classList.toggle('is-open', !isOpen);
            });
        });
    }


    /* ============================================================
     *  ۶) نشانگر قدرت رمز
     * ============================================================ */
    function initPasswordStrength() {
        var input = document.getElementById('password_1');
        var meter = document.getElementById('wcup-rp-strength');
        var label = document.getElementById('wcup-rp-strength-label');

        if (!input || !meter) return;

        var bars   = meter.querySelectorAll('.wcup-rp-strength-bar');
        var labels = ['خیلی ضعیف', 'ضعیف', 'متوسط', 'قوی', 'خیلی قوی'];
        var colors = ['#F34747', '#F34747', '#FBE83F', '#008869', '#008869'];

        function scorePassword(pass) {
            var score = 0;
            if (!pass) return 0;
            if (pass.length >= 8)  score++;
            if (pass.length >= 12) score++;
            if (/[a-z]/.test(pass) && /[A-Z]/.test(pass)) score++;
            if (/\d/.test(pass)) score++;
            if (/[^A-Za-z0-9]/.test(pass)) score++;
            return Math.min(score, 5);
        }

        input.addEventListener('input', function () {
            var val   = input.value;
            var score = val ? Math.max(1, scorePassword(val)) : 0;

            meter.setAttribute('data-score', score);
            bars.forEach(function (bar, i) {
                bar.style.background = (i < score) ? colors[score - 1] : '#eef1f4';
            });

            if (label) {
                label.textContent = val ? labels[score - 1] : 'قدرت رمز عبور';
                label.style.color = val ? colors[score - 1] : '';
            }
        });
    }


    /* ============================================================
     *  ۷) NOTIFICATIONS
     * ============================================================ */
    function initNotifications() {

        if (!window.wcupNotificationsData) return;

        var data = window.wcupNotificationsData;

        function ajax(action, params, callback) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', data.ajaxUrl, true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');

            xhr.onload = function () {
                if (xhr.status !== 200) return;
                try {
                    var res = JSON.parse(xhr.responseText);
                    if (callback) callback(res);
                } catch (e) {}
            };

            var body = 'action=' + action + '&nonce=' + encodeURIComponent(data.nonce);
            if (params) {
                Object.keys(params).forEach(function (k) {
                    body += '&' + k + '=' + encodeURIComponent(params[k]);
                });
            }

            xhr.send(body);
        }

        function updateNotifBadge(count) {
            var link = document.querySelector('.wcup-nav-item[href*="/notifications"]');
            if (!link) return;

            var badge = link.querySelector('.wcup-nav-badge');

            if (count <= 0) {
                if (badge) badge.remove();
                return;
            }

            if (!badge) {
                badge = document.createElement('span');
                badge.className = 'wcup-nav-badge';
                link.appendChild(badge);
            }

            badge.textContent = toFaNum(count);
        }

        /* حذف تکی */
        document.addEventListener('click', function (e) {
            var btn = e.target.closest('.wcup-nf-item-delete');
            if (!btn) return;

            e.preventDefault();

            var id = btn.getAttribute('data-id');
            if (!id || !confirm('این اعلان حذف بشه؟')) return;

            btn.disabled = true;

            ajax('wcup_delete_notification', { id: id }, function (res) {
                btn.disabled = false;

                if (res && res.success) {
                    var item = btn.closest('.wcup-nf-item');
                    if (item) {
                        item.style.transition = 'opacity .25s, transform .25s, max-height .3s';
                        item.style.opacity = '0';
                        item.style.transform = 'translateX(-20px)';
                        item.style.maxHeight = '0';
                        item.style.overflow = 'hidden';
                        setTimeout(function () {
                            if (item.parentNode) item.parentNode.removeChild(item);
                        }, 300);
                    }
                    updateNotifBadge(res.data.unread_count);
                    Toast.info('اعلان حذف شد.');
                }
            });
        });

        /* همه رو خوانده کن */
        var markAllBtn = document.getElementById('wcup-nf-mark-all');
        if (markAllBtn) {
            markAllBtn.addEventListener('click', function () {
                markAllBtn.disabled = true;

                ajax('wcup_mark_all_read', {}, function (res) {
                    markAllBtn.disabled = false;

                    if (res && res.success) {
                        document.querySelectorAll('.wcup-nf-item.is-unread').forEach(function (item) {
                            item.classList.remove('is-unread');
                            var dot = item.querySelector('.wcup-nf-item-dot');
                            if (dot) dot.remove();
                        });

                        updateNotifBadge(0);
                        markAllBtn.style.display = 'none';
                        Toast.success('همهٔ اعلان‌ها خوانده شدند.');
                    }
                });
            });
        }

        /* حذف همه */
        var deleteAllBtn = document.getElementById('wcup-nf-delete-all');
        if (deleteAllBtn) {
            deleteAllBtn.addEventListener('click', function () {
                if (!confirm('همهٔ اعلان‌ها حذف بشن؟')) return;

                deleteAllBtn.disabled = true;

                ajax('wcup_delete_all', {}, function (res) {
                    deleteAllBtn.disabled = false;

                    if (res && res.success) {
                        var list = document.getElementById('wcup-nf-list');
                        if (list) {
                            list.style.transition = 'opacity .3s';
                            list.style.opacity = '0';
                            setTimeout(function () {
                                window.location.reload();
                            }, 300);
                        }
                        updateNotifBadge(0);
                    }
                });
            });
        }

        /* کلیک روی اعلان → خوانده بشه */
        document.addEventListener('click', function (e) {
            var item = e.target.closest('.wcup-nf-item.is-unread');
            if (!item) return;
            if (e.target.closest('.wcup-nf-item-delete')) return;

            var id = item.getAttribute('data-id');

            ajax('wcup_mark_read', { id: id }, function (res) {
                if (res && res.success) {
                    item.classList.remove('is-unread');
                    var dot = item.querySelector('.wcup-nf-item-dot');
                    if (dot) dot.remove();
                    updateNotifBadge(res.data.unread_count);
                }
            });
        });
    }


    /* ============================================================
     *  ۸) WISHLIST — Toggle
     * ============================================================ */
    function initWishlistToggle() {

        if (!window.wcupWishlistData) return;

        var data = window.wcupWishlistData;

        function updateWishlistBadge(count) {
            var link = document.querySelector('.wcup-nav-item[href*="/wishlist"]');
            if (!link) return;

            var badge = link.querySelector('.wcup-nav-badge');

            if (count <= 0) {
                if (badge) badge.remove();
                return;
            }

            if (!badge) {
                badge = document.createElement('span');
                badge.className = 'wcup-nav-badge';
                link.appendChild(badge);
            }

            badge.textContent = toFaNum(count);
        }

        /* کلیک روی هر دکمهٔ wishlist */
        document.addEventListener('click', function (e) {

            var btn = e.target.closest('.wcup-wishlist-toggle');
            if (!btn) return;

            e.preventDefault();
            e.stopPropagation();

            /* اگه لاگین نیست */
            if (!data.isLoggedIn) {
                Toast.info('برای افزودن به علاقه‌مندی‌ها باید وارد شوید.', 4000);
                setTimeout(function () {
                    window.location.href = data.loginUrl;
                }, 1200);
                return;
            }

            var productId = btn.getAttribute('data-product-id');
            if (!productId || btn.disabled) return;

            btn.disabled = true;
            btn.classList.add('is-loading');

            var xhr = new XMLHttpRequest();
            xhr.open('POST', data.ajaxUrl, true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');

            xhr.onload = function () {
                btn.disabled = false;
                btn.classList.remove('is-loading');

                if (xhr.status !== 200) {
                    Toast.error('خطای شبکه. دوباره تلاش کن.');
                    return;
                }

                var res;
                try {
                    res = JSON.parse(xhr.responseText);
                } catch (err) {
                    Toast.error('پاسخ نامعتبر از سرور.');
                    return;
                }

                if (!res || !res.success) {
                    if (res && res.data && res.data.code === 'not_logged_in') {
                        Toast.info('برای افزودن باید وارد شوید.', 4000);
                        setTimeout(function () {
                            window.location.href = res.data.login_url || data.loginUrl;
                        }, 1200);
                        return;
                    }
                    Toast.error((res && res.data && res.data.message) || 'خطا در انجام عملیات.');
                    return;
                }

                var inList = res.data.in_wishlist;

                /* آپدیت همهٔ دکمه‌های این محصول */
                var allBtns = document.querySelectorAll('.wcup-wishlist-toggle[data-product-id="' + productId + '"]');
                allBtns.forEach(function (b) {
                    if (inList) {
                        b.classList.add('is-active');
                    } else {
                        b.classList.remove('is-active');
                    }

                    var svg = b.querySelector('svg');
                    if (svg) {
                        svg.setAttribute('fill', inList ? 'currentColor' : 'none');
                    }

                    var textSpan = b.querySelector('.wcup-wishlist-toggle-text');
                    if (textSpan) {
                        textSpan.textContent = inList
                            ? (b.getAttribute('data-text-remove') || 'در علاقه‌مندی‌ها')
                            : (b.getAttribute('data-text-add') || 'افزودن به علاقه‌مندی‌ها');
                    }

                    var ariaText = inList ? 'حذف از علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی‌ها';
                    b.setAttribute('aria-label', ariaText);
                    b.setAttribute('title', ariaText);
                });

                /* آپدیت badge منو */
                updateWishlistBadge(res.data.count);

                /* آپدیت count اگه هست */
                var countEls = document.querySelectorAll('.wcup-wishlist-toggle-count');
                countEls.forEach(function (el) {
                    el.textContent = toFaNum(res.data.count);
                    el.style.display = res.data.count > 0 ? '' : 'none';
                });

                /* اگه توی صفحه wishlist بودیم و حذف شد */
                if (!inList && window.location.pathname.indexOf('/wishlist') !== -1) {
                    var card = btn.closest('.wcup-wl-card');
                    if (card) {
                        card.classList.add('is-removing');
                        setTimeout(function () {
                            card.remove();
                            var remaining = document.querySelectorAll('.wcup-wl-card');
                            if (remaining.length === 0) {
                                window.location.reload();
                            }
                        }, 350);
                    }
                }

                /* ─── پاپ‌آپ ─── */
                if (inList) {
                    Toast.success(res.data.message || 'به علاقه‌مندی‌ها اضافه شد.');
                } else {
                    Toast.info(res.data.message || 'از علاقه‌مندی‌ها حذف شد.');
                }
            };

            xhr.onerror = function () {
                btn.disabled = false;
                btn.classList.remove('is-loading');
                Toast.error('خطای شبکه. اتصال اینترنت رو چک کن.');
            };

            xhr.send(
                'action=wcup_toggle_wishlist' +
                '&product_id=' + encodeURIComponent(productId) +
                '&nonce=' + encodeURIComponent(data.nonce)
            );
        });
    }


    /* ============================================================
     *  ۹) WISHLIST — صفحه (حذف کارت + پاک‌سازی)
     * ============================================================ */
    function initWishlistPage() {

        /* حذف کارت */
        document.addEventListener('click', function (e) {

            var btn = e.target.closest('.wcup-wl-card-remove');
            if (!btn) return;

            e.preventDefault();
            e.stopPropagation();

            var card = btn.closest('.wcup-wl-card');
            if (!card) return;

            var productId = btn.getAttribute('data-product-id');
            if (!productId || !window.wcupWishlistData) return;

            var data = window.wcupWishlistData;

            btn.disabled = true;

            var xhr = new XMLHttpRequest();
            xhr.open('POST', data.ajaxUrl, true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');

            xhr.onload = function () {
                btn.disabled = false;

                try {
                    var res = JSON.parse(xhr.responseText);
                    if (res && res.success) {
                        card.classList.add('is-removing');
                        setTimeout(function () {
                            card.remove();

                            /* آپدیت badge */
                            var link = document.querySelector('.wcup-nav-item[href*="/wishlist"]');
                            if (link) {
                                var badge = link.querySelector('.wcup-nav-badge');
                                if (res.data.count <= 0) {
                                    if (badge) badge.remove();
                                } else if (badge) {
                                    badge.textContent = toFaNum(res.data.count);
                                }
                            }

                            Toast.info('از علاقه‌مندی‌ها حذف شد.');

                            if (document.querySelectorAll('.wcup-wl-card').length === 0) {
                                window.location.reload();
                            }
                        }, 300);
                    }
                } catch (err) {}
            };

            xhr.send(
                'action=wcup_toggle_wishlist' +
                '&product_id=' + encodeURIComponent(productId) +
                '&nonce=' + encodeURIComponent(data.nonce)
            );
        });

        /* پاک‌سازی همه */
        var clearBtn = document.getElementById('wcup-wl-clear');
        if (clearBtn) {
            clearBtn.addEventListener('click', function () {
                if (!confirm('همهٔ علاقه‌مندی‌ها حذف بشن؟ این کار برگشت‌پذیر نیست.')) return;

                clearBtn.disabled = true;

                var ids = [];
                document.querySelectorAll('.wcup-wl-card').forEach(function (card) {
                    var id = card.getAttribute('data-product-id');
                    if (id) ids.push(id);
                });

                if (ids.length === 0) {
                    clearBtn.disabled = false;
                    return;
                }

                var data = window.wcupWishlistData;
                if (!data) return;

                var remaining = ids.length;
                var failed = false;

                ids.forEach(function (id) {
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', data.ajaxUrl, true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');

                    xhr.onload = function () {
                        remaining--;
                        if (remaining === 0) {
                            if (!failed) {
                                Toast.success('همه حذف شدند.');
                                setTimeout(function () {
                                    window.location.reload();
                                }, 800);
                            }
                        }
                    };

                    xhr.onerror = function () { failed = true; remaining--; };

                    xhr.send(
                        'action=wcup_toggle_wishlist' +
                        '&product_id=' + encodeURIComponent(id) +
                        '&nonce=' + encodeURIComponent(data.nonce)
                    );
                });
            });
        }
    }

    /* ============================================================
     *  ۱۰) ADDRESSES — Multiple
     * ============================================================ */
    function initAddresses() {

        /* ═══ چک DOM ═══ */
        var modal = document.getElementById('wcup-ad-modal');
        if (!modal) return;

        var form = document.getElementById('wcup-ad-form');
        if (!form) {
            console.warn('WCUP: فرم آدرس پیدا نشد');
            return;
        }

        /* ═══ چک AJAX data ═══ */
        var data = window.wcupAddressesData;

        if (!data || !data.nonce) {
            console.warn('WCUP: wcupAddressesData تعریف نشده');
            Toast.error('خطا: نشست نامعتبر. صفحه رو رفرش کن.');
            return;
        }

        /* ═══ عناصر ═══ */
        var modalTitle = document.getElementById('wcup-ad-modal-title');
        var submitBtn  = document.getElementById('wcup-ad-submit');
        var closeBtn   = document.getElementById('wcup-ad-modal-close');
        var cancelBtn  = document.getElementById('wcup-ad-cancel');
        var backdrop   = modal.querySelector('.wcup-ad-modal-backdrop');
        var idField    = form.querySelector('#wcup-ad-field-id');

        /* ═══ Open Modal ═══ */
        function openModal(addressData) {

            form.reset();
            if (idField) idField.value = '';

            if (addressData && addressData.id) {
                if (modalTitle) modalTitle.textContent = 'ویرایش آدرس';
                if (idField) idField.value = addressData.id;

                var fields = ['label', 'first_name', 'last_name', 'company', 'phone', 'email',
                              'country', 'state', 'city', 'address_1', 'address_2', 'postcode'];

                fields.forEach(function (f) {
                    var el = form.querySelector('[name="' + f + '"]');
                    if (el && addressData[f] !== undefined && addressData[f] !== null) {
                        el.value = addressData[f];
                    }
                });

                var defBill = form.querySelector('#wcup-ad-def-bill');
                var defShip = form.querySelector('#wcup-ad-def-ship');
                if (defBill) defBill.checked = !!addressData.is_default_billing;
                if (defShip) defShip.checked = !!addressData.is_default_shipping;

            } else {
                if (modalTitle) modalTitle.textContent = 'افزودن آدرس جدید';
            }

            /* ── نمایش Modal ── */
            modal.style.display = 'flex';
            modal.classList.add('is-open');

            /* ── 🔒 قفل کردن اسکرول صفحه ── */
            lockBodyScroll();

            /* ── فوکوس روی اولین فیلد ── */
            setTimeout(function () {
                var firstInput = form.querySelector('input[name="label"]');
                if (firstInput) firstInput.focus();
            }, 100);
        }

        /* ═══ Close Modal ═══ */
        function closeModal() {
            modal.style.display = 'none';
            modal.classList.remove('is-open');

            /* ── 🔓 آزاد کردن اسکرول ── */
            unlockBodyScroll();
        }

        /* ═══ Scroll Lock — قفل کردن صفحه ═══ */
        function lockBodyScroll() {
            var scrollY = window.scrollY || window.pageYOffset || 0;
            modal.setAttribute('data-scroll-y', scrollY);

            document.documentElement.style.overflow = 'hidden';
            document.body.style.overflow = 'hidden';
            document.body.style.position = 'fixed';
            document.body.style.top = '-' + scrollY + 'px';
            document.body.style.width = '100%';

            /* ⭐ اضافه */
            document.documentElement.classList.add('wcup-ad-modal-open');
            document.body.classList.add('wcup-ad-modal-open');
        }

        function unlockBodyScroll() {
            var scrollY = parseInt(modal.getAttribute('data-scroll-y') || '0', 10);

            document.documentElement.style.overflow = '';
            document.body.style.overflow = '';
            document.body.style.position = '';
            document.body.style.top = '';
            document.body.style.width = '';

            /* ⭐ اضافه */
            document.documentElement.classList.remove('wcup-ad-modal-open');
            document.body.classList.remove('wcup-ad-modal-open');

            window.scrollTo(0, scrollY);
        }

        /* ═══ Add Buttons ═══ */
        var addBtn      = document.getElementById('wcup-ad-add');
        var addFirstBtn = document.getElementById('wcup-ad-add-first');

        if (addBtn) {
            addBtn.addEventListener('click', function (e) {
                e.preventDefault();
                openModal(null);
            });
        }

        if (addFirstBtn) {
            addFirstBtn.addEventListener('click', function (e) {
                e.preventDefault();
                openModal(null);
            });
        }

        /* ═══ Close ═══ */
        if (closeBtn)  closeBtn.addEventListener('click', closeModal);
        if (cancelBtn) cancelBtn.addEventListener('click', closeModal);
        if (backdrop)  backdrop.addEventListener('click', closeModal);

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && modal.classList.contains('is-open')) {
                closeModal();
            }
        });

        /* ═══ Edit ═══ */
        document.addEventListener('click', function (e) {
            var editBtn = e.target.closest('.wcup-ad-card-btn--edit');
            if (!editBtn) return;

            e.preventDefault();

            var addressId = editBtn.getAttribute('data-address-id');
            if (!addressId) return;

            var addressData = null;
            if (window.wcupAddressesList && Array.isArray(window.wcupAddressesList)) {
                window.wcupAddressesList.forEach(function (a) {
                    if (a.id === addressId) addressData = a;
                });
            }

            openModal(addressData || { id: addressId });
        });

        /* ═══ Delete ═══ */
        document.addEventListener('click', function (e) {
            var delBtn = e.target.closest('.wcup-ad-card-btn--delete');
            if (!delBtn) return;

            e.preventDefault();

            if (!confirm('این آدرس حذف بشه؟')) return;

            var addressId = delBtn.getAttribute('data-address-id');
            if (!addressId) return;

            delBtn.disabled = true;

            var xhr = new XMLHttpRequest();
            xhr.open('POST', data.ajaxUrl, true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');

            xhr.onload = function () {
                delBtn.disabled = false;

                try {
                    var res = JSON.parse(xhr.responseText);
                    if (res && res.success) {
                        var card = delBtn.closest('.wcup-ad-card');
                        if (card) {
                            card.style.transition = 'opacity .25s';
                            card.style.opacity = '0';
                            setTimeout(function () {
                                card.remove();
                                if (document.querySelectorAll('.wcup-ad-card').length === 0) {
                                    window.location.reload();
                                }
                            }, 300);
                        }
                        Toast.success('آدرس حذف شد.');
                    } else {
                        Toast.error((res && res.data && res.data.message) || 'خطا در حذف.');
                    }
                } catch (err) {
                    Toast.error('پاسخ نامعتبر.');
                }
            };

            xhr.send(
                'action=wcup_address_delete' +
                '&address_id=' + encodeURIComponent(addressId) +
                '&nonce=' + encodeURIComponent(data.nonce)
            );
        });

        /* ═══ Set Default ═══ */
        document.addEventListener('click', function (e) {
            var btn = e.target.closest('.wcup-ad-default-btn');
            if (!btn) return;

            e.preventDefault();

            var addressId = btn.getAttribute('data-address-id');
            var type      = btn.getAttribute('data-type');
            if (!addressId || !type) return;

            btn.disabled = true;

            var xhr = new XMLHttpRequest();
            xhr.open('POST', data.ajaxUrl, true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');

            xhr.onload = function () {
                btn.disabled = false;

                try {
                    var res = JSON.parse(xhr.responseText);
                    if (res && res.success) {
                        Toast.success(res.data.message || 'تنظیم شد.');
                        setTimeout(function () {
                            window.location.reload();
                        }, 600);
                    } else {
                        Toast.error((res && res.data && res.data.message) || 'خطا.');
                    }
                } catch (err) {
                    Toast.error('پاسخ نامعتبر.');
                }
            };

            xhr.send(
                'action=wcup_address_set_default' +
                '&address_id=' + encodeURIComponent(addressId) +
                '&type=' + encodeURIComponent(type) +
                '&nonce=' + encodeURIComponent(data.nonce)
            );
        });

        /* ═══ فرم submit — مهم‌ترین بخش ═══ */
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            e.stopPropagation();

            if (!submitBtn) return;

            submitBtn.disabled = true;
            submitBtn.classList.add('is-loading');

            var formData = new FormData(form);
            formData.append('action', 'wcup_address_save');
            formData.append('nonce', data.nonce);

            /* checkbox‌ها */
            var defBill = form.querySelector('#wcup-ad-def-bill');
            var defShip = form.querySelector('#wcup-ad-def-ship');
            formData.set('is_default_billing',  defBill && defBill.checked ? '1' : '0');
            formData.set('is_default_shipping', defShip && defShip.checked ? '1' : '0');

            console.log('WCUP: Submitting address...');

            var xhr = new XMLHttpRequest();
            xhr.open('POST', data.ajaxUrl, true);

            xhr.onload = function () {
                submitBtn.disabled = false;
                submitBtn.classList.remove('is-loading');

                console.log('WCUP: Response', xhr.status, xhr.responseText);

                if (xhr.status !== 200) {
                    Toast.error('خطای سرور (کد ' + xhr.status + ')');
                    return;
                }

                var res;
                try {
                    res = JSON.parse(xhr.responseText);
                } catch (err) {
                    Toast.error('پاسخ نامعتبر. Console رو چک کن.');
                    return;
                }

                if (res && res.success) {
                    Toast.success(res.data.message || 'آدرس ذخیره شد.');
                    closeModal();
                    setTimeout(function () {
                        window.location.reload();
                    }, 600);
                } else {
                    var msg  = (res && res.data && res.data.message) || 'خطا در ذخیره.';
                    var code = (res && res.data && res.data.code) || '';
                    Toast.error(msg + (code ? ' [' + code + ']' : ''), 5000);
                    console.error('Save failed:', res);
                }
            };

            xhr.onerror = function () {
                submitBtn.disabled = false;
                submitBtn.classList.remove('is-loading');
                Toast.error('خطای شبکه.');
            };

            xhr.send(formData);
        });

        console.log('WCUP: initAddresses OK');
    }

    /* ============================================================
     *  INIT
     * ============================================================ */
    function init() {
        initTabs();
        initPasswordToggles();
        initAvatar();
        initNotices();
        initDownloadToggles();
        initPasswordStrength();
        initNotifications();
        initWishlistToggle();
        initWishlistPage();
		initAddresses();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();