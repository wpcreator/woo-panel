<?php
/**
 * WCUP Account — Bootstrap
 * ============================================================
 *  @package WCUP_Account
 *  @version 1.0.1
 * ============================================================
 */

defined( 'ABSPATH' ) || exit;

/* ─────────── ثابت‌ها ─────────── */
define( 'WCUP_VERSION', '1.0.0' );
define( 'WCUP_FILE',    __FILE__ );
define( 'WCUP_PATH',    trailingslashit( dirname( __FILE__ ) ) );
define( 'WCUP_URL',     trailingslashit( get_stylesheet_directory_uri() . '/wcup-account' ) );

define( 'WCUP_MIN_PHP', '7.4' );
define( 'WCUP_MIN_WC',  '5.0' );

/* ─────────── بررسی پیش‌نیازها ─────────── */
if ( version_compare( PHP_VERSION, WCUP_MIN_PHP, '<' ) ) {
    return;
}

if ( ! class_exists( 'WooCommerce' ) ) {
    return;
}

/* ─────────── لود هسته ─────────── */
$wcup_core_file = WCUP_PATH . 'includes/class-wcup-core.php';

if ( file_exists( $wcup_core_file ) ) {
    require_once $wcup_core_file;
}

/**
 * دسترسی سراسری به هسته
 */
function wcup_account() {
    if ( class_exists( 'wcup_core' ) ) {
        return wcup_core::instance();
    }
    return null;
}

/**
 * ⚠️ این فایل از functions.php قالب لود می‌شه، نه به‌عنوان افزونه.
 * پس هوک plugins_loaded کار نمی‌کنه.
 */
add_action( 'after_setup_theme', 'wcup_account', 5 );