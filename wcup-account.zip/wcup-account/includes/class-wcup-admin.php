<?php
/**
 * WCUP Admin — پنل مدیریت افزونه
 * ============================================================
 *  @package WCUP_Account
 *  @version 1.2.0
 * ============================================================
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_admin' ) ) {
    return;
}

class wcup_admin {

    const MENU_SLUG = 'wcup-myaccount';
    const NONCE     = 'wcup_admin_nonce';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {

        add_action( 'admin_menu',            array( $this, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

        /* AJAX handlers */
        add_action( 'wp_ajax_wcup_save_settings', array( $this, 'ajax_save_settings' ) );

        /* ⚠️ تغییر ترتیب زیرمنوها (CPT اطلاعیه خودکار اضافه می‌شه) */
        add_filter( 'custom_menu_order', '__return_true' );
        add_filter( 'menu_order', array( $this, 'reorder_submenu' ), 999 );
    }

    /* ============================================================
     *  ثبت منو
     * ============================================================ */
    public function register_menu() {

        /* ─── منوی اصلی ─── */
        add_menu_page(
            'پنل کاربری',
            'پنل کاربری',
            'manage_options',
            self::MENU_SLUG,
            array( $this, 'render_dashboard' ),
            'dashicons-admin-users',
            26
        );

        /* ─── زیرمنوها ───
         *  ترتیب زیرمنوها مهمه چون CPT اطلاعیه (که با show_in_menu
         *  به همین slug وصل می‌شه) خودکار بعد از اینا اضافه می‌شه.
         *  برای همین «اطلاعیه‌ها» رو دستی اینجا اضافه نمی‌کنیم.
         */
        $submenus = array(
            'dashboard' => array( '📊 داشبورد',            'render_dashboard' ),
            'general'   => array( '⚙️ تنظیمات عمومی',      'render_general' ),
            'widgets'   => array( '🎛️ کارت‌های داشبورد',   'render_widgets' ),
            'menu'      => array( '📋 منوی حساب',          'render_menu' ),
            'carriers'  => array( '🚚 شرکت‌های حمل',       'render_carriers' ),
            'progress'  => array( '📈 نوار پیشرفت',        'render_progress' ),
            'invoice'   => array( '🧾 فاکتور',             'render_invoice' ),  /* 🆕 */
            'tools'     => array( '🛠️ ابزارها',           'render_tools' ),
        );

        foreach ( $submenus as $slug => $data ) {

            $page_slug = ( 'dashboard' === $slug ) ? self::MENU_SLUG : self::MENU_SLUG . '-' . $slug;

            add_submenu_page(
                self::MENU_SLUG,
                $data[0],
                $data[0],
                'manage_options',
                $page_slug,
                array( $this, $data[1] )
            );
        }
    }

    /* ============================================================
     *  ترتیب زیرمنوها
     *  (چون CPT اطلاعیه خودکار اضافه میشه، دستی مرتبش می‌کنیم)
     * ============================================================ */
    public function reorder_submenu( $menu_order ) {

        global $submenu;

        if ( empty( $submenu[ self::MENU_SLUG ] ) ) {
            return $menu_order;
        }

        /* ترتیب دلخواه (با slug اصلی) */
        $desired_order = array(
            self::MENU_SLUG,                       /* 📊 داشبورد */
            self::MENU_SLUG . '-general',          /* ⚙️ تنظیمات عمومی */
            self::MENU_SLUG . '-widgets',          /* 🎛️ کارت‌های داشبورد */
            self::MENU_SLUG . '-menu',             /* 📋 منوی حساب */
            self::MENU_SLUG . '-carriers',         /* 🚚 شرکت‌های حمل */
			self::MENU_SLUG . '-invoice',         /* 🧾 فاکتور' */
            self::MENU_SLUG . '-progress',         /* 📈 نوار پیشرفت */
            'edit.php?post_type=wcup_notice',      /* 📢 اطلاعیه‌ها (CPT) */
            self::MENU_SLUG . '-tools',            /* 🛠️ ابزارها */
        );

        /* مرتب‌سازی */
        usort( $submenu[ self::MENU_SLUG ], function ( $a, $b ) use ( $desired_order ) {

            $pos_a = array_search( $a[2], $desired_order, true );
            $pos_b = array_search( $b[2], $desired_order, true );

            if ( false === $pos_a ) $pos_a = 999;
            if ( false === $pos_b ) $pos_b = 999;

            return $pos_a - $pos_b;
        } );

        return $menu_order;
    }

    /* ============================================================
     *  AJAX: ذخیره تنظیمات
     * ============================================================ */
    public function ajax_save_settings() {

        if ( ! check_ajax_referer( self::NONCE, 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => 'نشست منقضی شده.' ) );
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
        }

        $data = isset( $_POST['settings'] ) ? (array) $_POST['settings'] : array();
        wcup_settings::update( $data );

        wp_send_json_success( array( 'message' => 'تنظیمات با موفقیت ذخیره شد.' ) );
    }

    /* ============================================================
     *  بارگذاری CSS/JS ادمین
     * ============================================================ */
    public function enqueue_assets( $hook ) {

        /* فقط صفحات پنل کاربری + صفحهٔ CPT اطلاعیه */
        $is_wcup_page  = ( strpos( $hook, self::MENU_SLUG ) !== false );
        $is_notice_cpt = ( function_exists( 'get_current_screen' ) &&
                           get_current_screen() &&
                           'wcup_notice' === get_current_screen()->post_type );

        if ( ! $is_wcup_page && ! $is_notice_cpt ) {
            return;
        }

        /* ⚠️ لازم برای media library در صفحهٔ تنظیمات عمومی */
        wp_enqueue_media();

        $css_file = WCUP_PATH . 'assets/admin/admin.css';
        $js_file  = WCUP_PATH . 'assets/admin/admin.js';

        if ( file_exists( $css_file ) ) {
            wp_enqueue_style(
                'wcup-admin',
                WCUP_URL . 'assets/admin/admin.css',
                array(),
                WCUP_VERSION
            );
        }

        wp_enqueue_style( 'wp-color-picker' );

        if ( file_exists( $js_file ) ) {
            wp_enqueue_script(
                'wcup-admin',
                WCUP_URL . 'assets/admin/admin.js',
                array( 'jquery', 'wp-color-picker' ),
                WCUP_VERSION,
                true
            );

            wp_localize_script( 'wcup-admin', 'wcupAdmin', array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( self::NONCE ),
            ) );
        }
    }

    /* ============================================================
     *  رندر صفحات
     * ============================================================ */
    public function render_dashboard() { $this->render_page( 'dashboard' ); }
    public function render_general()   { $this->render_page( 'general' ); }
    public function render_widgets()   { $this->render_page( 'widgets' ); }
    public function render_menu()      { $this->render_page( 'menu' ); }
    public function render_carriers()  { $this->render_page( 'carriers' ); }
    public function render_progress()  { $this->render_page( 'progress' ); }
    public function render_invoice() { $this->render_page( 'invoice' ); }
    public function render_tools()     { $this->render_page( 'tools' ); }

    /**
     * لود فایل صفحه از includes/admin/
     */
    private function render_page( $slug ) {

        $file = WCUP_PATH . 'includes/admin/' . $slug . '.php';

        if ( file_exists( $file ) ) {
            include $file;
        } else {
            echo '<div class="wrap"><p>صفحه پیدا نشد: ' . esc_html( $slug ) . '</p></div>';
        }
    }
}