<?php
/**
 * WCUP Notice — اطلاعیه‌های سیستم (Core)
 * ============================================================
 *  این کلاس مسئول:
 *    - ثبت CPT (که زیر منوی پنل کاربری نمایش داده می‌شه)
 *    - AJAX dismiss
 *    - nonce برای فرانت
 *
 *  ⚠️ منطق ادمین (متاباکس، ستون، پیش‌نمایش) در فایل زیر است:
 *     includes/admin/notice-meta.php
 *
 *  @package WCUP_Account
 *  @version 2.0.0
 * ============================================================
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_notice' ) ) {
    return;
}

class wcup_notice {

    const POST_TYPE  = 'wcup_notice';
    const NONCE_KEY  = 'wcup_save_notice';
    const NONCE_FLD  = 'wcup_notice_nonce';
    const AJAX_KEY   = 'wcup_dismiss_notice';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {

        /* CPT */
        add_action( 'init', array( $this, 'register_cpt' ) );

        /* AJAX: بستن اطلاعیه */
        add_action( 'wp_ajax_' . self::AJAX_KEY, array( $this, 'ajax_dismiss' ) );

        /* nonce برای JS فرانت */
        add_action( 'wp_footer', array( $this, 'print_nonce' ), 90 );

        /* لود منطق ادمین (فقط در پنل ادمین) */
        if ( is_admin() ) {
            $admin_file = WCUP_PATH . 'includes/admin/notice-meta.php';
            if ( file_exists( $admin_file ) ) {
                require_once $admin_file;
            }
        }
    }

    /* ============================================================
     *  شرط نمایش
     * ============================================================ */
    public function is_enabled() {
        return (bool) wcup_settings::get( 'notices_enabled', 1 );
    }

    /* ============================================================
     *  ثبت CPT — زیر منوی «پنل کاربری»
     * ============================================================ */
    public function register_cpt() {

        if ( ! $this->is_enabled() ) {
            return;
        }

        register_post_type( self::POST_TYPE, array(
            'labels' => array(
                'name'          => 'اطلاعیه‌ها',
                'singular_name' => 'اطلاعیه',
                'add_new'       => 'افزودن اطلاعیه',
                'add_new_item'  => 'افزودن اطلاعیه جدید',
                'edit_item'     => 'ویرایش اطلاعیه',
                'all_items'     => 'اطلاعیه‌ها',
                'menu_name'     => '📢 اطلاعیه‌ها',
                'search_items'  => 'جستجوی اطلاعیه',
                'not_found'     => 'اطلاعیه‌ای یافت نشد',
            ),
            'public'          => false,
            'show_ui'         => true,
            'show_in_menu'    => 'wcup-myaccount',   /* ⭐ زیر منوی پنل کاربری */
            'capability_type' => 'post',
            'supports'        => array( 'title', 'editor' ),
            'has_archive'     => false,
            'rewrite'         => false,
        ) );
    }

    /* ============================================================
     *  AJAX: بستن اطلاعیه
     * ============================================================ */
    public function ajax_dismiss() {

        if ( ! check_ajax_referer( self::AJAX_KEY, 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => 'نشست منقضی شده.' ) );
        }

        $user_id   = get_current_user_id();
        $notice_id = isset( $_POST['notice_id'] ) ? (int) $_POST['notice_id'] : 0;

        if ( ! $user_id || ! $notice_id ) {
            wp_send_json_error( array( 'message' => 'اطلاعات نامعتبر.' ) );
        }

        $dismissed = get_user_meta( $user_id, '_wcup_dismissed_notices', true );
        $dismissed = is_array( $dismissed ) ? $dismissed : array();

        if ( ! in_array( $notice_id, $dismissed, true ) ) {
            $dismissed[] = $notice_id;
            update_user_meta( $user_id, '_wcup_dismissed_notices', $dismissed );
        }

        wp_send_json_success( array( 'message' => 'بسته شد.' ) );
    }

    /* ============================================================
     *  nonce برای JS (فرانت)
     * ============================================================ */
    public function print_nonce() {

        if ( ! $this->is_enabled() ) {
            return;
        }

        if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
            return;
        }

        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            return;
        }
        ?>
        <script>
        window.wcupNoticeData = {
            ajaxUrl: <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,
            nonce:   <?php echo wp_json_encode( wp_create_nonce( self::AJAX_KEY ) ); ?>
        };
        </script>
        <?php
    }
}