<?php
/**
 * WCUP Avatar — مدیریت عکس پروفایل
 * ============================================================
 *  شامل:
 *    - ۱۰. آپلود و مدیریت عکس پروفایل
 *    - ۱۱. فیلتر آواتار (جایگزینی Gravatar)
 *    - ۱۲. پاک‌سازی عکس هنگام حذف کاربر
 *    - ۱۳. حذف آواتار با AJAX
 *
 *  @package WCUP_Account
 *  @version 1.0.0
 * ============================================================
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_avatar' ) ) {
    return;
}

class wcup_avatar {

    const META_KEY   = 'wcup_avatar_id';
    const OWNER_META = '_wcup_avatar_owner';
    const NONCE_KEY  = 'wcup_delete_avatar';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {

        /* آپلود هنگام ذخیرهٔ حساب */
        add_action( 'woocommerce_save_account_details', array( $this, 'handle_upload' ), 10, 1 );

        /* نمایش پیام‌ها */
        add_action( 'woocommerce_account_content', array( $this, 'render_messages' ), 5 );

        /* فیلتر آواتار */
        add_filter( 'get_avatar_data', array( $this, 'filter_avatar' ), 10, 2 );

        /* پاک‌سازی هنگام حذف کاربر */
        add_action( 'delete_user', array( $this, 'cleanup_on_delete' ) );

        /* AJAX حذف */
        add_action( 'wp_ajax_wcup_delete_avatar', array( $this, 'ajax_delete' ) );

        /* nonce برای JS */
        add_action( 'wp_footer', array( $this, 'print_nonce' ), 80 );
    }

    /* ============================================================
     *  شرط نمایش
     * ============================================================ */
    private function should_load() {

        if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
            return false;
        }

        if ( ! wcup_settings::get( 'avatar_upload', 1 ) ) {
            return false;
        }

        return true;
    }

    /* ============================================================
     *  ۱۰) آپلود / حذف هنگام ذخیرهٔ حساب
     * ============================================================ */
    public function handle_upload( $user_id ) {

        if ( ! $user_id || ! is_user_logged_in() ) {
            return;
        }

        if ( empty( $_POST['save-account-details-nonce'] ) ||
             ! wp_verify_nonce( $_POST['save-account-details-nonce'], 'save_account_details' ) ) {
            return;
        }

        /* حذف آواتار درخواست شده */
        if ( ! empty( $_POST['wcup_avatar_delete'] ) && $_POST['wcup_avatar_delete'] === '1' ) {
            $this->delete_user_avatar( $user_id );
        }

        /* اگر فایلی آپلود نشده، برو */
        if ( empty( $_FILES['wcup_avatar'] ) ) {
            return;
        }

        $file = $_FILES['wcup_avatar'];

        /* خطاهای آپلود */
        if ( isset( $file['error'] ) && $file['error'] !== UPLOAD_ERR_OK ) {

            if ( (int) $file['error'] === UPLOAD_ERR_NO_FILE ) {
                return;
            }

            $error_msgs = array(
                UPLOAD_ERR_INI_SIZE   => 'حجم فایل از حد مجاز سرور بیشتره.',
                UPLOAD_ERR_FORM_SIZE  => 'حجم فایل از حد مجاز فرم بیشتره.',
                UPLOAD_ERR_PARTIAL    => 'آپلود فایل ناقص موند.',
                UPLOAD_ERR_NO_TMP_DIR => 'پوشهٔ موقت روی سرور وجود نداره.',
                UPLOAD_ERR_CANT_WRITE => 'نوشتن روی سرور ممکن نیست.',
                UPLOAD_ERR_EXTENSION  => 'آپلود توسط افزونهٔ سرور متوقف شد.',
            );

            $msg = isset( $error_msgs[ (int) $file['error'] ] )
                ? $error_msgs[ (int) $file['error'] ]
                : 'خطای نامشخص در آپلود.';

            set_transient( 'wcup_avatar_error_' . $user_id, $msg, 60 );
            return;
        }

        if ( empty( $file['name'] ) || empty( $file['size'] ) ) {
            return;
        }

        /* بررسی پسوند */
        $ext         = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
        $allowed_ext = array( 'jpg', 'jpeg', 'png', 'webp', 'gif' );

        if ( ! in_array( $ext, $allowed_ext, true ) ) {
            set_transient( 'wcup_avatar_error_' . $user_id, 'فرمت تصویر مجاز نیست (JPG، PNG، WebP، GIF).', 60 );
            return;
        }

        /* بررسی حجم */
        if ( $file['size'] > 2 * 1024 * 1024 ) {
            set_transient( 'wcup_avatar_error_' . $user_id, 'حجم تصویر نباید بیشتر از ۲ مگابایت باشد.', 60 );
            return;
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $attachment_id = media_handle_upload( 'wcup_avatar', 0 );

        if ( is_wp_error( $attachment_id ) ) {
            set_transient( 'wcup_avatar_error_' . $user_id, 'خطا در آپلود: ' . $attachment_id->get_error_message(), 60 );
            return;
        }

        /* حذف آواتار قدیمی */
        $old_id = (int) get_user_meta( $user_id, self::META_KEY, true );
        if ( $old_id && $old_id !== $attachment_id ) {
            wp_delete_attachment( $old_id, true );
        }

        update_user_meta( $user_id, self::META_KEY, $attachment_id );
        update_post_meta( $attachment_id, self::OWNER_META, $user_id );

        set_transient( 'wcup_avatar_success_' . $user_id, '1', 60 );
    }

    /* ============================================================
     *  نمایش پیام‌ها
     * ============================================================ */
    public function render_messages() {

        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            return;
        }

        $error = get_transient( 'wcup_avatar_error_' . $user_id );
        if ( $error ) {
            wc_print_notice( $error, 'error' );
            delete_transient( 'wcup_avatar_error_' . $user_id );
        }

        $success = get_transient( 'wcup_avatar_success_' . $user_id );
        if ( $success ) {
            wc_print_notice( 'عکس پروفایل با موفقیت ذخیره شد.', 'success' );
            delete_transient( 'wcup_avatar_success_' . $user_id );
        }
    }

    /* ============================================================
     *  ۱۱) فیلتر آواتار
     * ============================================================ */
    public function filter_avatar( $args, $id_or_email ) {

        $user_id = $this->resolve_user_id( $id_or_email );
        if ( ! $user_id ) {
            return $args;
        }

        $avatar_id = (int) get_user_meta( $user_id, self::META_KEY, true );
        if ( ! $avatar_id ) {
            return $args;
        }

        $size = ! empty( $args['size'] ) ? (int) $args['size'] : 96;
        $url  = wp_get_attachment_image_url( $avatar_id, array( $size, $size ) );

        if ( $url ) {
            $args['url']          = $url;
            $args['found_avatar'] = true;
        }

        return $args;
    }

    /* ============================================================
     *  تشخیص user_id از انواع ورودی
     * ============================================================ */
    private function resolve_user_id( $id_or_email ) {

        if ( is_numeric( $id_or_email ) ) {
            return (int) $id_or_email;
        }

        if ( $id_or_email instanceof WP_User ) {
            return (int) $id_or_email->ID;
        }

        if ( $id_or_email instanceof WP_Comment ) {
            return (int) $id_or_email->user_id;
        }

        if ( $id_or_email instanceof WP_Post ) {
            return (int) $id_or_email->post_author;
        }

        if ( is_string( $id_or_email ) && is_email( $id_or_email ) ) {
            $user = get_user_by( 'email', $id_or_email );
            if ( $user ) {
                return (int) $user->ID;
            }
        }

        return 0;
    }

    /* ============================================================
     *  ۱۲) پاک‌سازی هنگام حذف کاربر
     * ============================================================ */
    public function cleanup_on_delete( $user_id ) {
        $this->delete_user_avatar( $user_id );
    }

    /* ============================================================
     *  ۱۳) AJAX: حذف آواتار
     * ============================================================ */
    public function ajax_delete() {

        if ( ! check_ajax_referer( self::NONCE_KEY, 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => 'نشست منقضی شده است. صفحه را رفرش کنید.' ) );
        }

        $user_id = get_current_user_id();

        if ( ! $user_id ) {
            wp_send_json_error( array( 'message' => 'شما وارد حساب نشده‌اید.' ) );
        }

        $this->delete_user_avatar( $user_id );

        $default_url = get_avatar_url( $user_id, array( 'size' => 96 ) );

        wp_send_json_success( array(
            'message'     => 'عکس پروفایل با موفقیت حذف شد.',
            'default_url' => $default_url,
        ) );
    }

    /* ============================================================
     *  حذف آواتار کاربر (مشترک بین AJAX و آپلود)
     * ============================================================ */
    private function delete_user_avatar( $user_id ) {

        $avatar_id = (int) get_user_meta( $user_id, self::META_KEY, true );

        if ( $avatar_id ) {
            wp_delete_attachment( $avatar_id, true );
        }

        delete_user_meta( $user_id, self::META_KEY );
    }

    /* ============================================================
     *  nonce برای JS
     * ============================================================ */
    public function print_nonce() {

        if ( ! $this->should_load() ) {
            return;
        }
        ?>
        <script>
        window.wcupAvatarData = {
            ajaxUrl: <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,
            nonce:   <?php echo wp_json_encode( wp_create_nonce( self::NONCE_KEY ) ); ?>
        };
        </script>
        <?php
    }
}