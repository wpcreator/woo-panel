<?php
defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_core' ) ) {
    return;
}

final class wcup_core {

    const DB_VERSION = '1.0.0';

    private static $instance = null;
    private $classes = array();

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->load_dependencies();
        $this->init_classes();
        $this->maybe_upgrade();
        add_action( 'init', array( $this, 'load_textdomain' ) );
    }

    private function load_dependencies() {

        $includes = WCUP_PATH . 'includes/';

        $files = array(
            'class-wcup-settings.php',
            'class-wcup-helpers.php',
            'class-wcup-assets.php',
            'class-wcup-menu.php',
            'class-wcup-popup.php',
            'class-wcup-avatar.php',
            'class-wcup-progress.php',
            'class-wcup-tracking.php',
            'class-wcup-reviews.php',
            'class-wcup-notice.php',
			'class-wcup-notifications.php',
			'class-wcup-wishlist.php',
			'class-wcup-addresses.php',
			'class-wcup-invoice.php',
        );

        foreach ( $files as $file ) {
            $path = $includes . $file;
            if ( file_exists( $path ) ) {
                require_once $path;
            }
        }

        if ( is_admin() ) {
            $admin_file = $includes . 'class-wcup-admin.php';
            if ( file_exists( $admin_file ) ) {
                require_once $admin_file;
            }
        }
    }

    private function init_classes() {

        /* settings اول */
        if ( class_exists( 'wcup_settings' ) ) {
            $this->classes['settings'] = wcup_settings::instance();
        }

        $map = array(
            'assets'    => 'wcup_assets',
            'menu'      => 'wcup_menu',
            'popup'     => 'wcup_popup',
            'avatar'    => 'wcup_avatar',
            'progress'  => 'wcup_progress',
            'tracking'  => 'wcup_tracking',
            'reviews'   => 'wcup_reviews',
            'notice'    => 'wcup_notice',
			'notifications' => 'wcup_notifications',
			'wishlist'  => 'wcup_wishlist',
			'addresses' => 'wcup_addresses',
			'invoice'   => 'wcup_invoice',
        );

        foreach ( $map as $key => $class_name ) {
            if ( class_exists( $class_name ) && method_exists( $class_name, 'instance' ) ) {
                $this->classes[ $key ] = call_user_func( array( $class_name, 'instance' ) );
            }
        }

        if ( is_admin() && class_exists( 'wcup_admin' ) && method_exists( 'wcup_admin', 'instance' ) ) {
            $this->classes['admin'] = wcup_admin::instance();
        }
    }

    public function get( $key ) {
        return isset( $this->classes[ $key ] ) ? $this->classes[ $key ] : null;
    }

    public function load_textdomain() {
        load_child_theme_textdomain( 'wcup-account', WCUP_PATH . 'languages' );
    }

    private function maybe_upgrade() {
        $current = get_option( 'wcup_db_version', '0' );
        if ( version_compare( $current, self::DB_VERSION, '>=' ) ) return;
        $this->run_migrations();
        update_option( 'wcup_db_version', self::DB_VERSION );
    }

    private function run_migrations() {
        $this->migrate_user_meta();
        $this->migrate_post_meta();
        $this->migrate_notice_meta();
        $this->migrate_options();
        $this->migrate_notice_cpt();
    }

    private function migrate_user_meta() {
        global $wpdb;
        $map = array(
            'wclm_avatar_id'          => 'wcup_avatar_id',
            '_wclm_dismissed_notices' => '_wcup_dismissed_notices',
        );
        foreach ( $map as $old_key => $new_key ) {
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->usermeta}
                 SET meta_key = %s
                 WHERE meta_key = %s
                 AND user_id NOT IN (
                     SELECT user_id FROM (
                         SELECT user_id FROM {$wpdb->usermeta}
                         WHERE meta_key = %s
                     ) AS t
                 )",
                $new_key, $old_key, $new_key
            ) );
        }
    }

    private function migrate_post_meta() {
        global $wpdb;
        $map = array(
            '_wclm_avatar_id'        => '_wcup_avatar_id',
            '_wclm_avatar_owner'     => '_wcup_avatar_owner',
            '_wclm_tracking_code'    => '_wcup_tracking_code',
            '_wclm_tracking_carrier' => '_wcup_tracking_carrier',
            '_wclm_tracking_url'     => '_wcup_tracking_url',
        );
        foreach ( $map as $old_key => $new_key ) {
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->postmeta} SET meta_key = %s WHERE meta_key = %s",
                $new_key, $old_key
            ) );
        }
    }

    private function migrate_notice_meta() {
        global $wpdb;
        $map = array(
            '_wclm_notice_type'        => '_wcup_notice_type',
            '_wclm_notice_priority'    => '_wcup_notice_priority',
            '_wclm_notice_dismissible' => '_wcup_notice_dismissible',
        );
        foreach ( $map as $old_key => $new_key ) {
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->postmeta} SET meta_key = %s WHERE meta_key = %s",
                $new_key, $old_key
            ) );
        }
    }

    private function migrate_options() {
        $map = array(
            'wclm_settings'    => 'wcup_settings',
            'wclm_carriers'    => 'wcup_carriers',
            'wclm_ma_settings' => 'wcup_settings',
        );
        foreach ( $map as $old_key => $new_key ) {
            $old_value = get_option( $old_key, null );
            if ( null === $old_value ) continue;
            if ( false === get_option( $new_key, false ) ) {
                update_option( $new_key, $old_value );
            }
        }
    }

    private function migrate_notice_cpt() {
        global $wpdb;
        $wpdb->query(
            "UPDATE {$wpdb->posts}
             SET post_type = 'wcup_notice'
             WHERE post_type = 'wclm_notice'"
        );
        clean_post_cache( 0 );
    }
}