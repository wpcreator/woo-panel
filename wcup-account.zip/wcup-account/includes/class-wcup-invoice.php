<?php
/**
 * WCUP Invoice — فاکتور HTML
 * ============================================================
 *  @package WCUP_Account
 *  @version 2.1.0
 * ============================================================
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_invoice' ) ) {
    return;
}

class wcup_invoice {

    const META_NUMBER = '_wcup_invoice_number';
    const META_DATE   = '_wcup_invoice_date';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {

        /* Endpoint HTML */
        add_action( 'template_redirect', array( $this, 'handle_html' ) );
        add_action( 'template_redirect', array( $this, 'handle_verify' ) );

        /* شمارهٔ فاکتور */
        add_action( 'woocommerce_payment_complete', array( $this, 'ensure_invoice_number' ), 10, 1 );
        add_action( 'woocommerce_order_status_processing', array( $this, 'ensure_invoice_number' ), 10, 1 );
        add_action( 'woocommerce_order_status_completed', array( $this, 'ensure_invoice_number' ), 10, 1 );
		add_action( 'woocommerce_account_invoices_endpoint', array( $this, 'render_invoices_endpoint' ) );

        /* ایمیل */
        add_action( 'woocommerce_order_status_completed', array( $this, 'on_order_completed' ), 20, 1 );

        /* ─── ادمین: ستون لیست سفارشات ─── */
        add_filter( 'manage_edit-shop_order_columns', array( $this, 'admin_column_header' ), 20 );
        add_action( 'manage_shop_order_posts_custom_column', array( $this, 'admin_column_content' ), 20, 2 );

        /* ─── ادمین: HPOS لیست سفارشات ─── */
        add_filter( 'manage_woocommerce_page_wc-orders_columns', array( $this, 'admin_column_header' ), 20 );
        add_action( 'manage_woocommerce_page_wc-orders_custom_column', array( $this, 'admin_column_content' ), 20, 2 );

        /* ─── ادمین: باکس در صفحهٔ سفارش ─── */
        add_action( 'woocommerce_admin_order_data_after_billing_address', array( $this, 'render_admin_order_box' ), 20 );
    }

    /* ============================================================
     *  فعاله؟
     * ============================================================ */
    public function is_enabled() {
        return (bool) wcup_settings::get( 'invoice_enabled', 1 );
    }

    /* ============================================================
     *  آیا این سفارش فاکتور داره؟
     * ============================================================ */
    public function can_download( $order ) {

        if ( ! $order instanceof WC_Order ) {
            return false;
        }

        if ( ! $this->is_enabled() ) {
            return false;
        }

        $allowed_statuses = apply_filters(
            'wcup_invoice_allowed_statuses',
            array( 'processing', 'completed' )
        );

        return $order->has_status( $allowed_statuses );
    }

    /* ============================================================
     *  شمارهٔ فاکتور
     * ============================================================ */
    public function get_invoice_number( $order ) {

        if ( ! $order instanceof WC_Order ) {
            return '';
        }

        $number = $order->get_meta( self::META_NUMBER );
        if ( $number ) {
            return $number;
        }

        return $this->generate_invoice_number( $order );
    }

    /* ============================================================
     *  ساختن شمارهٔ فاکتور
     * ============================================================ */
    private function generate_invoice_number( $order ) {

        if ( ! $order instanceof WC_Order ) {
            return '';
        }

        $now       = current_time( 'timestamp' );
        $year_greg = date( 'Y', $now );
        $year_j    = $this->to_jalali_year( $year_greg );

        /* prefix از تنظیمات */
        $prefix_name = wcup_settings::get( 'invoice_prefix', 'INV' );
        $prefix_name = sanitize_text_field( $prefix_name );
        if ( $prefix_name === '' ) {
            $prefix_name = 'INV';
        }

        global $wpdb;

        $prefix = $prefix_name . '-' . $year_j . '-';

        $max = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT MAX(CAST(SUBSTRING(meta_value, %d) AS UNSIGNED))
                 FROM {$wpdb->postmeta}
                 WHERE meta_key = %s
                 AND meta_value LIKE %s",
                strlen( $prefix ) + 1,
                self::META_NUMBER,
                $prefix . '%'
            )
        );

        $next   = (int) $max + 1;
        $number = $prefix . str_pad( $next, 4, '0', STR_PAD_LEFT );

        $order->update_meta_data( self::META_NUMBER, $number );
        $order->update_meta_data( self::META_DATE, current_time( 'mysql' ) );
        $order->save();

        /* ⭐ اعلان صدور فاکتور */
        $this->notify_invoice_issued( $order, $number );

        return $number;
    }

    /* ============================================================
     *  اعلان صدور فاکتور
     * ============================================================ */
    private function notify_invoice_issued( $order, $number ) {

        if ( ! class_exists( 'wcup_notifications' ) ) {
            return;
        }

        if ( ! wcup_settings::get( 'notifications_enabled', 1 ) ) {
            return;
        }

        $user_id = $order->get_customer_id();
        if ( ! $user_id ) {
            return;
        }

        /* چک نکنیم دوبار اعلان بدیم */
        $already = $order->get_meta( '_wcup_invoice_notified' );
        if ( $already ) {
            return;
        }

        wcup_notifications::add( $user_id, array(
            'type'    => 'invoice',
            'title'   => 'فاکتور شما صادر شد 🧾',
            'message' => 'فاکتور سفارش #' . $order->get_order_number() . ' با شمارهٔ «' . $number . '» صادر شد. می‌تونی از صفحهٔ سفارش، فاکتور رو مشاهده یا چاپ کنی.',
            'link'    => $this->get_invoice_url( $order ),
            'icon'    => 'system',
        ) );

        $order->update_meta_data( '_wcup_invoice_notified', current_time( 'mysql' ) );
        $order->save();
    }

    /* ============================================================
     *  سال شمسی (تقریبی)
     * ============================================================ */
    private function to_jalali_year( $year_greg ) {
        $month = (int) current_time( 'm' );
        return ( $month < 3 ) ? ( (int) $year_greg - 622 ) : ( (int) $year_greg - 621 );
    }

    /* ============================================================
     *  Idempotent
     * ============================================================ */
    public function ensure_invoice_number( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order ) return;
        if ( $order->get_meta( self::META_NUMBER ) ) return;
        $this->get_invoice_number( $order );
    }

    /* ============================================================
     *  URL فاکتور HTML
     * ============================================================ */
    public function get_invoice_url( $order ) {

        if ( ! $order instanceof WC_Order ) {
            return '';
        }

        return add_query_arg(
            'wcup_invoice_html',
            $order->get_id(),
            home_url( '/' )
        );
    }

    /* ============================================================
     *  یه نمونه سفارش برای پیش‌نمایش
     * ============================================================ */
    public function get_sample_order_id() {

        $orders = wc_get_orders( array(
            'limit'   => 1,
            'orderby' => 'date',
            'order'   => 'DESC',
            'status'  => array( 'processing', 'completed' ),
        ) );

        return ! empty( $orders ) ? $orders[0]->get_id() : 0;
    }

    /* ============================================================
     *  پردازش HTML
     * ============================================================ */
    public function handle_html() {

        if ( ! isset( $_GET['wcup_invoice_html'] ) ) {
            return;
        }

        if ( ! is_user_logged_in() ) {
            wp_die( 'برای مشاهدهٔ فاکتور باید وارد شوید.' );
        }

        $order_id = (int) $_GET['wcup_invoice_html'];

        if ( ! $order_id ) {
            wp_die( 'شمارهٔ سفارش نامعتبر.' );
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            wp_die( 'سفارش پیدا نشد.' );
        }

        /* دسترسی: مالک یا ادمین */
        $user_id = get_current_user_id();
        if ( $order->get_customer_id() !== $user_id && ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( 'شما دسترسی به این فاکتور ندارید.' );
        }

        if ( ! $this->can_download( $order ) ) {
            wp_die( 'فاکتور این سفارش قابل مشاهده نیست.' );
        }

        $invoice_number = $this->get_invoice_number( $order );

        $auto_print = ! empty( $_GET['print'] );

        $this->render_html_preview( $order, $invoice_number, $auto_print );
        exit;
    }

    /* ============================================================
     *  نمایش HTML فاکتور
     * ============================================================ */
    private function render_html_preview( $order, $invoice_number, $auto_print = false ) {

        $html = $this->render_html( $order, $invoice_number );

        /* ═══════════════════════════════════════════════════════
         *  ⭐ فونت از قالب سایت
         * ========================================================
         */
        $fonts_base = content_url( '/uploads/2025/03/' );

        $custom_fonts_base = wcup_settings::get( 'invoice_fonts_base', '' );
        if ( $custom_fonts_base ) {
            $fonts_base = $custom_fonts_base;
        }

        $fonts_base = trailingslashit( $fonts_base );

        $font_face_css = '';

        $font_weights = array(
            'Regular'   => 400,
            'Medium'    => 500,
            'SemiBold'  => 600,
            'Bold'      => 700,
            'ExtraBold' => 800,
        );

        foreach ( $font_weights as $weight_name => $weight_value ) {
            $font_face_css .= "@font-face{";
            $font_face_css .= "font-family:'PeydaWebFaNum';";
            $font_face_css .= "src:url('{$fonts_base}PeydaWebFaNum-{$weight_name}.woff2') format('woff2');";
            $font_face_css .= "font-weight:{$weight_value};font-style:normal;font-display:swap;";
            $font_face_css .= "}";
        }

        echo '<!DOCTYPE html>';
        echo '<html dir="rtl" lang="fa">';
        echo '<head>';
        echo '<meta charset="UTF-8">';
        echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
        echo '<title>فاکتور ' . esc_html( $invoice_number ) . ' - ' . esc_html( get_bloginfo( 'name' ) ) . '</title>';
        echo '<style>' . $font_face_css . '</style>';
        echo '<style>
            html, body {
                background: #f0f2f5;
                padding: 20px;
                margin: 0;
                direction: rtl;
                font-family: "PeydaWebFaNum", "Peyda", -apple-system, Tahoma, sans-serif;
            }
            .wcup-print-toolbar {
                max-width: 800px;
                margin: 0 auto 20px;
                padding: 20px 24px;
                background: #fff;
                border-radius: 14px;
                box-shadow: 0 4px 20px -8px rgba(0,39,54,.08);
                display: flex;
                align-items: center;
                gap: 14px;
                flex-wrap: wrap;
                direction: rtl;
                font-family: "PeydaWebFaNum", "Peyda", -apple-system, Tahoma, sans-serif;
            }
            .wcup-print-toolbar-text {
                flex: 1;
                min-width: 200px;
                color: #002736;
                font-size: 14px;
                line-height: 1.8;
            }
            .wcup-print-toolbar-text strong {
                display: block;
                font-size: 15px;
                margin-bottom: 4px;
            }
            .wcup-print-toolbar-text span {
                color: #7C8289;
                font-size: 12.5px;
            }
            .wcup-print-btn {
                padding: 12px 28px;
                background: #3897A9;
                color: #fff !important;
                border: 0;
                border-radius: 10px;
                font-family: inherit;
                font-size: 14px;
                font-weight: 800;
                cursor: pointer;
                text-decoration: none;
                display: inline-flex;
                align-items: center;
                gap: 8px;
                line-height: 1;
                transition: all .15s;
            }
            .wcup-print-btn:hover {
                background: #004151;
                transform: translateY(-1px);
            }
            @media print {
                html, body { background: #fff !important; padding: 0 !important; margin: 0 !important; }
                .wcup-print-toolbar { display: none !important; }
                .wcup-inv { box-shadow: none !important; margin: 0 !important; max-width: 100% !important; }
                @page { margin: 10mm; size: A4; }
            }
        </style>';
        echo '</head>';
        echo '<body>';

        echo '<div class="wcup-print-toolbar">';
        echo '<div class="wcup-print-toolbar-text">';
        echo '<strong>📄 فاکتور شما آماده است</strong>';
        echo '<span>برای ذخیره به‌صورت PDF، روی «ذخیره PDF» کلیک کن و در پنجرهٔ چاپ، «Save as PDF» را انتخاب کن.</span>';
        echo '</div>';
        echo '<button type="button" class="wcup-print-btn" onclick="window.print()">';
        echo '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9V2h12v7"></path><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>';
        echo 'ذخیره PDF';
        echo '</button>';
        echo '</div>';

        echo $html;

        if ( $auto_print ) {
            echo '<script>
                window.addEventListener("load", function() {
                    setTimeout(function() {
                        window.print();
                    }, 500);
                });
            </script>';
        }

        echo '</body>';
        echo '</html>';
    }

    /* ============================================================
     *  رندر HTML فاکتور
     * ============================================================ */
    public function render_html( $order, $invoice_number = '' ) {

        if ( ! $order instanceof WC_Order ) {
            return '';
        }

        if ( ! $invoice_number ) {
            $invoice_number = $this->get_invoice_number( $order );
        }

        $css = $this->get_css();

        $vars = $this->prepare_template_vars( $order, $invoice_number );
        $vars['css'] = $css;

        $template = WCUP_PATH . 'templates/invoice/invoice-html.php';

        if ( ! file_exists( $template ) ) {
            return '<div style="padding:40px;text-align:center;color:#c0392b;">قالب فاکتور پیدا نشد.</div>';
        }

        ob_start();
        extract( $vars );
        include $template;
        return ob_get_clean();
    }

    public function render_invoices_endpoint() {

        $template = locate_template( 'woocommerce/myaccount/invoices.php' );

        if ( $template ) {
            include $template;
            return;
        }

        echo '<div style="padding:30px;background:#fdecec;border-radius:16px;color:#c0392b;text-align:center;">';
        echo '<strong>⚠️ قالب فاکتورها پیدا نشد</strong>';
        echo '<p style="margin-top:8px;">فایل <code>woocommerce/myaccount/invoices.php</code> رو بساز.</p>';
        echo '</div>';
    }
	
    /* ============================================================
     *  CSS
     * ============================================================ */
    public function get_css() {

        $css_file = WCUP_PATH . 'templates/invoice/invoice.css';

        if ( ! file_exists( $css_file ) ) {
            return '';
        }

        return file_get_contents( $css_file );
    }

    /* ============================================================
     *  آماده‌سازی متغیرها
     * ============================================================ */
    private function prepare_template_vars( $order, $invoice_number ) {

        /* ─── آیتم‌ها ─── */
        $items = array();
        foreach ( $order->get_items() as $item_id => $item ) {

            $product = $item->get_product();
            $qty     = $item->get_quantity();
            $total   = (float) $item->get_total();

            $meta_html = wc_display_item_meta( $item, array(
                'before'    => '',
                'after'     => '',
                'separator' => '<br>',
                'echo'      => false,
            ) );

            /* ⭐ عکس محصول */
            $img_url = '';
            if ( $product ) {
                $img_id = $product->get_image_id();
                if ( $img_id ) {
                    $img_url = wp_get_attachment_image_url( $img_id, 'thumbnail' );
                }
            }
            if ( ! $img_url ) {
                $img_url = wc_placeholder_img_src( 'thumbnail' );
            }

            $items[] = array(
                'name'     => $item->get_name(),
                'qty'      => $qty,
                'subtotal' => (float) $item->get_subtotal(),
                'total'    => $total,
                'sku'      => $product ? $product->get_sku() : '',
                'meta'     => $meta_html,
                'img'      => $img_url,
            );
        }

        /* ─── آدرس ─── */
        $billing_name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );

        $billing_address = array_filter( array(
            $order->get_billing_address_1(),
            $order->get_billing_address_2(),
            $order->get_billing_city(),
            $order->get_billing_state(),
            $order->get_billing_postcode(),
        ) );

        /* ─── تاریخ ─── */
        $date_created = $order->get_date_created();
        $date_str     = $date_created ? date_i18n( 'j F Y - H:i', $date_created->getTimestamp() ) : '—';

        /* ─── وضعیت ─── */
        $status_labels = wc_get_order_statuses();
        $status_label  = $status_labels[ 'wc-' . $order->get_status() ] ?? $order->get_status();

        /* ─── QR ─── */
        $verify_url = add_query_arg( 'wcup_verify_invoice', $order->get_order_key(), home_url( '/' ) );
        $qr_url     = 'https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=' . rawurlencode( $verify_url );

        /* ─── لوگو — اولویت: تنظیمات ادمین → لوگوی سایت ─── */
        $logo_url = '';

        $custom_logo_id = (int) wcup_settings::get( 'invoice_logo_id', 0 );
        if ( $custom_logo_id ) {
            $logo_url = wp_get_attachment_image_url( $custom_logo_id, 'medium' );
        }

        if ( ! $logo_url ) {
            $theme_logo_id = get_theme_mod( 'custom_logo' );
            $logo_url = $theme_logo_id ? wp_get_attachment_image_url( $theme_logo_id, 'medium' ) : '';
        }

        /* ─── متن‌ها و نمایش‌ها از تنظیمات ─── */
        $invoice_thanks_text   = wcup_settings::get( 'invoice_thanks_text',   'از خرید شما سپاسگزاریم' );
        $invoice_footer_note   = wcup_settings::get( 'invoice_footer_note',   'این فاکتور به‌صورت خودکار توسط سیستم تولید شده است.' );
        $invoice_terms_text    = wcup_settings::get( 'invoice_terms_text',    '' );
        $invoice_show_qr       = (int) wcup_settings::get( 'invoice_show_qr',       1 );
        $invoice_show_tracking = (int) wcup_settings::get( 'invoice_show_tracking', 1 );
        $invoice_show_terms    = (int) wcup_settings::get( 'invoice_show_terms',    1 );

        /* ─── فروشگاه ─── */
        $shop_name  = get_bloginfo( 'name' );
        $shop_phone = get_option( 'woocommerce_store_phone', '' );
        $shop_email = get_option( 'woocommerce_store_email', get_option( 'admin_email' ) );

        $store_address  = get_option( 'woocommerce_store_address' );
        $store_city     = get_option( 'woocommerce_store_city' );
        $store_postcode = get_option( 'woocommerce_store_postcode' );

        $shop_address = $store_address
            ? trim( $store_address . ' - ' . $store_city . ' - ' . $store_postcode )
            : '';

        /* ─── اعداد فارسی ─── */
        $fa = function ( $num ) {
            return wcup_helpers::fa_num( $num );
        };

        return array(
            'order'                 => $order,
            'invoice_number'        => $invoice_number,
            'invoice_date'          => $order->get_meta( self::META_DATE ) ?: $date_str,
            'date_str'              => $date_str,
            'status_label'          => $status_label,
            'items'                 => $items,
            'billing_name'          => $billing_name,
            'billing_phone'         => $order->get_billing_phone(),
            'billing_email'         => $order->get_billing_email(),
            'billing_address'       => implode( '، ', $billing_address ),
            'billing_company'       => $order->get_billing_company(),
            'coupons'               => $order->get_coupon_codes(),
            'subtotal'              => (float) $order->get_subtotal(),
            'discount'              => (float) $order->get_discount_total(),
            'shipping'              => (float) $order->get_shipping_total(),
            'tax'                   => (float) $order->get_total_tax(),
            'total'                 => (float) $order->get_total(),
            'formatted_total'       => $order->get_formatted_order_total(),
            'payment_method'        => $order->get_payment_method_title(),
            'transaction_id'        => $order->get_transaction_id(),
            'tracking_code'         => $order->get_meta( '_wcup_tracking_code' ),
            'tracking_carrier'      => $order->get_meta( '_wcup_tracking_carrier' ),
            'verify_url'            => $verify_url,
            'qr_url'                => $qr_url,
            'logo_url'              => $logo_url,
            'shop_name'             => $shop_name,
            'shop_phone'            => $shop_phone,
            'shop_email'            => $shop_email,
            'shop_address'          => $shop_address,
            'invoice_thanks_text'   => $invoice_thanks_text,
            'invoice_footer_note'   => $invoice_footer_note,
            'invoice_terms_text'    => $invoice_terms_text,
            'invoice_show_qr'       => $invoice_show_qr,
            'invoice_show_tracking' => $invoice_show_tracking,
            'invoice_show_terms'    => $invoice_show_terms,
            'fa'                    => $fa,
            'css'                   => $this->get_css(),
        );
    }

    /* ============================================================
     *  ستون لیست سفارشات ادمین
     * ============================================================ */
    public function admin_column_header( $columns ) {

        if ( ! $this->is_enabled() ) {
            return $columns;
        }

        $new_columns = array();

        foreach ( $columns as $key => $label ) {
            $new_columns[ $key ] = $label;
            if ( 'order_status' === $key || 'wc_actions' === $key ) {
                $new_columns['wcup_invoice'] = 'فاکتور';
            }
        }

        if ( ! isset( $new_columns['wcup_invoice'] ) ) {
            $new_columns['wcup_invoice'] = 'فاکتور';
        }

        return $new_columns;
    }

    public function admin_column_content( $column, $order_id ) {

        if ( 'wcup_invoice' !== $column ) {
            return;
        }

        $order = wc_get_order( $order_id );

        if ( ! $order || ! $this->can_download( $order ) ) {
            echo '<span style="opacity:.3;">—</span>';
            return;
        }

        $invoice_url = $this->get_invoice_url( $order );
        $invoice_no  = $order->get_meta( self::META_NUMBER );

        if ( ! $invoice_no ) {
            $invoice_no = $this->get_invoice_number( $order );
        }

        printf(
            '<a href="%s" target="_blank" rel="noopener" title="مشاهدهٔ فاکتور %s" style="display:inline-flex;align-items:center;gap:4px;padding:4px 8px;background:#f0f8fa;color:#3897A9;border:1px solid #3897A9;border-radius:6px;text-decoration:none;font-size:11px;font-weight:700;line-height:1;">📄 <span>مشاهده</span></a>',
            esc_url( $invoice_url ),
            esc_attr( $invoice_no )
        );
    }

    /* ============================================================
     *  باکس در صفحهٔ سفارش ادمین
     * ============================================================ */
    public function render_admin_order_box( $order ) {

        if ( ! $order instanceof WC_Order || ! $this->is_enabled() ) {
            return;
        }

        $invoice_no  = $order->get_meta( self::META_NUMBER );
        $invoice_url = $this->get_invoice_url( $order );
        $can_view    = $this->can_download( $order );
        ?>
        <div class="wcup-admin-invoice-box" style="clear:both;margin-top:20px;padding:16px 20px;background:#f0f8fa;border:1px solid rgba(56,151,169,.25);border-radius:12px;">
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                <span style="font-size:22px;">📄</span>
                <div style="flex:1;min-width:200px;">
                    <strong style="display:block;color:#002736;font-size:14px;margin-bottom:2px;">فاکتور سفارش</strong>
                    <span style="color:#7C8289;font-size:12px;">
                        <?php if ( $invoice_no ) : ?>
                            شمارهٔ فاکتور: <code style="background:#fff;padding:2px 6px;border-radius:4px;font-weight:700;color:#3897A9;"><?php echo esc_html( $invoice_no ); ?></code>
                        <?php else : ?>
                            هنوز شماره‌ای صادر نشده
                        <?php endif; ?>
                    </span>
                </div>
                <?php if ( $can_view ) : ?>
                    <a href="<?php echo esc_url( $invoice_url ); ?>" target="_blank" rel="noopener" class="button button-primary" style="padding:8px 18px;background:#3897A9;color:#fff;border:0;border-radius:8px;font-weight:700;font-size:12px;text-decoration:none;line-height:1;display:inline-flex;align-items:center;gap:6px;">👁️ مشاهدهٔ فاکتور</a>
                    <a href="<?php echo esc_url( add_query_arg( 'print', '1', $invoice_url ) ); ?>" target="_blank" rel="noopener" class="button" style="padding:8px 18px;background:#fff;color:#3897A9;border:1px solid #3897A9;border-radius:8px;font-weight:700;font-size:12px;text-decoration:none;line-height:1;display:inline-flex;align-items:center;gap:6px;">🖨️ چاپ</a>
                <?php else : ?>
                    <span style="padding:8px 14px;background:#fff;color:#7C8289;border:1px dashed #e5eaed;border-radius:8px;font-size:11px;font-weight:600;">⏳ فقط برای سفارشات در حال انجام یا تکمیل‌شده</span>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    /* ============================================================
     *  اعتبارسنجی فاکتور
     * ============================================================ */
    public function handle_verify() {

        if ( ! isset( $_GET['wcup_verify_invoice'] ) ) {
            return;
        }

        $order_key = sanitize_text_field( $_GET['wcup_verify_invoice'] );

        if ( ! $order_key ) {
            wp_die( 'کد اعتبارسنجی نامعتبر.' );
        }

        $orders = wc_get_orders( array(
            'limit'      => 1,
            'orderby'    => 'date',
            'order'      => 'DESC',
            'meta_key'   => '_order_key',
            'meta_value' => $order_key,
            'status'     => 'any',
        ) );

        $order = ! empty( $orders ) ? $orders[0] : null;

        ?>
        <!DOCTYPE html>
        <html dir="rtl" lang="fa">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>اعتبارسنجی فاکتور</title>
            <style>
                body { font-family: -apple-system, Tahoma, "PeydaWebFaNum", sans-serif; background: #f0f2f5; padding: 40px 20px; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
                .box { max-width: 500px; width: 100%; background: #fff; border-radius: 20px; padding: 40px 32px; box-shadow: 0 20px 60px -20px rgba(0,39,54,.15); text-align: center; }
                .icon { width: 80px; height: 80px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 40px; margin-bottom: 20px; }
                .icon.ok { background: rgba(0,136,105,.12); color: #008869; }
                .icon.fail { background: rgba(243,71,71,.12); color: #F34747; }
                h1 { font-size: 22px; color: #002736; margin: 0 0 12px; }
                p { color: #7C8289; font-size: 14px; line-height: 1.9; margin: 0 0 20px; }
                .details { text-align: right; background: #f0f2f5; padding: 20px; border-radius: 14px; margin-top: 20px; }
                .row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #e5eaed; font-size: 13px; }
                .row:last-child { border-bottom: 0; }
                .row .label { color: #7C8289; font-weight: 600; }
                .row .value { color: #002736; font-weight: 800; }
                .btn { display: inline-block; margin-top: 20px; padding: 12px 28px; background: #3897A9; color: #fff !important; border-radius: 10px; text-decoration: none; font-weight: 800; font-size: 13px; }
            </style>
        </head>
        <body>
            <div class="box">

                <?php if ( $order ) : ?>

                    <div class="icon ok">✓</div>
                    <h1>فاکتور معتبر است</h1>
                    <p>این فاکتور توسط سیستم ما تأیید شده و معتبر است.</p>

                    <div class="details">
                        <div class="row">
                            <span class="label">شمارهٔ سفارش:</span>
                            <span class="value">#<?php echo esc_html( wcup_helpers::fa_num( $order->get_order_number() ) ); ?></span>
                        </div>
                        <div class="row">
                            <span class="label">شمارهٔ فاکتور:</span>
                            <span class="value"><?php echo esc_html( $order->get_meta( self::META_NUMBER ) ?: '—' ); ?></span>
                        </div>
                        <div class="row">
                            <span class="label">تاریخ:</span>
                            <span class="value">
                                <?php
                                $d = $order->get_date_created();
                                echo esc_html( $d ? wcup_helpers::fa_num( date_i18n( 'j F Y', $d->getTimestamp() ) ) : '—' );
                                ?>
                            </span>
                        </div>
                        <div class="row">
                            <span class="label">مبلغ:</span>
                            <span class="value"><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></span>
                        </div>
                    </div>

                <?php else : ?>

                    <div class="icon fail">✕</div>
                    <h1>فاکتور نامعتبر است</h1>
                    <p>کد اعتبارسنجی نامعتبر است یا فاکتور پیدا نشد.</p>

                <?php endif; ?>

                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn">بازگشت به سایت</a>

            </div>
        </body>
        </html>
        <?php
        exit;
    }

    /* ============================================================
     *  ایمیل بعد از تکمیل
     * ============================================================ */
    public function on_order_completed( $order_id ) {

        if ( ! wcup_settings::get( 'invoice_email_on_complete', 1 ) ) {
            return;
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) return;

        $email = $order->get_billing_email();
        if ( ! $email ) return;

        $invoice_number = $this->get_invoice_number( $order );
        $invoice_url    = $this->get_invoice_url( $order );

        $subject = 'فاکتور سفارش #' . $order->get_order_number() . ' - ' . get_bloginfo( 'name' );

        $message  = "سلام " . $order->get_billing_first_name() . "\n\n";
        $message .= "سفارش شما با موفقیت تکمیل شد.\n\n";
        $message .= "شمارهٔ فاکتور: " . $invoice_number . "\n";
        $message .= "شمارهٔ سفارش: #" . $order->get_order_number() . "\n\n";
        $message .= "برای مشاهدهٔ فاکتور:\n" . $invoice_url . "\n\n";
        $message .= "با تشکر\n" . get_bloginfo( 'name' );

        wp_mail( $email, $subject, $message );
    }
}