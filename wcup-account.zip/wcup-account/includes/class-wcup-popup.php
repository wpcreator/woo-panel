<?php
/**
 * WCUP Popup — تبدیل پیام‌های ووکامرس به Modal Popup
 * ============================================================
 *  بخش ۱۴ از فایل قدیمی
 *
 *  @package WCUP_Account
 *  @version 1.0.0
 * ============================================================
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_popup' ) ) {
    return;
}

class wcup_popup {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'wp_footer', array( $this, 'render_script' ), 100 );
    }

    /* ============================================================
     *  شرط نمایش
     * ============================================================ */
    private function should_load() {

        if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
            return false;
        }

        if ( ! wcup_settings::get( 'popup_notices', 1 ) ) {
            return false;
        }

        return true;
    }

    /* ============================================================
     *  رندر اسکریپت
     * ============================================================ */
    public function render_script() {

        if ( ! $this->should_load() ) {
            return;
        }
        ?>
        <script>
        (function () {
            'use strict';

            var POPUP_DURATION = 5000;
            var overlay, stack;

            function getOverlay() {
                if (!overlay) {
                    overlay = document.querySelector('.woocommerce-notices-wrapper');
                    if (!overlay) {
                        overlay = document.createElement('div');
                        overlay.className = 'woocommerce-notices-wrapper';
                        document.body.appendChild(overlay);
                    }
                }
                return overlay;
            }

            function getStack() {
                var ov = getOverlay();
                var s  = ov.querySelector('.wcup-popup-stack');
                if (!s) {
                    s = document.createElement('div');
                    s.className = 'wcup-popup-stack';
                    ov.appendChild(s);
                }
                return s;
            }

            function getIcon(type) {
                var icons = {
                    success: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
                    error:   '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
                    info:    '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>'
                };
                return icons[type] || icons.info;
            }

            function detectType(el) {
                if (el.classList.contains('woocommerce-message')) return 'success';
                if (el.classList.contains('woocommerce-error'))   return 'error';
                if (el.classList.contains('woocommerce-info'))    return 'info';
                return 'info';
            }

            function createPopup(element) {
                var type = detectType(element);
                var html = element.innerHTML;

                html = html.replace(/<svg[^>]*class="[^"]*woocommerce[^"]*"[^>]*>[\s\S]*?<\/svg>/gi, '');
                html = html.replace(/<span[^>]*class="[^"]*woocommerce-message[^"]*"[^>]*>[\s\S]*?<\/span>/gi, '');

                var popup = document.createElement('div');
                popup.className = 'wcup-popup-notice wcup-popup-notice--' + type;
                popup.style.setProperty('--wcup-popup-duration', POPUP_DURATION + 'ms');

                popup.innerHTML =
                    '<span class="wcup-popup-icon">' + getIcon(type) + '</span>' +
                    '<div class="wcup-popup-text">' + html + '</div>' +
                    '<button type="button" class="wcup-popup-close" aria-label="بستن">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
                            '<line x1="18" y1="6" x2="6" y2="18"></line>' +
                            '<line x1="6" y1="6" x2="18" y2="18"></line>' +
                        '</svg>' +
                    '</button>' +
                    '<div class="wcup-popup-progress"></div>';

                return popup;
            }

            function closePopup(popup) {
                if (!popup || popup.classList.contains('is-closing')) return;
                popup.classList.add('is-closing');
                popup.addEventListener('animationend', function () {
                    if (popup.parentNode) popup.parentNode.removeChild(popup);
                    checkOverlay();
                }, { once: true });
            }

            function checkOverlay() {
                var s = getOverlay().querySelector('.wcup-popup-stack');
                if (!s) return;
                var remaining = s.querySelectorAll('.wcup-popup-notice:not(.is-closing)');
                if (remaining.length === 0) {
                    getOverlay().classList.remove('is-active');
                    setTimeout(function () {
                        var ov = getOverlay();
                        var st = ov.querySelector('.wcup-popup-stack');
                        if (st && st.querySelectorAll('.wcup-popup-notice').length === 0) {
                            st.remove();
                        }
                    }, 300);
                }
            }

            function setupPopup(popup) {
                var closeBtn = popup.querySelector('.wcup-popup-close');
                if (closeBtn) {
                    closeBtn.addEventListener('click', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        closePopup(popup);
                    });
                }

                var timer = setTimeout(function () {
                    closePopup(popup);
                }, POPUP_DURATION);

                popup.addEventListener('mouseenter', function () {
                    clearTimeout(timer);
                    var p = popup.querySelector('.wcup-popup-progress');
                    if (p) p.style.animationPlayState = 'paused';
                });

                popup.addEventListener('mouseleave', function () {
                    var p = popup.querySelector('.wcup-popup-progress');
                    if (p) p.style.animationPlayState = 'running';
                    timer = setTimeout(function () {
                        closePopup(popup);
                    }, 1500);
                });
            }

            function bindOverlayClick() {
                var ov = getOverlay();
                if (ov.dataset.wcupClickBound === '1') return;
                ov.dataset.wcupClickBound = '1';

                ov.addEventListener('click', function (e) {
                    if (e.target === ov) {
                        var s = ov.querySelector('.wcup-popup-stack');
                        if (s) s.querySelectorAll('.wcup-popup-notice:not(.is-closing)').forEach(closePopup);
                    }
                });

                document.addEventListener('keydown', function (e) {
                    if (e.key === 'Escape') {
                        var s = ov.querySelector('.wcup-popup-stack');
                        if (s) s.querySelectorAll('.wcup-popup-notice:not(.is-closing)').forEach(closePopup);
                    }
                });
            }

            function processNotices() {
                var notices = document.querySelectorAll(
                    '.woocommerce-message, .woocommerce-error, .woocommerce-info, .woocommerce-notice'
                );

                if (!notices.length) return;

                var pending = [];

                notices.forEach(function (notice) {
                    if (notice.closest('.woocommerce-notices-wrapper')) return;
                    if (notice.dataset.wcupProcessed === '1') return;

                    notice.dataset.wcupProcessed = '1';
                    pending.push(notice);
                });

                if (!pending.length) return;

                var ov = getOverlay();
                var st = getStack();
                ov.classList.add('is-active');
                bindOverlayClick();

                pending.forEach(function (notice) {
                    var popup = createPopup(notice);
                    notice.style.display = 'none';
                    notice.style.visibility = 'hidden';
                    st.appendChild(popup);
                    setupPopup(popup);
                });
            }

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', function () {
                    setTimeout(processNotices, 100);
                });
            } else {
                setTimeout(processNotices, 100);
            }

            var observer = new MutationObserver(function (mutations) {
                var hasNew = false;
                mutations.forEach(function (m) {
                    if (m.addedNodes.length) {
                        m.addedNodes.forEach(function (node) {
                            if (node.nodeType === 1) {
                                if (node.matches && (
                                    node.matches('.woocommerce-message, .woocommerce-error, .woocommerce-info') ||
                                    (node.querySelector && node.querySelector('.woocommerce-message, .woocommerce-error, .woocommerce-info'))
                                )) {
                                    hasNew = true;
                                }
                            }
                        });
                    }
                });
                if (hasNew) {
                    setTimeout(processNotices, 100);
                }
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });

        })();
        </script>
        <?php
    }
}