<?php
defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_reviews' ) ) {
    return;
}

class wcup_reviews {

    const ENDPOINT = 'reviews';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', array( $this, 'render_endpoint' ) );
        add_filter( 'woocommerce_endpoint_' . self::ENDPOINT . '_title', array( $this, 'endpoint_title' ) );
        add_action( 'after_switch_theme', array( $this, 'flush_rewrite' ) );
    }

    public function render_endpoint() {
        $template = locate_template( 'woocommerce/myaccount/reviews.php' );
        if ( $template ) {
            include $template;
            return;
        }
        wc_get_template( 'myaccount/reviews.php' );
    }

    public function endpoint_title( $title ) {
        return wcup_settings::get( 'label_reviews', 'نظرات شما' );
    }

    public function flush_rewrite() {
        flush_rewrite_rules();
    }
}