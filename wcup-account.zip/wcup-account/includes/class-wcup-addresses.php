<?php
/**
 * WCUP Addresses — آدرس‌های متعدد
 * ============================================================
 *  @package WCUP_Account
 *  @version 1.0.0
 * ============================================================
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_addresses' ) ) {
    return;
}

class wcup_addresses {

    const META_KEY   = '_wcup_addresses';
    const NONCE_KEY  = 'wcup_addresses_nonce';

    /* Sync keys (WC meta) */
    const SYNC_BILLING = array(
        'first_name' => 'billing_first_name',
        'last_name'  => 'billing_last_name',
        'company'    => 'billing_company',
        'phone'      => 'billing_phone',
        'email'      => 'billing_email',
        'country'    => 'billing_country',
        'state'      => 'billing_state',
        'city'       => 'billing_city',
        'address_1'  => 'billing_address_1',
        'address_2'  => 'billing_address_2',
        'postcode'   => 'billing_postcode',
    );

    const SYNC_SHIPPING = array(
        'first_name' => 'shipping_first_name',
        'last_name'  => 'shipping_last_name',
        'company'    => 'shipping_company',
        'country'    => 'shipping_country',
        'state'      => 'shipping_state',
        'city'       => 'shipping_city',
        'address_1'  => 'shipping_address_1',
        'address_2'  => 'shipping_address_2',
        'postcode'   => 'shipping_postcode',
    );

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {

        /* Endpoint */
        add_action( 'woocommerce_account_addresses_endpoint', array( $this, 'render_endpoint' ) );

        /* AJAX */
        add_action( 'wp_ajax_wcup_address_save',   array( $this, 'ajax_save' ) );
        add_action( 'wp_ajax_wcup_address_delete', array( $this, 'ajax_delete' ) );
        add_action( 'wp_ajax_wcup_address_set_default', array( $this, 'ajax_set_default' ) );

        /* قبل از checkout، آدرس پیش‌فرض رو sync کن (اگه هنوز ست نشده) */
        add_action( 'woocommerce_before_checkout_form', array( $this, 'maybe_prefill_checkout' ), 5 );
    }

    /* ============================================================
     *  آیا فعاله؟
     * ============================================================ */
    public function is_enabled() {
        return (bool) wcup_settings::get( 'addresses_enabled', 1 );
    }

    /* ============================================================
     *  گرفتن همهٔ آدرس‌ها
     * ============================================================ */
    public static function get_all( $user_id = 0 ) {

        if ( ! $user_id ) {
            $user_id = get_current_user_id();
        }

        if ( ! $user_id ) {
            return array();
        }

        $list = get_user_meta( $user_id, self::META_KEY, true );

        if ( ! is_array( $list ) ) {
            return array();
        }

        return array_values( $list );
    }

    /* ============================================================
     *  گرفتن یک آدرس با ID
     * ============================================================ */
    public static function get( $user_id, $address_id ) {

        if ( ! $user_id || ! $address_id ) {
            return null;
        }

        $list = self::get_all( $user_id );

        foreach ( $list as $addr ) {
            if ( isset( $addr['id'] ) && $addr['id'] === $address_id ) {
                return $addr;
            }
        }

        return null;
    }

    /* ============================================================
     *  آدرس پیش‌فرض
     * ============================================================ */
    public static function get_default( $user_id, $type = 'billing' ) {

        if ( ! $user_id ) {
            return null;
        }

        $flag  = ( 'shipping' === $type ) ? 'is_default_shipping' : 'is_default_billing';
        $list  = self::get_all( $user_id );

        foreach ( $list as $addr ) {
            if ( ! empty( $addr[ $flag ] ) ) {
                return $addr;
            }
        }

        return null;
    }

    /* ============================================================
     *  شمارش
     * ============================================================ */
    public static function count( $user_id = 0 ) {
        return count( self::get_all( $user_id ) );
    }

    /* ============================================================
     *  ذخیرهٔ همه
     * ============================================================ */
    private static function save_all( $user_id, $addresses ) {
        update_user_meta( $user_id, self::META_KEY, array_values( $addresses ) );
    }

    /* ============================================================
     *  افزودن آدرس
     * ============================================================ */
    public static function add( $user_id, $data ) {

        if ( ! $user_id ) {
            return new WP_Error( 'no_user', 'کاربر نامعتبر.' );
        }

        $max = (int) wcup_settings::get( 'addresses_max', 10 );
        $current = self::count( $user_id );

        if ( $current >= $max ) {
            return new WP_Error( 'max_addresses', sprintf( 'حداکثر %d آدرس مجاز است.', $max ) );
        }

        $sanitized = self::sanitize( $data );

        if ( empty( $sanitized['first_name'] ) || empty( $sanitized['last_name'] ) ) {
            return new WP_Error( 'missing_name', 'نام و نام خانوادگی الزامی است.' );
        }

        if ( empty( $sanitized['address_1'] ) ) {
            return new WP_Error( 'missing_address', 'آدرس الزامی است.' );
        }

        if ( empty( $sanitized['city'] ) ) {
            return new WP_Error( 'missing_city', 'شهر الزامی است.' );
        }

        if ( empty( $sanitized['phone'] ) ) {
            return new WP_Error( 'missing_phone', 'شماره تماس الزامی است.' );
        }

        /* شناسهٔ یکتا */
        $id = 'addr_' . strtolower( wp_generate_password( 8, false, false ) );

        $address = array_merge( $sanitized, array(
            'id'                   => $id,
            'is_default_billing'   => 0,
            'is_default_shipping'  => 0,
            'created_at'           => current_time( 'mysql' ),
        ) );

        $addresses = self::get_all( $user_id );
        $addresses[] = $address;

        /* اگه اولین آدرسه، خودکار پیش‌فرض بشه */
        if ( count( $addresses ) === 1 ) {
            $addresses[0]['is_default_billing']  = 1;
            $addresses[0]['is_default_shipping'] = 1;
        }

        /* اگه کاربر خواست پیش‌فرض باشه */
        if ( ! empty( $data['is_default_billing'] ) ) {
            $addresses = self::set_flag( $addresses, $id, 'is_default_billing' );
        }
        if ( ! empty( $data['is_default_shipping'] ) ) {
            $addresses = self::set_flag( $addresses, $id, 'is_default_shipping' );
        }

        self::save_all( $user_id, $addresses );

        /* Sync به WC */
        self::sync_to_wc( $user_id );

        do_action( 'wcup_address_added', $user_id, $address );

        return $id;
    }

    /* ============================================================
     *  به‌روزرسانی
     * ============================================================ */
    public static function update( $user_id, $address_id, $data ) {

        if ( ! $user_id || ! $address_id ) {
            return new WP_Error( 'invalid', 'اطلاعات نامعتبر.' );
        }

        $addresses = self::get_all( $user_id );
        $found = false;

        $sanitized = self::sanitize( $data );

        foreach ( $addresses as $i => $addr ) {
            if ( $addr['id'] === $address_id ) {
                $addresses[ $i ] = array_merge( $addr, $sanitized );
                $found = true;
                break;
            }
        }

        if ( ! $found ) {
            return new WP_Error( 'not_found', 'آدرس پیدا نشد.' );
        }

        /* پیش‌فرض‌ها */
        if ( ! empty( $data['is_default_billing'] ) ) {
            $addresses = self::set_flag( $addresses, $address_id, 'is_default_billing' );
        }
        if ( ! empty( $data['is_default_shipping'] ) ) {
            $addresses = self::set_flag( $addresses, $address_id, 'is_default_shipping' );
        }

        self::save_all( $user_id, $addresses );
        self::sync_to_wc( $user_id );

        do_action( 'wcup_address_updated', $user_id, $address_id );

        return true;
    }

    /* ============================================================
     *  حذف
     * ============================================================ */
    public static function delete( $user_id, $address_id ) {

        if ( ! $user_id || ! $address_id ) {
            return new WP_Error( 'invalid', 'اطلاعات نامعتبر.' );
        }

        $addresses = self::get_all( $user_id );
        $deleted   = null;

        foreach ( $addresses as $i => $addr ) {
            if ( $addr['id'] === $address_id ) {
                $deleted = $addr;
                unset( $addresses[ $i ] );
                break;
            }
        }

        if ( null === $deleted ) {
            return new WP_Error( 'not_found', 'آدرس پیدا نشد.' );
        }

        $addresses = array_values( $addresses );

        /* اگه آدرس پیش‌فرض بود، به آدرس اول منتقل کن */
        if ( ! empty( $deleted['is_default_billing'] ) && ! empty( $addresses ) ) {
            $addresses[0]['is_default_billing'] = 1;
        }
        if ( ! empty( $deleted['is_default_shipping'] ) && ! empty( $addresses ) ) {
            $addresses[0]['is_default_shipping'] = 1;
        }

        self::save_all( $user_id, $addresses );
        self::sync_to_wc( $user_id );

        do_action( 'wcup_address_deleted', $user_id, $address_id );

        return true;
    }

    /* ============================================================
     *  Set flag (پاک‌سازی بقیه)
     * ============================================================ */
    private static function set_flag( $addresses, $target_id, $flag ) {

        foreach ( $addresses as $i => $addr ) {
            $addresses[ $i ][ $flag ] = ( $addr['id'] === $target_id ) ? 1 : 0;
        }

        return $addresses;
    }

    /* ============================================================
     *  Sanitize
     * ============================================================ */
    private static function sanitize( $data ) {

        $out = array(
            'label'     => '',
            'first_name' => '',
            'last_name'  => '',
            'company'    => '',
            'phone'      => '',
            'email'      => '',
            'country'    => 'IR',
            'state'      => '',
            'city'       => '',
            'address_1'  => '',
            'address_2'  => '',
            'postcode'   => '',
        );

        if ( isset( $data['label'] ) ) {
            $out['label'] = sanitize_text_field( $data['label'] );
            if ( $out['label'] === '' ) {
                $out['label'] = 'آدرس';
            }
        }

        if ( isset( $data['first_name'] ) ) {
            $out['first_name'] = sanitize_text_field( $data['first_name'] );
        }
        if ( isset( $data['last_name'] ) ) {
            $out['last_name'] = sanitize_text_field( $data['last_name'] );
        }
        if ( isset( $data['company'] ) ) {
            $out['company'] = sanitize_text_field( $data['company'] );
        }
        if ( isset( $data['phone'] ) ) {
            $out['phone'] = sanitize_text_field( $data['phone'] );
            /* فقط اعداد و + و - و فاصله */
            $out['phone'] = preg_replace( '/[^0-9\+\-\s]/', '', $out['phone'] );
        }
        if ( isset( $data['email'] ) ) {
            $out['email'] = sanitize_email( $data['email'] );
        }
        if ( isset( $data['country'] ) ) {
            $out['country'] = sanitize_text_field( $data['country'] );
            if ( $out['country'] === '' ) {
                $out['country'] = 'IR';
            }
        }
        if ( isset( $data['state'] ) ) {
            $out['state'] = sanitize_text_field( $data['state'] );
        }
        if ( isset( $data['city'] ) ) {
            $out['city'] = sanitize_text_field( $data['city'] );
        }
        if ( isset( $data['address_1'] ) ) {
            $out['address_1'] = sanitize_textarea_field( $data['address_1'] );
        }
        if ( isset( $data['address_2'] ) ) {
            $out['address_2'] = sanitize_textarea_field( $data['address_2'] );
        }
        if ( isset( $data['postcode'] ) ) {
            $postcode = preg_replace( '/\D/', '', $data['postcode'] );
            $out['postcode'] = $postcode;
        }

        return $out;
    }

    /* ============================================================
     *  Sync به WC meta (برای پیش‌فرض‌ها)
     * ============================================================ */
    public static function sync_to_wc( $user_id ) {

        if ( ! $user_id ) {
            return;
        }

        /* Billing */
        $billing = self::get_default( $user_id, 'billing' );
        if ( $billing ) {
            foreach ( self::SYNC_BILLING as $key => $meta_key ) {
                if ( isset( $billing[ $key ] ) ) {
                    update_user_meta( $user_id, $meta_key, $billing[ $key ] );
                }
            }
        }

        /* Shipping */
        $shipping = self::get_default( $user_id, 'shipping' );
        if ( $shipping ) {
            foreach ( self::SYNC_SHIPPING as $key => $meta_key ) {
                if ( isset( $shipping[ $key ] ) ) {
                    update_user_meta( $user_id, $meta_key, $shipping[ $key ] );
                }
            }
        }
    }

    /* ============================================================
     *  Pre-fill checkout (اگه پیش‌فرض داره ولی WC خالیه)
     * ============================================================ */
    public function maybe_prefill_checkout() {

        if ( ! is_user_logged_in() ) {
            return;
        }

        $user_id = get_current_user_id();

        /* اگه billing خالیه ولی ما پیش‌فرض داریم، sync کن */
        $billing_first = get_user_meta( $user_id, 'billing_first_name', true );

        if ( empty( $billing_first ) ) {
            self::sync_to_wc( $user_id );
        }
    }

    /* ============================================================
     *  رندر endpoint
     * ============================================================ */
    public function render_endpoint() {

        if ( ! $this->is_enabled() ) {
            echo '<div class="wcup-vo-error" style="padding:30px;background:#fdecec;border-radius:16px;color:#c0392b;text-align:center;">';
            echo 'سیستم آدرس‌های متعدد غیرفعال است.';
            echo '</div>';
            return;
        }

        $template = locate_template( 'woocommerce/myaccount/addresses.php' );

        if ( $template ) {
            include $template;
            return;
        }

        echo '<div class="wcup-vo-error" style="padding:30px;background:#fdecec;border-radius:16px;color:#c0392b;text-align:center;">';
        echo 'قالب addresses.php پیدا نشد.';
        echo '</div>';
    }

    /* ============================================================
     *  AJAX: ذخیره
     * ============================================================ */
    public function ajax_save() {

        check_ajax_referer( self::NONCE_KEY, 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
        }

        $user_id    = get_current_user_id();
        $address_id = isset( $_POST['address_id'] ) ? sanitize_text_field( $_POST['address_id'] ) : '';

        $fields = array(
            'label', 'first_name', 'last_name', 'company', 'phone',
            'email', 'country', 'state', 'city', 'address_1', 'address_2', 'postcode',
        );

        $data = array();
        foreach ( $fields as $f ) {
            if ( isset( $_POST[ $f ] ) ) {
                $data[ $f ] = wp_unslash( $_POST[ $f ] );
            }
        }

        $data['is_default_billing']  = ! empty( $_POST['is_default_billing'] );
        $data['is_default_shipping'] = ! empty( $_POST['is_default_shipping'] );

        if ( $address_id ) {
            $result = self::update( $user_id, $address_id, $data );
        } else {
            $result = self::add( $user_id, $data );
        }

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array(
            'message'     => $address_id ? 'آدرس به‌روزرسانی شد.' : 'آدرس با موفقیت اضافه شد.',
            'address_id'  => $address_id ? $address_id : $result,
            'addresses'   => self::get_all( $user_id ),
            'count'       => self::count( $user_id ),
        ) );
    }

    /* ============================================================
     *  AJAX: حذف
     * ============================================================ */
    public function ajax_delete() {

        check_ajax_referer( self::NONCE_KEY, 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
        }

        $user_id    = get_current_user_id();
        $address_id = isset( $_POST['address_id'] ) ? sanitize_text_field( $_POST['address_id'] ) : '';

        if ( ! $address_id ) {
            wp_send_json_error( array( 'message' => 'اطلاعات نامعتبر.' ) );
        }

        $result = self::delete( $user_id, $address_id );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array(
            'message' => 'آدرس حذف شد.',
            'count'   => self::count( $user_id ),
        ) );
    }

    /* ============================================================
     *  AJAX: تنظیم پیش‌فرض
     * ============================================================ */
    public function ajax_set_default() {

        check_ajax_referer( self::NONCE_KEY, 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
        }

        $user_id    = get_current_user_id();
        $address_id = isset( $_POST['address_id'] ) ? sanitize_text_field( $_POST['address_id'] ) : '';
        $type       = isset( $_POST['type'] ) ? sanitize_key( $_POST['type'] ) : 'billing';

        if ( ! $address_id || ! in_array( $type, array( 'billing', 'shipping' ), true ) ) {
            wp_send_json_error( array( 'message' => 'اطلاعات نامعتبر.' ) );
        }

        $addresses = self::get_all( $user_id );
        $flag      = 'is_default_' . $type;
        $found     = false;

        foreach ( $addresses as $i => $addr ) {
            if ( $addr['id'] === $address_id ) {
                $addresses[ $i ][ $flag ] = 1;
                $found = true;
            } else {
                $addresses[ $i ][ $flag ] = 0;
            }
        }

        if ( ! $found ) {
            wp_send_json_error( array( 'message' => 'آدرس پیدا نشد.' ) );
        }

        self::save_all( $user_id, $addresses );
        self::sync_to_wc( $user_id );

        wp_send_json_success( array(
            'message' => ( 'billing' === $type ) ? 'آدرس پیش‌فرض صورتحساب تنظیم شد.' : 'آدرس پیش‌فرض ارسال تنظیم شد.',
        ) );
    }
}