<?php
/**
 * WCUP Notifications — سیستم اعلان‌ها
 * ============================================================
 *  @package WCUP_Account
 *  @version 1.0.0
 * ============================================================
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_notifications' ) ) {
    return;
}

class wcup_notifications {

    const TABLE       = 'wcup_notifications';
    const DB_VERSION  = '1.0.0';
    const NONCE_KEY   = 'wcup_notifications_nonce';
    const PER_PAGE    = 20;

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {

        /* ساخت جدول (فقط یک بار) */
        add_action( 'init', array( $this, 'maybe_install' ), 5 );

        /* Endpoint — رندر توسط همین کلاس */
        add_action( 'woocommerce_account_notifications_endpoint', array( $this, 'render_endpoint' ) );

        /* هوک‌های خودکار */
        add_action( 'woocommerce_order_status_changed', array( $this, 'on_order_status_changed' ), 10, 4 );
        add_action( 'woocommerce_process_shop_order_meta', array( $this, 'on_tracking_saved' ), 20 );
        add_action( 'wp_set_comment_status', array( $this, 'on_comment_approved' ), 10, 2 );

        /* هوک‌های علاقه‌مندی */
        add_action( 'wcup_wishlist_added',   array( $this, 'on_wishlist_added' ), 10, 2 );
        add_action( 'wcup_wishlist_removed', array( $this, 'on_wishlist_removed' ), 10, 2 );

        /* AJAX */
        add_action( 'wp_ajax_wcup_get_notifications',   array( $this, 'ajax_get' ) );
        add_action( 'wp_ajax_wcup_mark_read',           array( $this, 'ajax_mark_read' ) );
        add_action( 'wp_ajax_wcup_mark_all_read',       array( $this, 'ajax_mark_all_read' ) );
        add_action( 'wp_ajax_wcup_delete_notification', array( $this, 'ajax_delete' ) );
        add_action( 'wp_ajax_wcup_delete_all',          array( $this, 'ajax_delete_all' ) );

        /* nonce برای JS */
        add_action( 'wp_footer', array( $this, 'print_nonce' ), 95 );

        /* پاک‌سازی خودکار (cron) */
        add_action( 'wcup_cleanup_notifications', array( $this, 'cleanup_old' ) );
    }

    /* ============================================================
     *  ساخت جدول
     * ============================================================ */
    public function maybe_install() {

        $installed = get_option( 'wcup_notifications_db', '0' );

        if ( version_compare( $installed, self::DB_VERSION, '>=' ) ) {
            /* کرون رو ثبت کن اگه نبود */
            if ( ! wp_next_scheduled( 'wcup_cleanup_notifications' ) ) {
                wp_schedule_event( time() + DAY_IN_SECONDS, 'daily', 'wcup_cleanup_notifications' );
            }
            return;
        }

        $this->install();
    }

    public function install() {

        global $wpdb;

        $table_name      = $wpdb->prefix . self::TABLE;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            type varchar(50) NOT NULL DEFAULT 'system',
            title varchar(255) NOT NULL DEFAULT '',
            message text,
            link varchar(500) DEFAULT '',
            icon varchar(50) DEFAULT '',
            is_read tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            read_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY is_read (is_read),
            KEY created_at (created_at)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );

        update_option( 'wcup_notifications_db', self::DB_VERSION );

        /* ثبت cron */
        if ( ! wp_next_scheduled( 'wcup_cleanup_notifications' ) ) {
            wp_schedule_event( time() + DAY_IN_SECONDS, 'daily', 'wcup_cleanup_notifications' );
        }
    }

    /* ============================================================
     *  ثبت اعلان جدید
     * ============================================================ */
    public static function add( $user_id, $args = array() ) {

        global $wpdb;

        $user_id = (int) $user_id;
        if ( ! $user_id ) {
            return false;
        }

        $defaults = array(
            'type'    => 'system',
            'title'   => '',
            'message' => '',
            'link'    => '',
            'icon'    => '',
        );

        $args = wp_parse_args( $args, $defaults );

        if ( $args['title'] === '' && $args['message'] === '' ) {
            return false;
        }

        $table = $wpdb->prefix . self::TABLE;

        $inserted = $wpdb->insert(
            $table,
            array(
                'user_id'    => $user_id,
                'type'       => sanitize_key( $args['type'] ),
                'title'      => sanitize_text_field( $args['title'] ),
                'message'    => wp_kses_post( $args['message'] ),
                'link'       => esc_url_raw( $args['link'] ),
                'icon'       => sanitize_key( $args['icon'] ),
                'is_read'    => 0,
                'created_at' => current_time( 'mysql' ),
            ),
            array( '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s' )
        );

        return $inserted ? (int) $wpdb->insert_id : false;
    }

    /* ============================================================
     *  دریافت اعلان‌ها
     * ============================================================ */
    public static function get( $user_id, $args = array() ) {

        global $wpdb;

        $defaults = array(
            'limit'     => self::PER_PAGE,
            'offset'    => 0,
            'unread'    => false,
            'type'      => '',
            'order_by'  => 'created_at',
            'order'     => 'DESC',
        );

        $args = wp_parse_args( $args, $defaults );

        $table = $wpdb->prefix . self::TABLE;

        $where = $wpdb->prepare( 'WHERE user_id = %d', $user_id );

        if ( $args['unread'] ) {
            $where .= ' AND is_read = 0';
        }

        if ( $args['type'] ) {
            $where .= $wpdb->prepare( ' AND type = %s', $args['type'] );
        }

        $order_by = in_array( $args['order_by'], array( 'created_at', 'id' ), true ) ? $args['order_by'] : 'created_at';
        $order    = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';

        $limit  = max( 1, (int) $args['limit'] );
        $offset = max( 0, (int) $args['offset'] );

        $query = $wpdb->prepare(
            "SELECT * FROM {$table} {$where} ORDER BY {$order_by} {$order} LIMIT %d OFFSET %d",
            $limit,
            $offset
        );

        return $wpdb->get_results( $query );
    }

    /* ============================================================
     *  شمارش اعلان‌ها
     * ============================================================ */
    public static function count( $user_id, $unread_only = false ) {

        global $wpdb;

        $table = $wpdb->prefix . self::TABLE;

        if ( $unread_only ) {
            return (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND is_read = 0",
                $user_id
            ) );
        }

        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE user_id = %d",
            $user_id
        ) );
    }

    /* ============================================================
     *  علامت‌گذاری خوانده‌شده
     * ============================================================ */
    public static function mark_read( $id, $user_id ) {

        global $wpdb;

        $table = $wpdb->prefix . self::TABLE;

        return $wpdb->update(
            $table,
            array(
                'is_read' => 1,
                'read_at' => current_time( 'mysql' ),
            ),
            array(
                'id'      => (int) $id,
                'user_id' => (int) $user_id,
            ),
            array( '%d', '%s' ),
            array( '%d', '%d' )
        );
    }

    /* ============================================================
     *  همه رو خوانده کن
     * ============================================================ */
    public static function mark_all_read( $user_id ) {

        global $wpdb;

        $table = $wpdb->prefix . self::TABLE;

        return $wpdb->update(
            $table,
            array(
                'is_read' => 1,
                'read_at' => current_time( 'mysql' ),
            ),
            array(
                'user_id' => (int) $user_id,
                'is_read' => 0,
            ),
            array( '%d', '%s' ),
            array( '%d', '%d' )
        );
    }

    /* ============================================================
     *  حذف اعلان
     * ============================================================ */
    public static function delete( $id, $user_id ) {

        global $wpdb;

        $table = $wpdb->prefix . self::TABLE;

        return $wpdb->delete(
            $table,
            array(
                'id'      => (int) $id,
                'user_id' => (int) $user_id,
            ),
            array( '%d', '%d' )
        );
    }

    /* ============================================================
     *  حذف همه
     * ============================================================ */
    public static function delete_all( $user_id ) {

        global $wpdb;

        $table = $wpdb->prefix . self::TABLE;

        return $wpdb->delete(
            $table,
            array( 'user_id' => (int) $user_id ),
            array( '%d' )
        );
    }

    /* ============================================================
     *  پاک‌سازی اعلان‌های قدیمی
     * ============================================================ */
    public function cleanup_old() {

        global $wpdb;

        $days  = (int) wcup_settings::get( 'notifications_retention', 90 );
        if ( $days < 1 ) {
            $days = 90;
        }

        $table = $wpdb->prefix . self::TABLE;

        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table} WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ) );
    }

    /* ============================================================
     *  هوک: تغییر وضعیت سفارش
     * ============================================================ */
    public function on_order_status_changed( $order_id, $old_status, $new_status, $order ) {

        if ( ! wcup_settings::get( 'notify_on_order_status', 1 ) ) {
            return;
        }

        if ( ! $order instanceof WC_Order ) {
            return;
        }

        $user_id = $order->get_customer_id();
        if ( ! $user_id ) {
            return;
        }

        $status_labels = array(
            'pending'    => 'در انتظار پرداخت',
            'processing' => 'در حال انجام',
            'on-hold'    => 'در انتظار بررسی',
            'completed'  => 'تکمیل شده',
            'cancelled'  => 'لغو شده',
            'refunded'   => 'مسترد شده',
            'failed'     => 'ناموفق',
        );

        $status_label = isset( $status_labels[ $new_status ] )
            ? $status_labels[ $new_status ]
            : $new_status;

        $order_number = $order->get_order_number();
        $order_url    = $order->get_view_order_url();

        self::add( $user_id, array(
            'type'    => 'order',
            'title'   => 'وضعیت سفارش #' . $order_number . ' تغییر کرد',
            'message' => 'سفارش شما به وضعیت «' . $status_label . '» درآمد.',
            'link'    => $order_url,
            'icon'    => 'box',
        ) );
    }

    /* ============================================================
     *  هوک: ذخیره کد رهگیری
     * ============================================================ */
    public function on_tracking_saved( $order_id ) {

        if ( ! wcup_settings::get( 'notify_on_tracking', 1 ) ) {
            return;
        }

        if ( ! isset( $_POST['wcup_tracking_code'] ) ) {
            return;
        }

        $code = sanitize_text_field( wp_unslash( $_POST['wcup_tracking_code'] ) );
        if ( $code === '' ) {
            return;
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        $user_id = $order->get_customer_id();
        if ( ! $user_id ) {
            return;
        }

        /* چک کن قبلاً اعلان مشابه نداده باشیم */
        global $wpdb;
        $table   = $wpdb->prefix . self::TABLE;
        $exists  = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table}
             WHERE user_id = %d AND type = 'tracking' AND link = %s
             AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)",
            $user_id,
            $order->get_view_order_url()
        ) );

        if ( $exists ) {
            return;
        }

        self::add( $user_id, array(
            'type'    => 'tracking',
            'title'   => 'کد رهگیری ثبت شد',
            'message' => 'کد رهگیری سفارش #' . $order->get_order_number() . ' ثبت شد. حالا می‌تونی مرسوله رو پیگیری کنی.',
            'link'    => $order->get_view_order_url(),
            'icon'    => 'truck',
        ) );
    }

    /* ============================================================
     *  هوک: تأیید نظر
     * ============================================================ */
    public function on_comment_approved( $comment_id, $status ) {

        if ( $status !== 'approve' ) {
            return;
        }

        if ( ! wcup_settings::get( 'notify_on_comment_approved', 1 ) ) {
            return;
        }

        $comment = get_comment( $comment_id );
        if ( ! $comment || ! $comment->user_id ) {
            return;
        }

        $post_id = (int) $comment->comment_post_ID;
        if ( get_post_type( $post_id ) !== 'product' ) {
            return;
        }

        $product_name = get_the_title( $post_id );
        $reviews_url  = wc_get_endpoint_url( 'reviews', '', wc_get_page_permalink( 'myaccount' ) );

        self::add( (int) $comment->user_id, array(
            'type'    => 'review',
            'title'   => 'نظر شما تأیید شد',
            'message' => 'نظر شما روی «' . $product_name . '» تأیید و منتشر شد.',
            'link'    => $reviews_url,
            'icon'    => 'star',
        ) );
    }

    /* ============================================================
     *  اعلان: افزودن به علاقه‌مندی (اختیاری)
     * ============================================================ */
    public function on_wishlist_added( $user_id, $product_id ) {

        /* غیرفعال شد چون اعلان اضافه نیست — فقط برای آینده */
        return;

        /* اگه خواستی فعال کنی، این رو از کامنت دربیار:
        if ( ! wcup_settings::get( 'notify_on_wishlist', 1 ) ) {
            return;
        }

        $product = wc_get_product( $product_id );
        if ( ! $product ) {
            return;
        }

        $wishlist_url = wc_get_endpoint_url( 'wishlist', '', wc_get_page_permalink( 'myaccount' ) );

        self::add( $user_id, array(
            'type'    => 'wishlist',
            'title'   => 'به علاقه‌مندی‌ها اضافه شد',
            'message' => 'محصول «' . $product->get_name() . '» به علاقه‌مندی‌هات اضافه شد.',
            'link'    => $wishlist_url,
            'icon'    => 'heart',
        ) );
        */
    }

    /* ============================================================
     *  اعلان: حذف از علاقه‌مندی (اختیاری)
     * ============================================================ */
    public function on_wishlist_removed( $user_id, $product_id ) {
        /* فعلاً نیازی نیست */
    }
	
    /* ============================================================
     *  Badge در منو
     * ============================================================ */
    public function add_badge_to_menu( $items ) {

        if ( ! isset( $items['notifications'] ) ) {
            return $items;
        }

        if ( ! is_user_logged_in() ) {
            return $items;
        }

        $user_id = get_current_user_id();
        $unread  = self::count( $user_id, true );

        if ( $unread > 0 ) {
            $items['notifications'] .= ' <span class="wcup-nav-badge">'
                . esc_html( wcup_helpers::fa_num( $unread ) )
                . '</span>';
        }

        return $items;
    }

    /* ============================================================
     *  رندر endpoint
     * ============================================================ */
    public function render_endpoint() {

        $template = locate_template( 'woocommerce/myaccount/notifications.php' );

        if ( $template ) {
            include $template;
            return;
        }

        echo '<div class="wcup-vo-error" style="padding:30px;background:#fdecec;border-radius:16px;color:#c0392b;text-align:center;">';
        echo 'قالب notifications.php پیدا نشد.';
        echo '</div>';
    }

    /* ============================================================
     *  AJAX: دریافت اعلان‌ها
     * ============================================================ */
    public function ajax_get() {

        check_ajax_referer( self::NONCE_KEY, 'nonce' );

        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
        }

        $unread_only = ! empty( $_POST['unread'] );

        $notifications = self::get( $user_id, array(
            'limit'  => 20,
            'unread' => $unread_only,
        ) );

        wp_send_json_success( array(
            'notifications' => $notifications,
            'unread_count'  => self::count( $user_id, true ),
        ) );
    }

    /* ============================================================
     *  AJAX: خوانده‌شده
     * ============================================================ */
    public function ajax_mark_read() {

        check_ajax_referer( self::NONCE_KEY, 'nonce' );

        $user_id = get_current_user_id();
        $id      = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;

        if ( ! $user_id || ! $id ) {
            wp_send_json_error( array( 'message' => 'اطلاعات نامعتبر.' ) );
        }

        self::mark_read( $id, $user_id );

        wp_send_json_success( array(
            'unread_count' => self::count( $user_id, true ),
        ) );
    }

    /* ============================================================
     *  AJAX: همه خوانده
     * ============================================================ */
    public function ajax_mark_all_read() {

        check_ajax_referer( self::NONCE_KEY, 'nonce' );

        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
        }

        self::mark_all_read( $user_id );

        wp_send_json_success( array(
            'message'      => 'همهٔ اعلان‌ها خوانده شدند.',
            'unread_count' => 0,
        ) );
    }

    /* ============================================================
     *  AJAX: حذف
     * ============================================================ */
    public function ajax_delete() {

        check_ajax_referer( self::NONCE_KEY, 'nonce' );

        $user_id = get_current_user_id();
        $id      = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;

        if ( ! $user_id || ! $id ) {
            wp_send_json_error( array( 'message' => 'اطلاعات نامعتبر.' ) );
        }

        self::delete( $id, $user_id );

        wp_send_json_success( array(
            'message'      => 'اعلان حذف شد.',
            'unread_count' => self::count( $user_id, true ),
        ) );
    }

    /* ============================================================
     *  AJAX: حذف همه
     * ============================================================ */
    public function ajax_delete_all() {

        check_ajax_referer( self::NONCE_KEY, 'nonce' );

        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
        }

        self::delete_all( $user_id );

        wp_send_json_success( array(
            'message'      => 'همهٔ اعلان‌ها حذف شدند.',
            'unread_count' => 0,
        ) );
    }

    /* ============================================================
     *  nonce برای JS
     * ============================================================ */
    public function print_nonce() {

        if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
            return;
        }

        if ( ! is_user_logged_in() ) {
            return;
        }
        ?>
        <script>
        window.wcupNotificationsData = {
            ajaxUrl: <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,
            nonce:   <?php echo wp_json_encode( wp_create_nonce( self::NONCE_KEY ) ); ?>,
            unread:  <?php echo (int) self::count( get_current_user_id(), true ); ?>
        };
        </script>
        <?php
    }
}