<?php
/**
 * WCUP Tracking — کد رهگیری سفارش
 * ============================================================
 *  شامل:
 *    - متاباکس ادمین (کلاسیک + HPOS)
 *    - ذخیره متا
 *    - نمایش به کاربر در جزئیات سفارش
 *    - ستون ادمین
 *    - Endpoint پیگیری سفارش
 *
 *  @package WCUP_Account
 *  @version 1.1.0
 * ============================================================
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_tracking' ) ) {
    return;
}

class wcup_tracking {

    const META_CARRIER = '_wcup_tracking_carrier';
    const META_CODE    = '_wcup_tracking_code';
    const META_URL     = '_wcup_tracking_url';

    const NONCE_KEY    = 'wcup_save_tracking';
    const NONCE_FIELD  = 'wcup_tracking_nonce';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {

        /* متاباکس کلاسیک (سازگار با پست‌های قدیمی) */
        add_action( 'add_meta_boxes', array( $this, 'register_metabox' ) );

        /* HPOS: فرم سفارش */
        add_action( 'woocommerce_admin_order_data_after_shipping_address', array( $this, 'render_hpos_metabox' ), 20 );

        /* ذخیره: کلاسیک */
        add_action( 'save_post_shop_order', array( $this, 'save_fields' ) );

        /* ذخیره: HPOS */
        add_action( 'woocommerce_process_shop_order_meta', array( $this, 'save_fields' ) );

        /* نمایش روی صفحه جزئیات سفارش کاربر */
        add_action( 'woocommerce_order_details_after_order_table', array( $this, 'render_user_tracking' ), 20 );

        /* ستون ادمین */
        add_filter( 'manage_edit-shop_order_columns', array( $this, 'admin_column_header' ), 20 );
        add_action( 'manage_shop_order_posts_custom_column', array( $this, 'admin_column_content' ), 20, 2 );

        /* Endpoint پیگیری سفارش */
        add_action( 'woocommerce_account_track-order_endpoint', array( $this, 'render_track_order_endpoint' ) );
    }

    /* ============================================================
     *  شرط نمایش
     * ============================================================ */
    private function is_enabled() {
        return (bool) wcup_settings::get( 'tracking_enabled', 1 );
    }

    /* ============================================================
     *  متاباکس کلاسیک
     * ============================================================ */
    public function register_metabox() {

        if ( ! $this->is_enabled() ) {
            return;
        }

        if ( $this->is_hpos_enabled() ) {
            return;
        }

        add_meta_box(
            'wcup_tracking_box',
            '🚚 اطلاعات رهگیری (WCUP)',
            array( $this, 'render_metabox' ),
            'shop_order',
            'side',
            'high'
        );
    }

    /* ============================================================
     *  رندر متاباکس کلاسیک
     * ============================================================ */
    public function render_metabox( $post ) {

        $order_id = $post->ID;
        $carrier  = get_post_meta( $order_id, self::META_CARRIER, true );
        $code     = get_post_meta( $order_id, self::META_CODE, true );
        $url      = get_post_meta( $order_id, self::META_URL, true );

        wp_nonce_field( self::NONCE_KEY, self::NONCE_FIELD );

        $this->render_fields( $carrier, $code, $url );
    }

    /* ============================================================
     *  رندر متاباکس HPOS
     * ============================================================ */
    public function render_hpos_metabox( $order ) {

        if ( ! $this->is_enabled() ) {
            return;
        }

        if ( ! $this->is_hpos_enabled() ) {
            return;
        }

        if ( ! $order instanceof WC_Order ) {
            return;
        }

        $carrier = $order->get_meta( self::META_CARRIER );
        $code    = $order->get_meta( self::META_CODE );
        $url     = $order->get_meta( self::META_URL );

        wp_nonce_field( self::NONCE_KEY, self::NONCE_FIELD );

        echo '<div class="wcup-hpos-tracking" style="clear:both;margin-top:20px;padding:12px;border:1px solid #ccd0d4;background:#fff;">';
        echo '<h3 style="margin-top:0;">🚚 اطلاعات رهگیری (WCUP)</h3>';
        $this->render_fields( $carrier, $code, $url );
        echo '</div>';
    }

    /* ============================================================
     *  فیلدهای مشترک
     * ============================================================ */
    private function render_fields( $carrier, $code, $url ) {

        $carriers = wcup_helpers::get_carriers();
        ?>
        <div style="padding:6px 0;">
            <p style="margin:0 0 10px;">
                <label style="display:block;font-weight:600;margin-bottom:4px;">شرکت حمل:</label>
                <select name="wcup_tracking_carrier" style="width:100%;">
                    <option value="" <?php selected( $carrier, '' ); ?>>— انتخاب کنید —</option>
                    <?php foreach ( $carriers as $key => $data ) : ?>
                        <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $carrier, $key ); ?>>
                            <?php echo esc_html( $data['label'] ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </p>

            <p style="margin:0 0 10px;">
                <label style="display:block;font-weight:600;margin-bottom:4px;">کد رهگیری:</label>
                <input type="text"
                       name="wcup_tracking_code"
                       value="<?php echo esc_attr( $code ); ?>"
                       style="width:100%;"
                       placeholder="مثلاً 12345678901234567890">
            </p>

            <p style="margin:0;">
                <label style="display:block;font-weight:600;margin-bottom:4px;">لینک رهگیری (اختیاری):</label>
                <input type="url"
                       name="wcup_tracking_url"
                       value="<?php echo esc_attr( $url ); ?>"
                       style="width:100%;">
            </p>
        </div>
        <?php
    }

    /* ============================================================
     *  ذخیره
     * ============================================================ */
    public function save_fields( $order_id ) {

        if ( ! $this->is_enabled() ) {
            return;
        }

        if ( ! isset( $_POST[ self::NONCE_FIELD ] ) ||
             ! wp_verify_nonce( $_POST[ self::NONCE_FIELD ], self::NONCE_KEY ) ) {
            return;
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        $can_edit = current_user_can( 'edit_shop_order', $order_id )
                 || current_user_can( 'edit_post', $order_id );

        if ( ! $can_edit ) {
            return;
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        $fields = array(
            self::META_CARRIER => 'wcup_tracking_carrier',
            self::META_CODE    => 'wcup_tracking_code',
            self::META_URL     => 'wcup_tracking_url',
        );

        foreach ( $fields as $meta_key => $post_key ) {

            $val = isset( $_POST[ $post_key ] )
                ? sanitize_text_field( wp_unslash( $_POST[ $post_key ] ) )
                : '';

            if ( $val === '' ) {
                $order->delete_meta_data( $meta_key );
            } else {
                $order->update_meta_data( $meta_key, $val );
            }
        }

        $order->save();
    }

    /* ============================================================
     *  نمایش به کاربر روی صفحه جزئیات سفارش
     * ============================================================ */
    public function render_user_tracking( $order ) {

        if ( ! $this->is_enabled() ) {
            return;
        }

        if ( ! $order instanceof WC_Order ) {
            return;
        }

        $carrier = $order->get_meta( self::META_CARRIER );
        $code    = $order->get_meta( self::META_CODE );
        $url     = wcup_helpers::get_tracking_url( $order );

        if ( ! $code && ! $carrier ) {
            return;
        }

        $label = wcup_helpers::get_carrier_label( $carrier );

        ?>
        <div class="wcup-vo-tracking">
            <h3 class="wcup-vo-tracking-title">🚚 اطلاعات رهگیری مرسوله</h3>

            <div class="wcup-vo-tracking-grid">

                <?php if ( $label && $label !== '—' ) : ?>
                    <div class="wcup-vo-tracking-row">
                        <span class="wcup-vo-tracking-label">شرکت حمل:</span>
                        <span class="wcup-vo-tracking-value"><?php echo esc_html( $label ); ?></span>
                    </div>
                <?php endif; ?>

                <?php if ( $code ) : ?>
                    <div class="wcup-vo-tracking-row">
                        <span class="wcup-vo-tracking-label">کد رهگیری:</span>
                        <span class="wcup-vo-tracking-value wcup-tracking-code">
                            <?php echo esc_html( wcup_helpers::fa_num( $code ) ); ?>
                        </span>
                    </div>
                <?php endif; ?>

                <?php if ( $url ) : ?>
                    <div class="wcup-vo-tracking-row">
                        <a href="<?php echo esc_url( $url ); ?>"
                           class="wcup-vo-tracking-btn"
                           target="_blank"
                           rel="noopener nofollow">
                            پیگیری مرسوله ↗
                        </a>
                    </div>
                <?php endif; ?>

            </div>
        </div>
        <?php
    }

    /* ============================================================
     *  Endpoint پیگیری سفارش
     * ============================================================ */
    public function render_track_order_endpoint() {

        $template = locate_template( 'woocommerce/myaccount/track-order.php' );

        if ( $template ) {
            include $template;
            return;
        }

        echo '<div class="wcup-vo-error" style="padding:30px;background:#fdecec;border-radius:16px;color:#c0392b;text-align:center;">';
        echo 'قالب track-order.php پیدا نشد.';
        echo '</div>';
    }

    /* ============================================================
     *  ستون ادمین (کلاسیک)
     * ============================================================ */
    public function admin_column_header( $columns ) {

        if ( $this->is_hpos_enabled() || ! $this->is_enabled() ) {
            return $columns;
        }

        $new = array();

        foreach ( $columns as $key => $label ) {
            $new[ $key ] = $label;
            if ( 'order_status' === $key ) {
                $new['wcup_tracking'] = 'رهگیری';
            }
        }

        return $new;
    }

    public function admin_column_content( $column, $post_id ) {

        if ( 'wcup_tracking' !== $column ) {
            return;
        }

        $code = get_post_meta( $post_id, self::META_CODE, true );

        if ( $code ) {
            echo '<span title="' . esc_attr( $code ) . '">✅</span>';
        } else {
            echo '<span style="opacity:.3;">—</span>';
        }
    }

    /* ============================================================
     *  تشخیص HPOS
     * ============================================================ */
    private function is_hpos_enabled() {

        if ( ! class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) ) {
            return false;
        }

        return \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
    }
}