<?php
/**
 * WCUP Assets — بارگذاری CSS/JS
 * ============================================================
 *  @package WCUP_Account
 *  @version 1.2.0
 * ============================================================
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_assets' ) ) {
    return;
}

class wcup_assets {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend' ), 20 );
    }

    /* ============================================================
     *  شرط لود CSS/JS
     * ============================================================ */
    private function should_load() {

        /* ─── صفحات حساب کاربری ─── */
        if ( function_exists( 'is_account_page' ) && is_account_page() ) {
            return true;
        }

        /* ─── صفحه محصول (برای دکمهٔ wishlist) ─── */
        if ( function_exists( 'is_product' ) && is_product() ) {
            if ( wcup_settings::get( 'wishlist_enabled', 1 ) && wcup_settings::get( 'wishlist_button_single', 1 ) ) {
                return true;
            }
        }

        /* ─── فروشگاه / آرشیو (برای دکمهٔ loop wishlist) ─── */
        $is_shop = ( function_exists( 'is_shop' ) && is_shop() )
                || ( function_exists( 'is_product_category' ) && is_product_category() )
                || ( function_exists( 'is_product_tag' ) && is_product_tag() )
                || ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() );

        if ( $is_shop && wcup_settings::get( 'wishlist_enabled', 1 ) && wcup_settings::get( 'wishlist_button_loop', 1 ) ) {
            return true;
        }

        /* ─── شورت‌کد wishlist توی هر صفحه‌ای ─── */
        if ( is_singular() ) {
            global $post;
            if ( $post && has_shortcode( $post->post_content, 'wcup_wishlist_button' ) ) {
                return true;
            }
        }

        /* ─── Elementor: هر جایی که ویجت داره ─── */
        if ( isset( $_GET['elementor-preview'] ) || did_action( 'elementor/loaded' ) ) {
            if ( is_singular() ) {
                global $post;
                if ( $post && (
                    strpos( $post->post_content, 'wcup_wishlist_button' ) !== false ||
                    strpos( $post->post_content, 'wcup-' ) !== false
                ) ) {
                    return true;
                }
            }
        }

        return false;
    }

    /* ============================================================
     *  بارگذاری در فرانت
     * ============================================================ */
    public function enqueue_frontend() {

        if ( ! $this->should_load() ) {
            return;
        }

        /* ─── CSS ─── */
        if ( wcup_settings::get( 'load_css', 1 ) ) {

            $css_file = WCUP_PATH . 'assets/css/wcup-myaccount.css';
            $css_uri  = WCUP_URL  . 'assets/css/wcup-myaccount.css';

            if ( file_exists( $css_file ) ) {
                wp_enqueue_style(
                    'wcup-myaccount',
                    $css_uri,
                    array(),
                    filemtime( $css_file )
                );
            }
        }

        /* ─── JS ─── */
        $js_file = WCUP_PATH . 'assets/js/wcup-account.js';
        $js_uri  = WCUP_URL  . 'assets/js/wcup-account.js';

        if ( ! file_exists( $js_file ) ) {
            return;
        }

        wp_enqueue_script(
            'wcup-account',
            $js_uri,
            array(),
            filemtime( $js_file ),
            true
        );

        /* ─── داده‌های مشترک ─── */
        wp_localize_script( 'wcup-account', 'wcupData', array(
            'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
            'isLoggedIn' => is_user_logged_in() ? 1 : 0,
            'loginUrl'   => wc_get_page_permalink( 'myaccount' ),
        ) );

        /* ─── داده‌های Wishlist ─── */
        if ( wcup_settings::get( 'wishlist_enabled', 1 ) ) {
            wp_localize_script( 'wcup-account', 'wcupWishlistData', array(
                'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
                'nonce'      => wp_create_nonce( 'wcup_wishlist_nonce' ),
                'isLoggedIn' => is_user_logged_in() ? 1 : 0,
                'loginUrl'   => wc_get_page_permalink( 'myaccount' ),
            ) );
        }

        /* ─── داده‌های Addresses ─── */
        if ( is_account_page() && wcup_settings::get( 'addresses_enabled', 1 ) ) {
            wp_localize_script( 'wcup-account', 'wcupAddressesData', array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'wcup_addresses_nonce' ),
            ) );
        }
		
        /* ─── داده‌های Notifications ─── */
        if ( wcup_settings::get( 'notifications_enabled', 1 ) ) {
            wp_localize_script( 'wcup-account', 'wcupNotificationsData', array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'wcup_notifications_nonce' ),
            ) );
        }
    }
}