<?php
defined( 'ABSPATH' ) || exit;

$s = wcup_settings::get();

$items = array(
    'dashboard'       => array( 'label' => 'پیشخوان',           'setting' => 'menu_dashboard',       'label_key' => 'label_dashboard' ),
    'orders'          => array( 'label' => 'سفارش‌ها',           'setting' => 'menu_orders',          'label_key' => 'label_orders' ),
    'invoices'        => array( 'label' => 'فاکتورها',           'setting' => 'menu_invoices',        'label_key' => 'label_invoices' ),
    'downloads'       => array( 'label' => 'دانلودها',           'setting' => 'menu_downloads',       'label_key' => 'label_downloads' ),
    'reviews'         => array( 'label' => 'نظرات شما',         'setting' => 'menu_reviews',         'label_key' => 'label_reviews' ),
    'track-order'     => array( 'label' => 'پیگیری سفارش',      'setting' => 'menu_track_order',     'label_key' => 'label_track_order' ),
    'notifications'   => array( 'label' => 'اعلان‌ها',           'setting' => 'menu_notifications',   'label_key' => 'label_notifications' ),
    'wishlist'        => array( 'label' => 'علاقه‌مندی‌ها',      'setting' => 'menu_wishlist',        'label_key' => 'label_wishlist' ),
    'addresses'       => array( 'label' => 'آدرس‌های من',       'setting' => 'menu_addresses',       'label_key' => 'label_addresses' ),
    'licenses'        => array( 'label' => 'لایسنس‌ها',          'setting' => 'menu_licenses',        'label_key' => 'label_licenses' ),
    'edit_account'    => array( 'label' => 'جزئیات حساب',       'setting' => 'menu_edit_account',    'label_key' => 'label_edit_account' ),
    'edit_address'    => array( 'label' => 'آدرس‌ها (قدیمی)',    'setting' => 'menu_edit_address',    'label_key' => 'label_edit_address' ),
    'payment_methods' => array( 'label' => 'روش‌های پرداخت',     'setting' => 'menu_payment_methods', 'label_key' => null ),
    'logout'          => array( 'label' => 'خروج',               'setting' => 'menu_logout',          'label_key' => 'label_logout' ),
);
?>
<div class="wrap wcup-wrap">

    <div class="wcup-header">
        <div>
            <h1 class="wcup-title">📋 منوی حساب کاربری</h1>
            <p class="wcup-header-sub">
                کنترل نمایش، ترتیب و برچسب هر آیتم در منوی حساب کاربری.
            </p>
        </div>
        <div class="wcup-header-actions">
            <a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>"
               class="button" target="_blank">
                👁️ مشاهدهٔ منو
            </a>
        </div>
    </div>

    <!-- راهنما -->
    <div class="wcup-panel wcup-panel--info">
        <div style="display:flex;gap:12px;align-items:flex-start;">
            <span style="font-size:22px;">💡</span>
            <div>
                <strong style="color:#002736;display:block;margin-bottom:4px;">راهنما</strong>
                <ul style="margin:0;padding-right:20px;font-size:13px;color:#7C8289;line-height:1.9;">
                    <li>تیک «نمایش» رو برداری، آیتم از منو حذف می‌شه.</li>
                    <li>برچسب سفارشی — اگه خالی بذاری، پیش‌فرض استفاده می‌شه.</li>
                    <li>ترتیب منو بعد از ذخیره، به‌طور خودکار اعمال می‌شه.</li>
                    <li>«آدرس‌ها (قدیمی)» فقط برای سازگاری با ووکامرس پیش‌فرضه — اگه از «آدرس‌های من» استفاده می‌کنی، این رو غیرفعال کن.</li>
                </ul>
            </div>
        </div>
    </div>

    <form method="post" action="options.php" class="wcup-form">
        <?php settings_fields( 'wcup_settings_group' ); ?>

        <div class="wcup-panel">
            <table class="widefat striped wcup-table">
                <thead>
                    <tr>
                        <th style="width:25%;">آیتم</th>
                        <th style="width:15%;text-align:center;">نمایش</th>
                        <th>برچسب سفارشی</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $items as $key => $data ) :

                    $enabled       = (int) ( $s[ $data['setting'] ] ?? 1 );
                    $current_label = $data['label_key'] ? ( $s[ $data['label_key'] ] ?? '' ) : '';
                ?>
                    <tr>
                        <td>
                            <strong style="color:#002736;"><?php echo esc_html( $data['label'] ); ?></strong>
                            <div style="font-size:11px;color:#7C8289;margin-top:2px;">
                                <code><?php echo esc_html( $key ); ?></code>
                                <span style="color:#c8d0d4;">·</span>
                                <code style="background:#f0f2f5;padding:1px 4px;border-radius:3px;">
                                    <?php echo esc_html( $data['setting'] ); ?>
                                </code>
                            </div>
                        </td>
                        <td style="text-align:center;">
                            <label class="wcup-switch">
                                <input type="hidden" name="wcup_settings[<?php echo esc_attr( $data['setting'] ); ?>]" value="0">
                                <input type="checkbox"
                                       name="wcup_settings[<?php echo esc_attr( $data['setting'] ); ?>]"
                                       value="1"
                                       <?php checked( $enabled, 1 ); ?>>
                                <span class="wcup-switch-slider"></span>
                            </label>
                        </td>
                        <td>
                            <?php if ( $data['label_key'] ) : ?>
                                <input type="text"
                                       name="wcup_settings[<?php echo esc_attr( $data['label_key'] ); ?>]"
                                       value="<?php echo esc_attr( $current_label ); ?>"
                                       placeholder="<?php echo esc_attr( $data['label'] ); ?>"
                                       class="regular-text">
                            <?php else : ?>
                                <span class="description">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php submit_button( '💾 ذخیرهٔ منو', 'primary large' ); ?>
    </form>

</div>