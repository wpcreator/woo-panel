<?php
defined( 'ABSPATH' ) || exit;

$s = wcup_settings::get();

/* ═══════════════════════════════════════════════════════
 *  گروه‌های کارت‌ها
 * ═══════════════════════════════════════════════════════ */
$groups = array(

    'sections' => array(
        'title'  => '🧩 بخش‌های داشبورد',
        'desc'   => 'کل بخش‌ها رو روشن/خاموش کن',
        'fields' => array(
            'dash_hero'          => array( 'label' => 'کارت خوش‌آمدگویی',    'desc' => 'آواتار + نام + روز عضویت' ),
            'dash_progress'      => array( 'label' => 'نوار پیشرفت پروفایل', 'desc' => 'نمایش درصد تکمیل پروفایل' ),
            'dash_quick_links'   => array( 'label' => 'لینک‌های سریع',         'desc' => 'دسترسی سریع به سفارش‌ها و دانلودها' ),
            'dash_recent_orders' => array( 'label' => 'آخرین سفارش‌ها',       'desc' => 'جدول ۳ سفارش آخر' ),
            'dash_notices'       => array( 'label' => 'اطلاعیه‌ها',            'desc' => 'نمایش اطلاعیه‌های فعال' ),
			'dash_show_section_titles' => array( 'label' => 'برچسب‌های بخش‌بندی',    'desc' => 'عناوین «آمار خرید»، «وضعیت سفارش‌ها»، «فعالیت‌های من»، «آخرین سفارش»' ),
        ),
    ),

    'purchase' => array(
        'title'  => '💰 کارت‌های آماری — خرید',
        'desc'   => 'مربوط به سفارش‌ها و خریدها',
        'fields' => array(
            'stat_total_spent'  => array( 'label' => 'مبلغ کل خرید',        'desc' => 'مجموع مبالغ پرداخت‌شده' ),
            'stat_total_orders' => array( 'label' => 'تعداد کل سفارش‌ها',   'desc' => 'همهٔ سفارش‌ها' ),
            'stat_avg_order'    => array( 'label' => 'میانگین مبلغ سفارش',  'desc' => 'میانگین مبلغ هر سفارش' ),
            'stat_member_days'  => array( 'label' => 'روزهای عضویت',         'desc' => 'از زمان ثبت‌نام تا امروز' ),
        ),
    ),

    'status' => array(
        'title'  => '📊 کارت‌های آماری — وضعیت',
        'desc'   => 'وضعیت سفارش‌ها',
        'fields' => array(
            'stat_completed'  => array( 'label' => 'سفارش‌های تکمیل‌شده', 'desc' => 'سفارش‌های با وضعیت Completed' ),
            'stat_processing' => array( 'label' => 'در حال پردازش',        'desc' => 'سفارش‌های در حال انجام + بررسی' ),
        ),
    ),

    'activity' => array(
        'title'  => '⭐ کارت‌های آماری — فعالیت',
        'desc'   => 'فعالیت‌های کاربر در سایت',
        'fields' => array(
            'stat_wishlist'  => array( 'label' => 'علاقه‌مندی‌ها',  'desc' => 'نیازمند پلاگین Wishlist' ),
            'stat_comments'  => array( 'label' => 'دیدگاه‌ها',      'desc' => 'نظرات تأییدشده' ),
            'stat_downloads' => array( 'label' => 'دانلودها',       'desc' => 'فایل‌های خریداری‌شده (یکتا)' ),
        ),
    ),

    'highlight' => array(
        'title'  => '🧾 آخرین سفارش',
        'desc'   => 'کارت برجستهٔ آخرین سفارش کاربر',
        'fields' => array(
            'stat_last_order' => array( 'label' => 'نمایش آخرین سفارش', 'desc' => 'یک کارت بزرگ با جزئیات آخرین سفارش' ),
        ),
    ),
);
?>
<div class="wrap wcup-wrap">

    <div class="wcup-header">
        <div>
            <h1 class="wcup-title">🎛️ کارت‌های داشبورد</h1>
            <p class="wcup-header-sub">
                کنترل نمایش هر کارت در داشبورد کاربری. تغییرات فقط روی نمایش تأثیر داره و اطلاعات حذف نمی‌شه.
            </p>
        </div>
        <div class="wcup-header-actions">
            <a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>"
               class="button" target="_blank">
                👁️ مشاهدهٔ داشبورد
            </a>
        </div>
    </div>

    <form method="post" action="options.php" class="wcup-form">
        <?php settings_fields( 'wcup_settings_group' ); ?>

        <!-- ═══ راهنمای سریع ═══ -->
        <div class="wcup-panel wcup-panel--info">
            <div style="display:flex;gap:12px;align-items:flex-start;">
                <span style="font-size:22px;">💡</span>
                <div>
                    <strong style="color:#002736;display:block;margin-bottom:4px;">نکته سریع</strong>
                    <p style="margin:0;font-size:13px;color:#7C8289;line-height:1.8;">
                        برای مرتب‌سازی یا حذف یه کارت، روی تیک مربوطه کلیک کن.
                        اگه یه گروه کامل غیرفعال بشه، کارت‌هاش توی داشبورد نمایش داده نمی‌شن.
                    </p>
                </div>
            </div>
        </div>

        <!-- ═══ گروه‌ها ═══ -->
        <?php foreach ( $groups as $group_key => $group ) : ?>

            <div class="wcup-panel wcup-panel--group">

                <div class="wcup-group-head">
                    <h2 class="wcup-panel-title" style="border:none;padding:0;margin:0;">
                        <?php echo esc_html( $group['title'] ); ?>
                    </h2>
                    <div class="wcup-group-actions">
                        <button type="button"
                                class="button button-small wcup-group-toggle"
                                data-group="<?php echo esc_attr( $group_key ); ?>"
                                data-action="all">
                            ✅ همه
                        </button>
                        <button type="button"
                                class="button button-small wcup-group-toggle"
                                data-group="<?php echo esc_attr( $group_key ); ?>"
                                data-action="none">
                            ⛔ هیچکدام
                        </button>
                    </div>
                </div>
                <p class="wcup-group-desc"><?php echo esc_html( $group['desc'] ); ?></p>

                <table class="widefat striped wcup-table wcup-table--widgets">
                    <tbody>
                        <?php foreach ( $group['fields'] as $key => $field ) :
                            $on = (int) ( $s[ $key ] ?? 1 );
                        ?>
                            <tr class="wcup-widget-row <?php echo $on ? 'is-on' : 'is-off'; ?>">
                                <td style="width:60%;">
                                    <label style="display:block;cursor:pointer;">
                                        <strong><?php echo esc_html( $field['label'] ); ?></strong>
                                        <span style="display:block;font-size:11px;color:#7C8289;margin-top:2px;">
                                            <?php echo esc_html( $field['desc'] ); ?>
                                        </span>
                                    </label>
                                </td>
                                <td style="text-align:center;width:150px;">
                                    <label class="wcup-switch">
                                        <input type="hidden" name="wcup_settings[<?php echo esc_attr( $key ); ?>]" value="0">
                                        <input type="checkbox"
                                               class="wcup-widget-toggle"
                                               data-group="<?php echo esc_attr( $group_key ); ?>"
                                               name="wcup_settings[<?php echo esc_attr( $key ); ?>]"
                                               value="1"
                                               <?php checked( $on, 1 ); ?>>
                                        <span class="wcup-switch-slider"></span>
                                    </label>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

            </div>

        <?php endforeach; ?>

        <?php submit_button( '💾 ذخیره تغییرات', 'primary large' ); ?>

    </form>

</div>

<script>
jQuery(function($){

    /* ═══ تغییر ظاهر ردیف با toggle ═══ */
    $(document).on('change', '.wcup-widget-toggle', function(){
        var row = $(this).closest('.wcup-widget-row');
        if ($(this).is(':checked')) {
            row.removeClass('is-off').addClass('is-on');
        } else {
            row.removeClass('is-on').addClass('is-off');
        }
    });

    /* ═══ همه / هیچکدام ═══ */
    $(document).on('click', '.wcup-group-toggle', function(e){
        e.preventDefault();
        var group  = $(this).data('group');
        var action = $(this).data('action');

        $('.wcup-widget-toggle[data-group="' + group + '"]').each(function(){
            var $cb = $(this);
            var newState = (action === 'all');
            if ($cb.is(':checked') !== newState) {
                $cb.prop('checked', newState).trigger('change');
            }
        });
    });

});
</script>