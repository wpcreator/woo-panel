<?php
defined( 'ABSPATH' ) || exit;

$s = wcup_settings::get();

$logo_id     = (int) ( $s['invoice_logo_id'] ?? 0 );
$logo_url    = $logo_id ? wp_get_attachment_image_url( $logo_id, 'medium' ) : '';
$placeholder = wc_placeholder_img_src();

/* فونت پیش‌فرض */
$fonts_base = $s['invoice_fonts_base'] ?? '';
if ( ! $fonts_base ) {
    $fonts_base = content_url( '/uploads/2025/03/' );
}

/* ⭐ نمونه سفارش برای پیش‌نمایش — از way درست */
$sample_order_id = 0;
if ( class_exists( 'wcup_invoice' ) ) {
    $sample_order_id = wcup_invoice::instance()->get_sample_order_id();
}

$preview_url = $sample_order_id
    ? add_query_arg( 'wcup_invoice_html', $sample_order_id, home_url( '/' ) )
    : '';
?>
<div class="wrap wcup-wrap">

    <div class="wcup-header">
        <div>
            <h1 class="wcup-title">🧾 مدیریت فاکتور</h1>
            <p class="wcup-header-sub">
                تنظیمات فاکتور HTML — شماره، لوگو، متن‌ها، و فونت.
            </p>
        </div>
        <div class="wcup-header-actions">
            <?php if ( $preview_url ) : ?>
                <a href="<?php echo esc_url( $preview_url ); ?>"
                   class="button button-primary"
                   target="_blank"
                   rel="noopener">
                    👁️ پیش‌نمایش فاکتور
                </a>
            <?php else : ?>
                <span class="button disabled" style="opacity:.5;cursor:not-allowed;">
                    👁️ پیش‌نمایش (سفارشی نیست)
                </span>
            <?php endif; ?>
        </div>
    </div>

    <form method="post" action="options.php" class="wcup-form">
        <?php settings_fields( 'wcup_settings_group' ); ?>

        <!-- ═══ فعال‌سازی ═══ -->
        <div class="wcup-panel">
            <h2 class="wcup-panel-title">⚡ فعال‌سازی</h2>
            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row">فعال بودن فاکتور</th>
                        <td>
                            <label class="wcup-switch">
                                <input type="hidden" name="wcup_settings[invoice_enabled]" value="0">
                                <input type="checkbox"
                                       name="wcup_settings[invoice_enabled]"
                                       value="1"
                                       <?php checked( (int) ( $s['invoice_enabled'] ?? 1 ), 1 ); ?>>
                                <span class="wcup-switch-slider"></span>
                            </label>
                            <p class="description">نمایش دکمهٔ «مشاهدهٔ فاکتور» روی سفارشات</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">ایمیل فاکتور</th>
                        <td>
                            <label class="wcup-switch">
                                <input type="hidden" name="wcup_settings[invoice_email_on_complete]" value="0">
                                <input type="checkbox"
                                       name="wcup_settings[invoice_email_on_complete]"
                                       value="1"
                                       <?php checked( (int) ( $s['invoice_email_on_complete'] ?? 1 ), 1 ); ?>>
                                <span class="wcup-switch-slider"></span>
                            </label>
                            <p class="description">ارسال لینک فاکتور به ایمیل مشتری بعد از تکمیل سفارش</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- ═══ شماره‌گذاری ═══ -->
        <div class="wcup-panel">
            <h2 class="wcup-panel-title">🔢 شماره‌گذاری</h2>
            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row">پیش‌شمارهٔ فاکتور</th>
                        <td>
                            <input type="text"
                                   name="wcup_settings[invoice_prefix]"
                                   value="<?php echo esc_attr( $s['invoice_prefix'] ?? 'INV' ); ?>"
                                   class="regular-text"
                                   placeholder="INV"
                                   dir="ltr"
                                   style="max-width:180px;font-family:monospace;">
                            <p class="description">
                                فرمت خروجی: <code><?php echo esc_html( $s['invoice_prefix'] ?? 'INV' ); ?>-1405-0001</code>
                            </p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- ═══ لوگو ═══ -->
        <div class="wcup-panel">
            <h2 class="wcup-panel-title">🖼️ لوگو فاکتور</h2>
            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row">لوگو</th>
                        <td>
                            <div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap;">
                                <div style="width:140px;height:90px;padding:8px;background:#f7f9fa;border:1px solid #e5eaed;border-radius:10px;display:flex;align-items:center;justify-content:center;overflow:hidden;">
                                    <img id="wcup-invoice-logo-preview"
                                         src="<?php echo esc_url( $logo_url ?: $placeholder ); ?>"
                                         style="max-width:100%;max-height:100%;object-fit:contain;display:block;">
                                </div>
                                <input type="hidden"
                                       name="wcup_settings[invoice_logo_id]"
                                       id="wcup-invoice-logo-id"
                                       value="<?php echo esc_attr( $logo_id ); ?>">
                                <div style="display:flex;flex-direction:column;gap:6px;">
                                    <button type="button" class="button" id="wcup-select-invoice-logo">
                                        🖼️ انتخاب تصویر
                                    </button>
                                    <button type="button" class="button" id="wcup-remove-invoice-logo">
                                        🗑️ حذف
                                    </button>
                                </div>
                            </div>
                            <p class="description">
                                اگه خالی باشه، از لوگوی سایت (سفارشی‌سازی → هویت سایت) استفاده می‌شه.
                            </p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- ═══ بخش‌ها ═══ -->
        <div class="wcup-panel">
            <h2 class="wcup-panel-title">📋 بخش‌های فاکتور</h2>
            <table class="widefat striped wcup-table">
                <tbody>
                    <tr>
                        <td style="width:70%;">
                            <strong>QR Code اعتبارسنجی</strong>
                            <p class="description" style="margin:2px 0 0;">کد QR پایین فاکتور برای اسکن کردن</p>
                        </td>
                        <td style="text-align:center;width:30%;">
                            <label class="wcup-switch">
                                <input type="hidden" name="wcup_settings[invoice_show_qr]" value="0">
                                <input type="checkbox"
                                       name="wcup_settings[invoice_show_qr]"
                                       value="1"
                                       <?php checked( (int) ( $s['invoice_show_qr'] ?? 1 ), 1 ); ?>>
                                <span class="wcup-switch-slider"></span>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong>اطلاعات رهگیری</strong>
                            <p class="description" style="margin:2px 0 0;">کد رهگیری مرسوله در فاکتور نمایش داده بشه</p>
                        </td>
                        <td style="text-align:center;">
                            <label class="wcup-switch">
                                <input type="hidden" name="wcup_settings[invoice_show_tracking]" value="0">
                                <input type="checkbox"
                                       name="wcup_settings[invoice_show_tracking]"
                                       value="1"
                                       <?php checked( (int) ( $s['invoice_show_tracking'] ?? 1 ), 1 ); ?>>
                                <span class="wcup-switch-slider"></span>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong>شرایط و قوانین</strong>
                            <p class="description" style="margin:2px 0 0;">متن شرایط پایین فاکتور نمایش داده بشه</p>
                        </td>
                        <td style="text-align:center;">
                            <label class="wcup-switch">
                                <input type="hidden" name="wcup_settings[invoice_show_terms]" value="0">
                                <input type="checkbox"
                                       name="wcup_settings[invoice_show_terms]"
                                       value="1"
                                       <?php checked( (int) ( $s['invoice_show_terms'] ?? 1 ), 1 ); ?>>
                                <span class="wcup-switch-slider"></span>
                            </label>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- ═══ متن‌ها ═══ -->
        <div class="wcup-panel">
            <h2 class="wcup-panel-title">✏️ متن‌های سفارشی</h2>
            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row">متن تشکر</th>
                        <td>
                            <input type="text"
                                   name="wcup_settings[invoice_thanks_text]"
                                   value="<?php echo esc_attr( $s['invoice_thanks_text'] ?? 'از خرید شما سپاسگزاریم' ); ?>"
                                   class="large-text"
                                   placeholder="از خرید شما سپاسگزاریم">
                            <p class="description">پایین فاکتور، در بخش تشکر</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">یادداشت پایین فاکتور</th>
                        <td>
                            <input type="text"
                                   name="wcup_settings[invoice_footer_note]"
                                   value="<?php echo esc_attr( $s['invoice_footer_note'] ?? 'این فاکتور به‌صورت خودکار توسط سیستم تولید شده است.' ); ?>"
                                   class="large-text">
                            <p class="description">متن کوچک زیر تشکر</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">شرایط و قوانین</th>
                        <td>
                            <textarea name="wcup_settings[invoice_terms_text]"
                                      rows="4"
                                      class="large-text"
                                      placeholder="کالاهای فروخته‌شده تا ۷ روز پس از دریافت، در صورت داشتن مشکل، قابل مرجوع هستند."><?php echo esc_textarea( $s['invoice_terms_text'] ?? '' ); ?></textarea>
                            <p class="description">
                                اگه «شرایط و قوانین» فعال باشه، بالای تشکر نمایش داده می‌شه.
                            </p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- ═══ فونت ═══ -->
        <div class="wcup-panel">
            <h2 class="wcup-panel-title">🔤 فونت فاکتور</h2>
            <table class="form-table">
                <tbody>
                    <tr>
                        <th scope="row">مسیر فونت‌ها</th>
                        <td>
                            <input type="url"
                                   name="wcup_settings[invoice_fonts_base]"
                                   value="<?php echo esc_attr( $s['invoice_fonts_base'] ?? '' ); ?>"
                                   class="large-text"
                                   placeholder="<?php echo esc_attr( content_url( '/uploads/2025/03/' ) ); ?>"
                                   dir="ltr">
                            <p class="description">
                                مسیر پوشه‌ای که فایل‌های <code>PeydaWebFaNum-*.woff2</code> داخلش هستند.<br>
                                اگه خالی بذاری، از مسیر پیش‌فرض استفاده می‌شه:<br>
                                <code><?php echo esc_html( content_url( '/uploads/2025/03/' ) ); ?></code>
                            </p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <?php submit_button( '💾 ذخیره تنظیمات فاکتور', 'primary large' ); ?>
    </form>

</div>

<script>
jQuery(function($){

    /* ─── لوگو ─── */
    var logoFrame;

    $('#wcup-select-invoice-logo').on('click', function(e){
        e.preventDefault();

        if ( logoFrame ) { logoFrame.open(); return; }

        if ( typeof wp === 'undefined' || ! wp.media ) {
            alert('کتابخانهٔ رسانه لود نشده. صفحه رو رفرش کن.');
            return;
        }

        logoFrame = wp.media({
            title: 'انتخاب لوگوی فاکتور',
            button: { text: 'استفاده' },
            multiple: false,
            library: { type: 'image' }
        });

        logoFrame.on('select', function(){
            var att = logoFrame.state().get('selection').first().toJSON();
            var src = ( att.sizes && att.sizes.medium ) ? att.sizes.medium.url : att.url;

            $('#wcup-invoice-logo-id').val( att.id );
            $('#wcup-invoice-logo-preview').attr('src', src);
        });

        logoFrame.open();
    });

    $('#wcup-remove-invoice-logo').on('click', function(e){
        e.preventDefault();
        $('#wcup-invoice-logo-id').val('0');
        $('#wcup-invoice-logo-preview').attr('src', '<?php echo esc_url( $placeholder ); ?>');
    });

});
</script>