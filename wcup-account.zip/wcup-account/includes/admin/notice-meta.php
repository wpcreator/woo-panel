<?php
/**
 * WCUP Notice — Admin Meta Boxes & Columns
 * ============================================================
 *  این فایل فقط در پنل ادمین لود می‌شه:
 *    - متاباکس تنظیمات اطلاعیه
 *    - متاباکس پیش‌نمایش زنده
 *    - ذخیره متا
 *    - ستون‌های لیست ادمین
 *    - استایل اختصاصی
 *
 *  @package WCUP_Account
 *  @version 1.0.0
 * ============================================================
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'wcup_notice' ) ) {
    return;
}

/* ═══════════════════════════════════════════════════════
 *  ثبت متاباکس‌ها
 * ═══════════════════════════════════════════════════════ */
add_action( 'add_meta_boxes', 'wcup_notice_register_metaboxes' );

function wcup_notice_register_metaboxes() {

    if ( ! wcup_notice::instance()->is_enabled() ) {
        return;
    }

    add_meta_box(
        'wcup_notice_settings',
        '⚙️ تنظیمات اطلاعیه',
        'wcup_notice_render_settings_metabox',
        wcup_notice::POST_TYPE,
        'side',
        'default'
    );

    add_meta_box(
        'wcup_notice_preview',
        '👁️ پیش‌نمایش زنده',
        'wcup_notice_render_preview_metabox',
        wcup_notice::POST_TYPE,
        'normal',
        'high'
    );
}

/* ═══════════════════════════════════════════════════════
 *  متاباکس تنظیمات
 * ═══════════════════════════════════════════════════════ */
function wcup_notice_render_settings_metabox( $post ) {

    $type        = get_post_meta( $post->ID, '_wcup_notice_type', true ) ?: 'info';
    $priority    = get_post_meta( $post->ID, '_wcup_notice_priority', true ) ?: 'normal';
    $dismissible = get_post_meta( $post->ID, '_wcup_notice_dismissible', true );
    $dismissible = ( $dismissible === '' ) ? '1' : $dismissible;

    wp_nonce_field( wcup_notice::NONCE_KEY, wcup_notice::NONCE_FLD );
    ?>
    <div class="wcup-notice-meta">

        <p>
            <label style="display:block;font-weight:600;margin-bottom:6px;">نوع اطلاعیه:</label>
            <select name="wcup_notice_type" id="wcup_notice_type" style="width:100%;">
                <option value="info"    <?php selected( $type, 'info' ); ?>>ℹ️ اطلاع</option>
                <option value="success" <?php selected( $type, 'success' ); ?>>✅ موفقیت</option>
                <option value="warning" <?php selected( $type, 'warning' ); ?>>⚠️ هشدار</option>
                <option value="danger"  <?php selected( $type, 'danger' ); ?>>❌ مهم</option>
            </select>
        </p>

        <p>
            <label style="display:block;font-weight:600;margin-bottom:6px;">اولویت:</label>
            <select name="wcup_notice_priority" id="wcup_notice_priority" style="width:100%;">
                <option value="normal" <?php selected( $priority, 'normal' ); ?>>عادی</option>
                <option value="high"   <?php selected( $priority, 'high' ); ?>>⚡ بالا</option>
            </select>
            <span style="display:block;font-size:11px;color:#666;margin-top:4px;">
                اولویت «بالا» در بالای لیست نمایش داده می‌شه.
            </span>
        </p>

        <p>
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                <input type="checkbox" name="wcup_notice_dismissible" id="wcup_notice_dismissible"
                       value="1" <?php checked( $dismissible, '1' ); ?>>
                <span>کاربر بتونه ببنده؟</span>
            </label>
            <span style="display:block;font-size:11px;color:#666;margin-top:4px;">
                اگه تیک نخوره، کاربر همیشه این اطلاعیه رو می‌بینه.
            </span>
        </p>

    </div>
    <?php
}

/* ═══════════════════════════════════════════════════════
 *  متاباکس پیش‌نمایش زنده
 * ═══════════════════════════════════════════════════════ */
function wcup_notice_render_preview_metabox( $post ) {

    $title       = $post->post_title ?: 'عنوان اطلاعیه';
    $content     = $post->post_content ?: 'محتوای اطلاعیه اینجا نمایش داده می‌شه...';
    $type        = get_post_meta( $post->ID, '_wcup_notice_type', true ) ?: 'info';
    $priority    = get_post_meta( $post->ID, '_wcup_notice_priority', true ) ?: 'normal';
    $dismissible = get_post_meta( $post->ID, '_wcup_notice_dismissible', true );
    $dismissible = ( $dismissible === '' ) ? '1' : $dismissible;

    $colors = array(
        'info'    => array( 'bg' => '#f0f8fa', 'border' => '#3897A9', 'text' => '#002736', 'icon_bg' => '#e6f4f7', 'icon_color' => '#3897A9', 'emoji' => 'ℹ️' ),
        'success' => array( 'bg' => '#f0fdf7', 'border' => '#008869', 'text' => '#002736', 'icon_bg' => '#e6f7ee', 'icon_color' => '#008869', 'emoji' => '✅' ),
        'warning' => array( 'bg' => '#fffbeb', 'border' => '#FBE83F', 'text' => '#7a6100', 'icon_bg' => '#fef9c3', 'icon_color' => '#b45309', 'emoji' => '⚠️' ),
        'danger'  => array( 'bg' => '#fef3f3', 'border' => '#F34747', 'text' => '#7a1f1f', 'icon_bg' => '#fdecec', 'icon_color' => '#F34747', 'emoji' => '❌' ),
    );
    $c = isset( $colors[ $type ] ) ? $colors[ $type ] : $colors['info'];
    ?>
    <div style="padding:20px;background:#f6f8f9;border-radius:12px;">
        <div style="margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;">
            <strong style="color:#002736;">پیش‌نمایش اطلاعیه در پنل کاربری:</strong>
            <?php if ( 'high' === $priority ) : ?>
                <span style="background:#FBE83F;color:#7a6100;padding:3px 10px;border-radius:6px;font-size:11px;font-weight:700;">
                    ⚡ اولویت بالا
                </span>
            <?php endif; ?>
        </div>

        <div id="wcup-notice-preview-box"
             style="display:flex;align-items:flex-start;gap:14px;padding:18px 20px;background:<?php echo esc_attr( $c['bg'] ); ?>;border:1px solid <?php echo esc_attr( $c['border'] ); ?>;border-radius:14px;position:relative;direction:rtl;">

            <div id="wcup-preview-icon"
                 style="width:42px;height:42px;border-radius:12px;background:<?php echo esc_attr( $c['icon_bg'] ); ?>;color:<?php echo esc_attr( $c['icon_color'] ); ?>;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;">
                <?php echo esc_html( $c['emoji'] ); ?>
            </div>

            <div style="flex:1;min-width:0;">
                <div id="wcup-preview-title" style="font-size:14.5px;font-weight:900;color:<?php echo esc_attr( $c['text'] ); ?>;margin-bottom:6px;line-height:1.4;">
                    <?php echo esc_html( $title ); ?>
                </div>
                <div id="wcup-preview-content" style="font-size:13px;line-height:1.9;color:<?php echo esc_attr( $c['text'] ); ?>;">
                    <?php echo wp_kses_post( wpautop( $content ) ); ?>
                </div>
            </div>

            <?php if ( $dismissible === '1' ) : ?>
                <div id="wcup-preview-close"
                     style="width:26px;height:26px;border-radius:8px;background:rgba(0,0,0,.05);display:flex;align-items:center;justify-content:center;color:#666;font-size:14px;flex-shrink:0;">
                    ×
                </div>
            <?php endif; ?>

        </div>

        <p style="margin:12px 0 0;font-size:12px;color:#666;">
            💡 این پیش‌نمایش با تغییر تنظیمات یا محتوا به‌صورت خودکار به‌روز می‌شه.
        </p>
    </div>

    <script>
    jQuery(function($){
        function updatePreview(){
            var type        = $('#wcup_notice_type').val();
            var dismissible = $('#wcup_notice_dismissible').is(':checked');

            var colors = {
                info:    { bg:'#f0f8fa', border:'#3897A9', text:'#002736', iconBg:'#e6f4f7', iconColor:'#3897A9', emoji:'ℹ️' },
                success: { bg:'#f0fdf7', border:'#008869', text:'#002736', iconBg:'#e6f7ee', iconColor:'#008869', emoji:'✅' },
                warning: { bg:'#fffbeb', border:'#FBE83F', text:'#7a6100', iconBg:'#fef9c3', iconColor:'#b45309', emoji:'⚠️' },
                danger:  { bg:'#fef3f3', border:'#F34747', text:'#7a1f1f', iconBg:'#fdecec', iconColor:'#F34747', emoji:'❌' }
            };
            var c = colors[type] || colors.info;

            $('#wcup-notice-preview-box').css({
                background: c.bg,
                borderColor: c.border
            });
            $('#wcup-preview-icon').css({
                background: c.iconBg,
                color: c.iconColor
            }).text(c.emoji);
            $('#wcup-preview-title').css('color', c.text);
            $('#wcup-preview-content').css('color', c.text);

            var closeBtn = $('#wcup-preview-close');
            if (dismissible) {
                if (closeBtn.length === 0) {
                    $('#wcup-notice-preview-box').append(
                        '<div id="wcup-preview-close" style="width:26px;height:26px;border-radius:8px;background:rgba(0,0,0,.05);display:flex;align-items:center;justify-content:center;color:#666;font-size:14px;flex-shrink:0;">×</div>'
                    );
                }
            } else {
                closeBtn.remove();
            }
        }

        $('#wcup_notice_type, #wcup_notice_priority, #wcup_notice_dismissible').on('change', updatePreview);

        $('#title, #content').on('input change keyup', function(){
            var title   = $('#title').val() || 'عنوان اطلاعیه';
            var content = '';
            if (window.tinymce && tinymce.get('content')) {
                content = tinymce.get('content').getContent();
            } else {
                content = $('#content').val();
            }
            if (!content.trim()) content = 'محتوای اطلاعیه اینجا نمایش داده می‌شه...';

            $('#wcup-preview-title').text(title);
            $('#wcup-preview-content').html('<p>' + content + '</p>');
        });
    });
    </script>
    <?php
}

/* ═══════════════════════════════════════════════════════
 *  ذخیره متا
 * ═══════════════════════════════════════════════════════ */
add_action( 'save_post_' . wcup_notice::POST_TYPE, 'wcup_notice_save_meta' );

function wcup_notice_save_meta( $post_id ) {

    if ( ! isset( $_POST[ wcup_notice::NONCE_FLD ] ) ||
         ! wp_verify_nonce( $_POST[ wcup_notice::NONCE_FLD ], wcup_notice::NONCE_KEY ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    update_post_meta(
        $post_id,
        '_wcup_notice_type',
        sanitize_key( $_POST['wcup_notice_type'] ?? 'info' )
    );

    update_post_meta(
        $post_id,
        '_wcup_notice_priority',
        sanitize_key( $_POST['wcup_notice_priority'] ?? 'normal' )
    );

    update_post_meta(
        $post_id,
        '_wcup_notice_dismissible',
        isset( $_POST['wcup_notice_dismissible'] ) ? '1' : '0'
    );
}

/* ═══════════════════════════════════════════════════════
 *  ستون‌های لیست ادمین
 * ═══════════════════════════════════════════════════════ */
add_filter( 'manage_' . wcup_notice::POST_TYPE . '_posts_columns', 'wcup_notice_admin_columns' );

function wcup_notice_admin_columns( $columns ) {

    $new = array();

    foreach ( $columns as $key => $label ) {

        $new[ $key ] = $label;

        if ( 'title' === $key ) {
            $new['wcup_type']        = 'نوع';
            $new['wcup_priority']    = 'اولویت';
            $new['wcup_dismissible'] = 'قابل بستن';
        }
    }

    return $new;
}

add_action( 'manage_' . wcup_notice::POST_TYPE . '_posts_custom_column', 'wcup_notice_admin_column_content', 10, 2 );

function wcup_notice_admin_column_content( $column, $post_id ) {

    switch ( $column ) {

        case 'wcup_type':
            $type = get_post_meta( $post_id, '_wcup_notice_type', true ) ?: 'info';
            $map  = array(
                'info'    => array( 'label' => 'ℹ️ اطلاع',  'bg' => '#e6f4f7', 'color' => '#3897A9' ),
                'success' => array( 'label' => '✅ موفقیت', 'bg' => '#e6f7ee', 'color' => '#008869' ),
                'warning' => array( 'label' => '⚠️ هشدار',  'bg' => '#fef9c3', 'color' => '#b45309' ),
                'danger'  => array( 'label' => '❌ مهم',    'bg' => '#fdecec', 'color' => '#F34747' ),
            );
            $data = isset( $map[ $type ] ) ? $map[ $type ] : $map['info'];
            printf(
                '<span style="background:%s;color:%s;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:700;">%s</span>',
                esc_attr( $data['bg'] ),
                esc_attr( $data['color'] ),
                esc_html( $data['label'] )
            );
            break;

        case 'wcup_priority':
            $priority = get_post_meta( $post_id, '_wcup_notice_priority', true ) ?: 'normal';
            if ( 'high' === $priority ) {
                echo '<span style="background:#FBE83F;color:#7a6100;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:700;">⚡ بالا</span>';
            } else {
                echo '<span style="color:#7C8289;font-size:12px;">—</span>';
            }
            break;

        case 'wcup_dismissible':
            $d = get_post_meta( $post_id, '_wcup_notice_dismissible', true );
            $d = ( $d === '' ) ? '1' : $d;
            if ( '1' === $d ) {
                echo '<span style="color:#008869;font-size:16px;" title="قابل بستن">✅</span>';
            } else {
                echo '<span style="color:#F34747;font-size:16px;" title="غیرقابل بستن">🔒</span>';
            }
            break;
    }
}

/* ═══════════════════════════════════════════════════════
 *  استایل ادمین
 * ═══════════════════════════════════════════════════════ */
add_action( 'admin_head', 'wcup_notice_admin_styles' );

function wcup_notice_admin_styles() {

    $screen = get_current_screen();
    if ( ! $screen || wcup_notice::POST_TYPE !== $screen->post_type ) {
        return;
    }
    ?>
    <style>
        .post-type-wcup_notice .wp-list-table .column-wcup_type,
        .post-type-wcup_notice .wp-list-table .column-wcup_priority,
        .post-type-wcup_notice .wp-list-table .column-wcup_dismissible {
            width: 100px;
            text-align: center;
        }

        .wcup-notice-meta p { margin: 0 0 16px; }
        .wcup-notice-meta select {
            padding: 8px 12px;
            border-radius: 8px;
            border: 1px solid #d0d5da;
            font-family: inherit;
            font-size: 13px;
        }
        .wcup-notice-meta select:focus {
            border-color: #3897A9;
            box-shadow: 0 0 0 2px rgba(56,151,169,.15);
            outline: none;
        }
    </style>
    <?php
}