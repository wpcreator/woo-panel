<?php
defined( 'ABSPATH' ) || exit;

/* ═══ آمار زنده ═══ */
$user_count  = count_users();
$total_users = isset( $user_count['total_users'] ) ? (int) $user_count['total_users'] : 0;

$orders_total = 0;
$orders_pend  = 0;
$orders_done  = 0;
$orders_today = 0;

if ( function_exists( 'wc_get_orders' ) ) {
    $orders_total = (int) wc_get_orders( array( 'limit' => -1, 'return' => 'ids', 'status' => 'any',        'paginate' => true ) )->total ?? 0;
    $orders_pend  = (int) wc_get_orders( array( 'limit' => -1, 'return' => 'ids', 'status' => 'pending',    'paginate' => true ) )->total ?? 0;
    $orders_done  = (int) wc_get_orders( array( 'limit' => -1, 'return' => 'ids', 'status' => 'completed',  'paginate' => true ) )->total ?? 0;

    /* سفارشات امروز */
    $orders_today = (int) wc_get_orders( array(
        'limit'        => -1,
        'return'       => 'ids',
        'paginate'     => true,
        'date_created' => '>' . ( time() - DAY_IN_SECONDS ),
    ) )->total ?? 0;
}

$notices_count = 0;
$counts = wp_count_posts( 'wcup_notice' );
if ( $counts && isset( $counts->publish ) ) {
    $notices_count = (int) $counts->publish;
}

/* ═══ درصد تکمیل هر آمار ═══ */
$pct_pending = $orders_total ? round( ( $orders_pend / $orders_total ) * 100 ) : 0;
$pct_done    = $orders_total ? round( ( $orders_done / $orders_total ) * 100 ) : 0;

/* ═══ تنظیمات ═══ */
$settings = wcup_settings::get();

/* ═══ ۵ کاربر آخر ═══ */
$recent_users = get_users( array(
    'number'  => 5,
    'orderby' => 'registered',
    'order'   => 'DESC',
) );

/* ═══ ۵ سفارش آخر ═══ */
$recent_orders = function_exists( 'wc_get_orders' ) ? wc_get_orders( array(
    'limit'   => 5,
    'orderby' => 'date',
    'order'   => 'DESC',
    'status'  => 'any',
) ) : array();

/* ═══ ۵ اطلاعیه آخر ═══ */
$recent_notices = get_posts( array(
    'post_type'      => 'wcup_notice',
    'posts_per_page' => 5,
    'post_status'    => 'publish',
) );
?>
<div class="wrap wcup-wrap">

    <!-- ═══ Header ═══ -->
    <div class="wcup-header">
        <div>
            <h1 class="wcup-title">📊 داشبورد پنل کاربری</h1>
            <p class="wcup-header-sub">خوش آمدی! خلاصهٔ وضعیت پنل کاربری اینجاست.</p>
        </div>
        <div class="wcup-header-actions">
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wcup-myaccount-general' ) ); ?>" class="button button-primary">
                ⚙️ تنظیمات
            </a>
            <a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="button" target="_blank">
                👁️ مشاهدهٔ پنل
            </a>
        </div>
    </div>

    <!-- ═══ کارت‌های آماری ═══ -->
    <div class="wcup-cards">

        <div class="wcup-card wcup-card--primary">
            <div class="wcup-card-icon">👥</div>
            <div class="wcup-card-body">
                <div class="wcup-card-value"><?php echo esc_html( wcup_fa_num( $total_users ) ); ?></div>
                <div class="wcup-card-label">کاربران</div>
            </div>
        </div>

        <div class="wcup-card wcup-card--success">
            <div class="wcup-card-icon">🛒</div>
            <div class="wcup-card-body">
                <div class="wcup-card-value"><?php echo esc_html( wcup_fa_num( $orders_total ) ); ?></div>
                <div class="wcup-card-label">کل سفارش‌ها</div>
            </div>
        </div>

        <div class="wcup-card wcup-card--warning">
            <div class="wcup-card-icon">⏳</div>
            <div class="wcup-card-body">
                <div class="wcup-card-value"><?php echo esc_html( wcup_fa_num( $orders_pend ) ); ?></div>
                <div class="wcup-card-label">در انتظار</div>
            </div>
        </div>

        <div class="wcup-card wcup-card--info">
            <div class="wcup-card-icon">📢</div>
            <div class="wcup-card-body">
                <div class="wcup-card-value"><?php echo esc_html( wcup_fa_num( $notices_count ) ); ?></div>
                <div class="wcup-card-label">اطلاعیه‌ها</div>
            </div>
        </div>

    </div>

    <!-- ═══ نمودارهای میلگردی ═══ -->
    <div class="wcup-panel">
        <h2 class="wcup-panel-title">📈 نگاه سریع به سفارش‌ها</h2>

        <div class="wcup-bars">

            <div class="wcup-bar-item">
                <div class="wcup-bar-header">
                    <span>✅ تکمیل شده</span>
                    <strong><?php echo esc_html( wcup_fa_num( $orders_done ) ); ?></strong>
                </div>
                <div class="wcup-bar-track">
                    <div class="wcup-bar-fill wcup-bar-fill--success" style="width: <?php echo esc_attr( $pct_done ); ?>%;"></div>
                </div>
                <span class="wcup-bar-pct"><?php echo esc_html( wcup_fa_num( $pct_done ) ); ?>%</span>
            </div>

            <div class="wcup-bar-item">
                <div class="wcup-bar-header">
                    <span>⏳ در انتظار</span>
                    <strong><?php echo esc_html( wcup_fa_num( $orders_pend ) ); ?></strong>
                </div>
                <div class="wcup-bar-track">
                    <div class="wcup-bar-fill wcup-bar-fill--warning" style="width: <?php echo esc_attr( $pct_pending ); ?>%;"></div>
                </div>
                <span class="wcup-bar-pct"><?php echo esc_html( wcup_fa_num( $pct_pending ) ); ?>%</span>
            </div>

            <div class="wcup-bar-item">
                <div class="wcup-bar-header">
                    <span>📅 امروز</span>
                    <strong><?php echo esc_html( wcup_fa_num( $orders_today ) ); ?></strong>
                </div>
                <div class="wcup-bar-track">
                    <div class="wcup-bar-fill wcup-bar-fill--info" style="width: <?php echo esc_attr( min( 100, $orders_today * 10 ) ); ?>%;"></div>
                </div>
                <span class="wcup-bar-pct"><?php echo esc_html( wcup_fa_num( $orders_today ) ); ?> سفارش</span>
            </div>

        </div>
    </div>

    <!-- ═══ شبکهٔ دوستونه ═══ -->
    <div class="wcup-grid-2">

        <!-- وضعیت امکانات -->
        <div class="wcup-panel">
            <h2 class="wcup-panel-title">🎛️ وضعیت امکانات</h2>
            <table class="widefat striped wcup-table">
                <tbody>
                    <?php
                    $features = array(
                        'enabled'          => 'پنل کاربری',
                        'load_css'         => 'استایل اختصاصی',
                        'popup_notices'    => 'پاپ‌آپ پیام‌ها',
                        'persian_numbers'  => 'اعداد فارسی',
                        'avatar_upload'    => 'آپلود آواتار',
                        'tracking_enabled' => 'رهگیری سفارش',
                        'notices_enabled'  => 'اطلاعیه‌ها',
                        'progress_enabled' => 'نوار پیشرفت',
                    );

                    foreach ( $features as $key => $label ) :
                        $on = (int) ( $settings[ $key ] ?? 0 );
                        ?>
                        <tr>
                            <td style="width:60%;"><?php echo esc_html( $label ); ?></td>
                            <td>
                                <?php if ( $on ) : ?>
                                    <span class="wcup-badge wcup-badge--on">✅ فعال</span>
                                <?php else : ?>
                                    <span class="wcup-badge wcup-badge--off">⛔ غیرفعال</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- کاربران اخیر -->
        <div class="wcup-panel">
            <h2 class="wcup-panel-title">🆕 کاربران اخیر</h2>
            <table class="widefat striped wcup-table">
                <thead>
                    <tr>
                        <th>کاربر</th>
                        <th>تاریخ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( ! empty( $recent_users ) ) : ?>
                        <?php foreach ( $recent_users as $u ) : ?>
                            <tr>
                                <td>
                                    <div class="wcup-user-row">
                                        <?php echo get_avatar( $u->ID, 32, '', '', array( 'class' => 'wcup-user-avatar' ) ); ?>
                                        <div class="wcup-user-info">
                                            <strong><?php echo esc_html( $u->display_name ); ?></strong>
                                            <div class="wcup-user-email"><?php echo esc_html( $u->user_email ); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo esc_html( wcup_fa_num( date_i18n( 'Y/m/d', strtotime( $u->user_registered ) ) ) ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr><td colspan="2">کاربری وجود ندارد.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>

    <!-- ═══ سفارشات اخیر ═══ -->
    <?php if ( ! empty( $recent_orders ) ) : ?>
        <div class="wcup-panel">
            <h2 class="wcup-panel-title">🛒 سفارشات اخیر</h2>
            <table class="widefat striped wcup-table">
                <thead>
                    <tr>
                        <th>#سفارش</th>
                        <th>مشتری</th>
                        <th>وضعیت</th>
                        <th>مبلغ</th>
                        <th>تاریخ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $recent_orders as $order ) :
                        if ( ! $order instanceof WC_Order ) continue;
                        $status = $order->get_status();
                        $status_map = array(
                            'pending'    => array( 'label' => 'در انتظار',   'color' => '#FBE83F' ),
                            'processing' => array( 'label' => 'در حال انجام', 'color' => '#3897A9' ),
                            'on-hold'    => array( 'label' => 'بررسی',       'color' => '#FBE83F' ),
                            'completed'  => array( 'label' => 'تکمیل شده',   'color' => '#008869' ),
                            'cancelled'  => array( 'label' => 'لغو شده',     'color' => '#F34747' ),
                            'refunded'   => array( 'label' => 'مسترد شده',   'color' => '#886EA5' ),
                            'failed'     => array( 'label' => 'ناموفق',      'color' => '#F34747' ),
                        );
                        $s = isset( $status_map[ $status ] ) ? $status_map[ $status ] : array( 'label' => $status, 'color' => '#7C8289' );
                    ?>
                        <tr>
                            <td>
                                <a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>">
                                    <strong>#<?php echo esc_html( wcup_fa_num( $order->get_order_number() ) ); ?></strong>
                                </a>
                            </td>
                            <td><?php echo esc_html( $order->get_formatted_billing_full_name() ?: '—' ); ?></td>
                            <td>
                                <span style="background: <?php echo esc_attr( $s['color'] ); ?>33; color: <?php echo esc_attr( $s['color'] ); ?>; padding: 3px 10px; border-radius: 6px; font-size: 11px; font-weight: 700;">
                                    <?php echo esc_html( $s['label'] ); ?>
                                </span>
                            </td>
                            <td><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></td>
                            <td><?php echo esc_html( $order->get_date_created() ? wcup_fa_num( date_i18n( 'Y/m/d', $order->get_date_created()->getTimestamp() ) ) : '—' ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <!-- ═══ لینک‌های سریع ═══ -->
    <div class="wcup-panel">
        <h2 class="wcup-panel-title">⚡ دسترسی سریع</h2>
        <div class="wcup-quick-links">

            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wcup-myaccount-general' ) ); ?>" class="wcup-quick-link">
                <span class="wcup-quick-icon">⚙️</span>
                <span class="wcup-quick-label">تنظیمات</span>
            </a>

            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wcup-myaccount-menu' ) ); ?>" class="wcup-quick-link">
                <span class="wcup-quick-icon">📋</span>
                <span class="wcup-quick-label">منوی حساب</span>
            </a>

            <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wcup_notice' ) ); ?>" class="wcup-quick-link">
                <span class="wcup-quick-icon">📢</span>
                <span class="wcup-quick-label">اطلاعیه‌ها</span>
            </a>

            <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=wcup_notice&action=new' ) ); ?>" class="wcup-quick-link">
                <span class="wcup-quick-icon">➕</span>
                <span class="wcup-quick-label">اطلاعیه جدید</span>
            </a>

            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wcup-myaccount-tools#export' ) ); ?>" class="wcup-quick-link">
                <span class="wcup-quick-icon">💾</span>
                <span class="wcup-quick-label">پشتیبان‌گیری</span>
            </a>

            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wcup-myaccount-tools#repair' ) ); ?>" class="wcup-quick-link">
                <span class="wcup-quick-icon">🔧</span>
                <span class="wcup-quick-label">بازسازی</span>
            </a>

        </div>
    </div>

</div>