<?php
defined( 'ABSPATH' ) || exit;

$s = wcup_settings::get();

$steps = array(
    'progress_first_name'    => 'نام',
    'progress_last_name'     => 'نام خانوادگی',
    'progress_email'         => 'ایمیل',
    'progress_avatar'        => 'عکس پروفایل',
    'progress_phone'         => 'شماره تماس',
    'progress_address'       => 'آدرس',
    'progress_city'          => 'شهر',
    'progress_postcode'      => 'کد پستی',
);
?>
<div class="wrap wcup-wrap">

    <h1 class="wcup-title">📈 نوار پیشرفت پروفایل</h1>

    <form method="post" action="options.php" class="wcup-form">
        <?php settings_fields( 'wcup_settings_group' ); ?>

        <div class="wcup-panel">
            <table class="form-table">
                <tr>
                    <th scope="row">فعال بودن</th>
                    <td>
                        <label class="wcup-switch">
                            <input type="hidden" name="wcup_settings[progress_enabled]" value="0">
                            <input type="checkbox"
                                   name="wcup_settings[progress_enabled]"
                                   value="1"
                                   <?php checked( (int) ( $s['progress_enabled'] ?? 1 ), 1 ); ?>>
                            <span class="wcup-switch-slider"></span>
                        </label>
                    </td>
                </tr>
            </table>
        </div>

        <div class="wcup-panel">
            <h2>مراحل شمارش‌شده</h2>
            <table class="widefat striped wcup-table">
                <thead>
                    <tr>
                        <th style="width:60%;">مرحله</th>
                        <th>وضعیت</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $steps as $key => $label ) : ?>
                    <tr>
                        <td><?php echo esc_html( $label ); ?></td>
                        <td>
                            <label class="wcup-switch">
                                <input type="hidden" name="wcup_settings[<?php echo esc_attr( $key ); ?>]" value="0">
                                <input type="checkbox"
                                       name="wcup_settings[<?php echo esc_attr( $key ); ?>]"
                                       value="1"
                                       <?php checked( (int) ( $s[ $key ] ?? 1 ), 1 ); ?>>
                                <span class="wcup-switch-slider"></span>
                            </label>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php submit_button( 'ذخیرهٔ تنظیمات' ); ?>
    </form>

</div>