<?php
defined( 'ABSPATH' ) || exit;

$message      = '';
$message_type = 'success';

/* ═══════════════════════════════════════════════════════
 *  اجرای اکشن‌ها
 * ═══════════════════════════════════════════════════════ */
if ( isset( $_POST['wcup_action'], $_POST['wcup_tools_nonce'] ) &&
     wp_verify_nonce( $_POST['wcup_tools_nonce'], 'wcup_tools' ) &&
     current_user_can( 'manage_options' ) ) {

    $action = sanitize_key( $_POST['wcup_action'] );

    switch ( $action ) {

        case 'flush_rewrite':
            flush_rewrite_rules();
            $message = 'Rewrite rules با موفقیت پاک شد.';
            break;

        case 'rerun_migration':
            delete_option( 'wcup_db_version' );
            $message = 'Migration در رفرش بعدی دوباره اجرا می‌شه.';
            break;

        case 'clear_avatar_cache':
            global $wpdb;
            $deleted = $wpdb->query(
                "DELETE FROM {$wpdb->options}
                 WHERE option_name LIKE '_transient_wcup_avatar_%'
                 OR option_name LIKE '_transient_timeout_wcup_avatar_%'"
            );
            $message = 'کش آواتار پاک شد (' . (int) $deleted . ' رکورد).';
            break;

        case 'clear_all_transients':
            global $wpdb;
            $deleted = $wpdb->query(
                "DELETE FROM {$wpdb->options}
                 WHERE option_name LIKE '_transient_wcup_%'
                 OR option_name LIKE '_transient_timeout_wcup_%'"
            );
            $message = 'همهٔ Transient های WCUP پاک شدن (' . (int) $deleted . ' رکورد).';
            break;

        case 'migrate_wishlist_yith':
            if ( class_exists( 'wcup_wishlist' ) ) {
                $result = wcup_wishlist::migrate_from_yith();

                if ( $result['success'] ) {
                    $message = sprintf(
                        '✅ %d رکورد از %s منتقل شد (خطا: %d)',
                        $result['migrated'],
                        $result['source'],
                        $result['errors']
                    );
                } else {
                    $message      = $result['message'] ?? 'خطا در مهاجرت.';
                    $message_type = 'error';
                }
            }
            break;

        case 'migrate_wishlist_ti':
            if ( class_exists( 'wcup_wishlist' ) ) {
                $result = wcup_wishlist::migrate_from_ti();

                if ( $result['success'] ) {
                    $message = sprintf(
                        '✅ %d رکورد از %s منتقل شد (خطا: %d)',
                        $result['migrated'],
                        $result['source'],
                        $result['errors']
                    );
                } else {
                    $message      = $result['message'] ?? 'خطا در مهاجرت.';
                    $message_type = 'error';
                }
            }
            break;

        case 'migrate_wishlist_meta':
            if ( class_exists( 'wcup_wishlist' ) ) {
                $result = wcup_wishlist::migrate_from_meta();

                if ( $result['success'] ) {
                    $message = sprintf(
                        '✅ %d رکورد از %s منتقل شد (خطا: %d)',
                        $result['migrated'],
                        $result['source'],
                        $result['errors']
                    );
                } else {
                    $message      = $result['message'] ?? 'خطا در مهاجرت.';
                    $message_type = 'error';
                }
            }
            break;
			
        case 'reset_settings':
            delete_option( 'wcup_settings' );
            update_option( 'wcup_settings', wcup_settings::get_defaults() );
            delete_option( 'wcup_settings_repaired' );
            $message = 'تنظیمات به حالت پیش‌فرض برگشت.';
            break;

        case 'export_settings':
            $settings = wcup_settings::get();
            $payload  = array(
                'plugin'    => 'WCUP Account',
                'version'   => defined( 'WCUP_VERSION' ) ? WCUP_VERSION : '1.0.0',
                'exported'  => current_time( 'mysql' ),
                'settings'  => $settings,
            );
            $json = wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );

            header( 'Content-Type: application/json; charset=utf-8' );
            header( 'Content-Disposition: attachment; filename="wcup-settings-' . date( 'Y-m-d-His' ) . '.json"' );
            echo $json;
            exit;

        case 'import_settings':
            if ( ! empty( $_FILES['wcup_import_file']['tmp_name'] ) ) {
                $content = file_get_contents( $_FILES['wcup_import_file']['tmp_name'] );
                $data    = json_decode( $content, true );

                if ( is_array( $data ) ) {
                    /* پشتیبانی از فرمت جدید (با کلید settings) */
                    if ( isset( $data['settings'] ) && is_array( $data['settings'] ) ) {
                        $data = $data['settings'];
                    }

                    wcup_settings::update( $data );
                    $message = 'تنظیمات با موفقیت وارد شد.';
                } else {
                    $message      = 'فایل نامعتبر است.';
                    $message_type = 'error';
                }
            } else {
                $message      = 'فایلی انتخاب نشده.';
                $message_type = 'error';
            }
            break;
    }
}

/* ═══ اطلاعات سیستم ═══ */
$is_hpos = class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
    && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();

$db_size = 0;
global $wpdb;
if ( $wpdb ) {
    $db_size = (int) $wpdb->get_var( "SELECT SUM(data_length + index_length) FROM information_schema.TABLES WHERE table_schema = DATABASE()" );
}
?>
<div class="wrap wcup-wrap">

    <div class="wcup-header">
        <div>
            <h1 class="wcup-title">🛠️ ابزارها</h1>
            <p class="wcup-header-sub">نگهداری، پشتیبان‌گیری و بازیابی پنل کاربری</p>
        </div>
    </div>

    <?php if ( $message ) : ?>
        <div class="notice notice-<?php echo esc_attr( $message_type ); ?> is-dismissible">
            <p><?php echo esc_html( $message ); ?></p>
        </div>
    <?php endif; ?>

    <!-- ═══ نگهداری ═══ -->
    <form method="post" enctype="multipart/form-data" id="repair">
        <?php wp_nonce_field( 'wcup_tools', 'wcup_tools_nonce' ); ?>

        <div class="wcup-panel">
            <h2 class="wcup-panel-title">🔧 ابزارهای نگهداری</h2>
            <table class="widefat striped">
                <tbody>
                    <tr>
                        <td>
                            <strong>Flush Rewrite Rules</strong>
                            <p class="description">اگه endpoint «نظرات شما» یا «اطلاعیه‌ها» کار نمی‌کنه، این رو بزن.</p>
                        </td>
                        <td style="width:20%;text-align:left;">
                            <button type="submit" name="wcup_action" value="flush_rewrite" class="button">اجرا</button>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong>اجرای دوباره Migration</strong>
                            <p class="description">⚠️ انتقال متاهای قدیمی wclm_* به wcup_* دوباره اجرا می‌شه.</p>
                        </td>
                        <td style="text-align:left;">
                            <button type="submit" name="wcup_action" value="rerun_migration" class="button">اجرا</button>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong>پاک‌سازی کش آواتار</strong>
                            <p class="description">Transient های آواتار پاک می‌شن.</p>
                        </td>
                        <td style="text-align:left;">
                            <button type="submit" name="wcup_action" value="clear_avatar_cache" class="button">اجرا</button>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <strong>پاک‌سازی همهٔ کش‌ها</strong>
                            <p class="description">همهٔ Transient های WCUP پاک می‌شن.</p>
                        </td>
                        <td style="text-align:left;">
                            <button type="submit" name="wcup_action" value="clear_all_transients" class="button">اجرا</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- ═══ مهاجرت علاقه‌مندی‌ها ═══ -->
        <div class="wcup-panel">
            <h2 class="wcup-panel-title">📦 مهاجرت علاقه‌مندی‌ها</h2>
            <p>
                اگر قبلاً از پلاگین‌های YITH Wishlist یا TI Wishlist استفاده می‌کردی،
                می‌تونی داده‌های علاقه‌مندی کاربران رو به سیستم داخلی WCUP منتقل کنی.
            </p>

            <?php
            /* آمار */
            if ( class_exists( 'wcup_wishlist' ) ) {
                $stats = wcup_wishlist::get_plugin_stats();
                ?>

                <table class="widefat striped" style="margin: 16px 0;">
                    <thead>
                        <tr>
                            <th>سیستم</th>
                            <th style="width:120px;text-align:center;">وضعیت</th>
                            <th style="width:120px;text-align:center;">تعداد رکورد</th>
                        </tr>
                    </thead>
                    <tbody>

                        <tr>
                            <td>YITH WooCommerce Wishlist</td>
                            <td style="text-align:center;">
                                <?php if ( $stats['yith']['detected'] ) : ?>
                                    <span class="wcup-badge wcup-badge--on">✅ شناسایی شد</span>
                                <?php else : ?>
                                    <span class="wcup-badge wcup-badge--off">— نصب نیست</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:center;">
                                <strong><?php echo esc_html( wcup_helpers::fa_num( $stats['yith']['count'] ) ); ?></strong>
                            </td>
                        </tr>

                        <tr>
                            <td>TI WooCommerce Wishlist</td>
                            <td style="text-align:center;">
                                <?php if ( $stats['ti']['detected'] ) : ?>
                                    <span class="wcup-badge wcup-badge--on">✅ شناسایی شد</span>
                                <?php else : ?>
                                    <span class="wcup-badge wcup-badge--off">— نصب نیست</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:center;">
                                <strong><?php echo esc_html( wcup_helpers::fa_num( $stats['ti']['count'] ) ); ?></strong>
                            </td>
                        </tr>

                        <tr>
                            <td>Meta عمومی</td>
                            <td style="text-align:center;">
                                <?php if ( $stats['generic']['detected'] ) : ?>
                                    <span class="wcup-badge wcup-badge--on">✅ شناسایی شد</span>
                                <?php else : ?>
                                    <span class="wcup-badge wcup-badge--off">— وجود ندارد</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:center;">
                                <strong><?php echo esc_html( wcup_helpers::fa_num( $stats['generic']['count'] ) ); ?></strong>
                            </td>
                        </tr>

                        <tr style="background:#f0f8fa;">
                            <td><strong>سیستم WCUP (فعلی)</strong></td>
                            <td style="text-align:center;"><span class="wcup-badge wcup-badge--on">✅ فعال</span></td>
                            <td style="text-align:center;">
                                <strong><?php echo esc_html( wcup_helpers::fa_num( $stats['total_users'] ) ); ?></strong>
                                <br><small>کاربر</small>
                            </td>
                        </tr>

                    </tbody>
                </table>

                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    <button type="submit"
                            name="wcup_action"
                            value="migrate_wishlist_yith"
                            class="button button-primary"
                            <?php disabled( ! $stats['yith']['detected'] ); ?>>
                        🔄 مهاجرت از YITH
                    </button>

                    <button type="submit"
                            name="wcup_action"
                            value="migrate_wishlist_ti"
                            class="button button-primary"
                            <?php disabled( ! $stats['ti']['detected'] ); ?>>
                        🔄 مهاجرت از TI
                    </button>

                    <button type="submit"
                            name="wcup_action"
                            value="migrate_wishlist_meta"
                            class="button"
                            onclick="return confirm('از Meta به WCUP منتقل بشه؟');"
                            <?php disabled( ! $stats['generic']['detected'] ); ?>>
                        🔄 مهاجرت از Meta
                    </button>
                </div>

                <p class="description" style="margin-top:12px;">
                    ⚠️ <strong>توجه:</strong> داده‌های قدیمی حذف نمی‌شن — فقط کپی می‌شن.
                    بعد از مهاجرت، می‌تونی پلاگین قبلی رو غیرفعال کنی.
                </p>

            <?php } ?>
        </div>

        <!-- ═══ Export ═══ -->
        <div class="wcup-panel" id="export">
            <h2 class="wcup-panel-title">💾 پشتیبان‌گیری</h2>
            <p>تنظیمات فعلی رو به صورت فایل JSON دانلود کن (شامل همهٔ تنظیمات پنل).</p>
            <button type="submit" name="wcup_action" value="export_settings" class="button button-primary">
                📥 دانلود فایل تنظیمات
            </button>
        </div>

        <!-- ═══ Import ═══ -->
        <div class="wcup-panel">
            <h2 class="wcup-panel-title">📤 بازیابی</h2>
            <p>یه فایل JSON انتخاب کن که قبلاً دانلود کردی.</p>

            <div class="wcup-import-row">
                <input type="file" name="wcup_import_file" accept="application/json,.json">
                <button type="submit" name="wcup_action" value="import_settings" class="button button-primary"
                        onclick="return confirm('مطمئنی؟ تنظیمات فعلی جایگزین می‌شن.');">
                    📤 بازیابی
                </button>
            </div>
        </div>

        <!-- ═══ Reset ═══ -->
        <div class="wcup-panel wcup-panel--danger">
            <h2 class="wcup-panel-title">⚠️ ناحیه خطر</h2>
            <p>با کلیک روی دکمهٔ زیر، همهٔ تنظیمات به حالت پیش‌فرض برمی‌گرده.</p>
            <button type="submit" name="wcup_action" value="reset_settings"
                    class="button button-link-delete"
                    onclick="return confirm('مطمئنی؟ همهٔ تنظیمات از دست می‌رن.');">
                🔄 بازگشت به پیش‌فرض
            </button>
        </div>

    </form>

    <!-- ═══ اطلاعات سیستم ═══ -->
    <div class="wcup-panel">
        <h2 class="wcup-panel-title">📋 اطلاعات سیستم</h2>
        <table class="widefat striped">
            <tbody>
                <tr><td style="width:35%;">نسخهٔ PHP</td><td><code><?php echo esc_html( PHP_VERSION ); ?></code></td></tr>
                <tr><td>نسخهٔ WordPress</td><td><code><?php echo esc_html( get_bloginfo( 'version' ) ); ?></code></td></tr>
                <tr><td>نسخهٔ ووکامرس</td><td><code><?php echo esc_html( defined( 'WC_VERSION' ) ? WC_VERSION : '—' ); ?></code></td></tr>
                <tr><td>نسخهٔ WCUP</td><td><code><?php echo esc_html( defined( 'WCUP_VERSION' ) ? WCUP_VERSION : '—' ); ?></code></td></tr>
                <tr><td>DB Version</td><td><code><?php echo esc_html( get_option( 'wcup_db_version', '0' ) ); ?></code></td></tr>
                <tr><td>HPOS</td><td><code><?php echo $is_hpos ? '✅ فعال' : '⛔ غیرفعال'; ?></code></td></tr>
                <tr><td>Memory Limit</td><td><code><?php echo esc_html( ini_get( 'memory_limit' ) ); ?></code></td></tr>
                <tr><td>Max Upload</td><td><code><?php echo esc_html( ini_get( 'upload_max_filesize' ) ); ?></code></td></tr>
                <tr><td>حجم دیتابیس</td><td><code><?php echo esc_html( size_format( $db_size, 2 ) ); ?></code></td></tr>
                <tr><td>Debug Mode</td><td><code><?php echo ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? '✅ فعال' : '⛔ غیرفعال'; ?></code></td></tr>
            </tbody>
        </table>
    </div>

</div>