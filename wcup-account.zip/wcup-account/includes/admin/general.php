<?php
defined( 'ABSPATH' ) || exit;

$s = wcup_settings::get();
$fields = array(
    'enabled'         => array( 'label' => 'فعال بودن پنل کاربری',       'desc' => 'غیرفعال کردن کل افزونه' ),
    'load_css'        => array( 'label' => 'بارگذاری استایل اختصاصی',     'desc' => 'CSS پنل کاربری بارگذاری بشه' ),
    'popup_notices'   => array( 'label' => 'پاپ‌آپ پیام‌ها',              'desc' => 'پیام‌های ووکامرس به صورت Modal نمایش داده بشن' ),
    'persian_numbers' => array( 'label' => 'اعداد فارسی',                 'desc' => 'تبدیل اعداد به فارسی در قالب‌ها' ),
    'avatar_upload'   => array( 'label' => 'آپلود عکس پروفایل',           'desc' => 'کاربر بتونه عکس پروفایل آپلود کنه' ),
    'remove_wc_styles'=> array( 'label' => 'حذف استایل پیش‌فرض ووکامرس',  'desc' => '⚠️ فقط اگر قالب اختصاصی داری' ),
);

$default_avatar_id  = (int) ( $s['default_avatar_id'] ?? 0 );
$default_avatar_url = $default_avatar_id
    ? wp_get_attachment_image_url( $default_avatar_id, 'thumbnail' )
    : '';

$placeholder_url = function_exists( 'wc_placeholder_img_src' )
    ? wc_placeholder_img_src()
    : includes_url( 'images/media/default.png' );
?>
<div class="wrap wcup-wrap">

    <h1 class="wcup-title">⚙️ تنظیمات عمومی</h1>

    <form method="post" action="options.php" class="wcup-form">
        <?php settings_fields( 'wcup_settings_group' ); ?>

        <div class="wcup-panel">
            <table class="form-table">
                <tbody>
                <?php foreach ( $fields as $key => $field ) : ?>
                    <tr>
                        <th scope="row"><?php echo esc_html( $field['label'] ); ?></th>
                        <td>
                            <label class="wcup-switch">
                                <input type="hidden" name="wcup_settings[<?php echo esc_attr( $key ); ?>]" value="0">
                                <input type="checkbox"
                                       name="wcup_settings[<?php echo esc_attr( $key ); ?>]"
                                       value="1"
                                       <?php checked( (int) ( $s[ $key ] ?? 0 ), 1 ); ?>>
                                <span class="wcup-switch-slider"></span>
                            </label>
                            <p class="description"><?php echo esc_html( $field['desc'] ); ?></p>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <!-- ═══ آواتار پیش‌فرض ═══ -->
                <tr>
                    <th scope="row">آواتار پیش‌فرض</th>
                    <td>
                        <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
                            <img id="wcup-default-avatar-preview"
                                 src="<?php echo esc_url( $default_avatar_url ?: $placeholder_url ); ?>"
                                 style="width:60px;height:60px;border-radius:50%;object-fit:cover;border:2px solid #e0e5e9;background:#f0f2f5;">
                            <input type="hidden"
                                   name="wcup_settings[default_avatar_id]"
                                   id="wcup-default-avatar-id"
                                   value="<?php echo esc_attr( $default_avatar_id ); ?>">
                            <button type="button" class="button" id="wcup-select-default-avatar">انتخاب تصویر</button>
                            <button type="button" class="button" id="wcup-remove-default-avatar">حذف</button>
                        </div>
                        <p class="description">
                            آواتاری که به‌طور پیش‌فرض به کاربرانی که عکس ندارن نمایش داده می‌شه.<br>
                            اگه خالی باشه، از فایل <code>assets/img/default-avatar.png</code> استفاده می‌شه.
                        </p>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>

        <?php submit_button( 'ذخیرهٔ تنظیمات' ); ?>
    </form>

</div>

<script>
jQuery(function($){
    var frame;
    $('#wcup-select-default-avatar').on('click', function(e){
        e.preventDefault();
        if (frame) { frame.open(); return; }
        frame = wp.media({
            title: 'انتخاب آواتار پیش‌فرض',
            button: { text: 'استفاده' },
            multiple: false,
            library: { type: 'image' }
        });
        frame.on('select', function(){
            var att = frame.state().get('selection').first().toJSON();
            $('#wcup-default-avatar-id').val(att.id);
            var src = (att.sizes && att.sizes.thumbnail) ? att.sizes.thumbnail.url : att.url;
            $('#wcup-default-avatar-preview').attr('src', src);
        });
        frame.open();
    });
    $('#wcup-remove-default-avatar').on('click', function(e){
        e.preventDefault();
        $('#wcup-default-avatar-id').val('0');
        $('#wcup-default-avatar-preview').attr('src', '<?php echo esc_url( $placeholder_url ); ?>');
    });
});
</script>