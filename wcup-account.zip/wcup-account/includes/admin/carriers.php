<?php
defined( 'ABSPATH' ) || exit;

$s        = wcup_settings::get();
$carriers = isset( $s['carriers'] ) && is_array( $s['carriers'] ) ? $s['carriers'] : array();
?>
<div class="wrap wcup-wrap">

    <div class="wcup-header">
        <div>
            <h1 class="wcup-title">🚚 شرکت‌های حمل و نقل</h1>
            <p class="wcup-header-sub">شرکت‌های حمل رو مدیریت کن و لینک رهگیری هر کدوم رو تنظیم کن.</p>
        </div>
    </div>

    <!-- راهنما -->
    <div class="wcup-panel wcup-panel--info">
        <div style="display:flex;gap:12px;align-items:flex-start;">
            <span style="font-size:22px;">💡</span>
            <div>
                <strong style="color:#002736;display:block;margin-bottom:4px;">راهنما</strong>
                <ul style="margin:0;padding-right:20px;font-size:13px;color:#7C8289;line-height:1.9;">
                    <li>در لینک رهگیری، از <code>{code}</code> استفاده کن — جای کد رهگیری قرار می‌گیره.</li>
                    <li>مثال: <code>https://tracking.post.ir/?id={code}</code></li>
                    <li>اگه شرکت لینک رهگیری نداره (مثل پیک)، فیلد لینک رو خالی بذار.</li>
                    <li>شرکت‌هایی که تیک «فعال» ندارن، توی فرم سفارش نمایش داده نمی‌شن.</li>
                </ul>
            </div>
        </div>
    </div>

    <form method="post" action="options.php" class="wcup-form" id="wcup-carriers-form">
        <?php settings_fields( 'wcup_settings_group' ); ?>

        <!-- ═══ تنظیمات کلی ═══ -->
        <div class="wcup-panel">
            <h2 class="wcup-panel-title">⚙️ تنظیمات کلی</h2>
            <table class="form-table">
                <tr>
                    <th scope="row" style="width:200px;">فعال بودن رهگیری</th>
                    <td>
                        <label class="wcup-switch">
                            <input type="hidden" name="wcup_settings[tracking_enabled]" value="0">
                            <input type="checkbox"
                                   name="wcup_settings[tracking_enabled]"
                                   value="1"
                                   <?php checked( (int) ( $s['tracking_enabled'] ?? 1 ), 1 ); ?>>
                            <span class="wcup-switch-slider"></span>
                        </label>
                        <p class="description">نمایش کد رهگیری روی صفحهٔ جزئیات سفارش کاربر</p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- ═══ لیست شرکت‌ها ═══ -->
        <div class="wcup-panel">
            <div class="wcup-panel-head-row">
                <h2 class="wcup-panel-title" style="border:none;padding:0;margin:0;">📋 لیست شرکت‌ها</h2>
                <button type="button" class="button button-secondary" id="wcup-add-carrier">
                    ➕ افزودن شرکت
                </button>
            </div>

            <table class="widefat striped wcup-table wcup-carriers-table" style="margin-top:16px;">
                <thead>
                    <tr>
                        <th style="width:20%;">نام شرکت</th>
                        <th style="width:15%;">کلید (Key)</th>
                        <th>الگوی لینک رهگیری</th>
                        <th style="width:80px;text-align:center;">فعال</th>
                        <th style="width:60px;"></th>
                    </tr>
                </thead>
                <tbody id="wcup-carriers-body">
                    <?php $i = 0; foreach ( $carriers as $c ) :
                        $key     = isset( $c['key'] )     ? $c['key']     : '';
                        $label   = isset( $c['label'] )   ? $c['label']   : '';
                        $url     = isset( $c['url'] )     ? $c['url']     : '';
                        $enabled = ! empty( $c['enabled'] );
                    ?>
                        <tr class="wcup-carrier-row">
                            <td>
                                <input type="text"
                                       name="wcup_settings[carriers][<?php echo $i; ?>][label]"
                                       value="<?php echo esc_attr( $label ); ?>"
                                       class="widefat wcup-carrier-label"
                                       placeholder="مثال: پست جمهوری اسلامی">
                            </td>
                            <td>
                                <input type="text"
                                       name="wcup_settings[carriers][<?php echo $i; ?>][key]"
                                       value="<?php echo esc_attr( $key ); ?>"
                                       class="widefat wcup-carrier-key"
                                       placeholder="post"
                                       pattern="[a-z0-9_\-]*">
                                <small style="color:#7C8289;font-size:11px;">حروف کوچک انگلیسی</small>
                            </td>
                            <td>
                                <input type="text"
                                       name="wcup_settings[carriers][<?php echo $i; ?>][url]"
                                       value="<?php echo esc_attr( $url ); ?>"
                                       class="widefat wcup-carrier-url"
                                       placeholder="https://tracking.post.ir/?id={code}"
                                       dir="ltr">
                            </td>
                            <td style="text-align:center;">
                                <input type="hidden" name="wcup_settings[carriers][<?php echo $i; ?>][enabled]" value="0">
                                <label class="wcup-switch">
                                    <input type="checkbox"
                                           name="wcup_settings[carriers][<?php echo $i; ?>][enabled]"
                                           value="1"
                                           <?php checked( $enabled, true ); ?>>
                                    <span class="wcup-switch-slider"></span>
                                </label>
                            </td>
                            <td>
                                <button type="button" class="button wcup-remove-carrier" title="حذف">🗑️</button>
                            </td>
                        </tr>
                    <?php $i++; endforeach; ?>
                </tbody>
            </table>

            <p class="description" style="margin-top:12px;">
                ⚠️ اگه شرکت حمل رو حذف کنی، سفارشات قدیمی که این شرکت رو دارن، همچنان کد رهگیری و نام شرکت رو نشون می‌دن.
            </p>
        </div>

        <?php submit_button( '💾 ذخیره شرکت‌های حمل', 'primary large' ); ?>
    </form>

</div>

<!-- ═══ Template for New Row ═══ -->
<script type="text/template" id="wcup-carrier-template">
    <tr class="wcup-carrier-row">
        <td>
            <input type="text" name="wcup_settings[carriers][__INDEX__][label]" value="" class="widefat wcup-carrier-label" placeholder="مثال: شرکت جدید">
        </td>
        <td>
            <input type="text" name="wcup_settings[carriers][__INDEX__][key]" value="" class="widefat wcup-carrier-key" placeholder="custom" pattern="[a-z0-9_\-]*">
            <small style="color:#7C8289;font-size:11px;">حروف کوچک انگلیسی</small>
        </td>
        <td>
            <input type="text" name="wcup_settings[carriers][__INDEX__][url]" value="" class="widefat wcup-carrier-url" placeholder="https://example.com/track/{code}" dir="ltr">
        </td>
        <td style="text-align:center;">
            <input type="hidden" name="wcup_settings[carriers][__INDEX__][enabled]" value="0">
            <label class="wcup-switch">
                <input type="checkbox" name="wcup_settings[carriers][__INDEX__][enabled]" value="1" checked>
                <span class="wcup-switch-slider"></span>
            </label>
        </td>
        <td>
            <button type="button" class="button wcup-remove-carrier" title="حذف">🗑️</button>
        </td>
    </tr>
</script>

<script>
jQuery(function($){

    var rowIndex = <?php echo (int) $i; ?>;

    /* ═══ افزودن شرکت جدید ═══ */
    $('#wcup-add-carrier').on('click', function(){
        var tpl  = $('#wcup-carrier-template').html();
        var html = tpl.replace(/__INDEX__/g, rowIndex);
        $('#wcup-carriers-body').append(html);
        rowIndex++;
    });

    /* ═══ حذف شرکت ═══ */
    $(document).on('click', '.wcup-remove-carrier', function(){
        if (!confirm('از حذف این شرکت مطمئنی؟')) return;
        $(this).closest('.wcup-carrier-row').fadeOut(200, function(){
            $(this).remove();
        });
    });

    /* ═══ تولید key خودکار ═══ */
    $(document).on('blur', '.wcup-carrier-label', function(){
        var $row = $(this).closest('.wcup-carrier-row');
        var $key = $row.find('.wcup-carrier-key');

        if ($key.val() !== '') return;

        var label = $(this).val();
        if (!label) return;

        /* تولید key یکتا */
        var key = 'c' + Date.now().toString(36).slice(-6);
        $key.val(key);
    });

    /* ═══ اعتبارسنجی قبل از submit ═══ */
    $('#wcup-carriers-form').on('submit', function(e){
        var hasEmpty = false;

        $('.wcup-carrier-row').each(function(){
            var label = $(this).find('.wcup-carrier-label').val().trim();
            var key   = $(this).find('.wcup-carrier-key').val().trim();

            if (label === '' && key === '') return;

            if (label === '' || key === '') {
                hasEmpty = true;
                $(this).css('background', '#fdecec');
            } else {
                $(this).css('background', '');
            }
        });

        if (hasEmpty) {
            e.preventDefault();
            alert('لطفاً نام شرکت و کلید رو کامل پر کن.');
        }
    });

    /* ═══ پاک‌سازی رنگ خطا ═══ */
    $(document).on('input', '.wcup-carrier-label, .wcup-carrier-key', function(){
        $(this).closest('.wcup-carrier-row').css('background', '');
    });

});
</script>