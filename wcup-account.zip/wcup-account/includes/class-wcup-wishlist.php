<?php
/**
 * WCUP Wishlist — علاقه‌مندی‌ها
 * ============================================================
 *  @package WCUP_Account
 *  @version 1.0.0
 * ============================================================
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_wishlist' ) ) {
    return;
}

class wcup_wishlist {

    const META_KEY   = '_wcup_wishlist';
    const NONCE_KEY  = 'wcup_wishlist_nonce';
    const PER_PAGE   = 20;

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {

        /* Endpoint */
        add_action( 'woocommerce_account_wishlist_endpoint', array( $this, 'render_endpoint' ) );

        /* دکمه روی کارت محصول (loop) */
        if ( wcup_settings::get( 'wishlist_button_loop', 1 ) ) {
            add_action( 'woocommerce_after_shop_loop_item', array( $this, 'render_loop_button' ), 15 );
        }

        /* دکمه روی صفحه محصول (single) */
        if ( wcup_settings::get( 'wishlist_button_single', 1 ) ) {
            add_action( 'woocommerce_single_product_summary', array( $this, 'render_single_button' ), 35 );
        }

        /* شورت‌کد دکمه */
        add_shortcode( 'wcup_wishlist_button', array( $this, 'shortcode_button' ) );

        /* AJAX */
        add_action( 'wp_ajax_wcup_toggle_wishlist', array( $this, 'ajax_toggle' ) );
        add_action( 'wp_ajax_nopriv_wcup_toggle_wishlist', array( $this, 'ajax_toggle' ) );

        /* پاک‌سازی هنگام حذف محصول */
        add_action( 'before_delete_post', array( $this, 'cleanup_on_product_delete' ) );

        /* پاک‌سازی هنگام حذف کاربر */
        add_action( 'delete_user', array( $this, 'cleanup_on_user_delete' ) );
    }

    /* ============================================================
     *  شرط فعال بودن
     * ============================================================ */
    public function is_enabled() {
        return (bool) wcup_settings::get( 'wishlist_enabled', 1 );
    }

    /* ============================================================
     *  گرفتن لیست علاقه‌مندی‌های کاربر
     * ============================================================ */
    public static function get_wishlist( $user_id = 0 ) {

        if ( ! $user_id ) {
            $user_id = get_current_user_id();
        }

        if ( ! $user_id ) {
            return array();
        }

        $list = get_user_meta( $user_id, self::META_KEY, true );

        if ( ! is_array( $list ) ) {
            return array();
        }

        /* فیلتر محصولات حذف‌شده */
        $list = array_filter( array_map( 'absint', $list ) );

        return array_values( array_unique( $list ) );
    }

    /* ============================================================
     *  آیا محصول در لیست هست؟
     * ============================================================ */
    public static function is_in_wishlist( $user_id, $product_id ) {

        if ( ! $user_id || ! $product_id ) {
            return false;
        }

        $list = self::get_wishlist( $user_id );

        return in_array( (int) $product_id, $list, true );
    }

    /* ============================================================
     *  افزودن
     * ============================================================ */
    public static function add( $user_id, $product_id ) {

        if ( ! $user_id || ! $product_id ) {
            return false;
        }

        /* اطمینان از معتبر بودن محصول */
        $product = wc_get_product( $product_id );
        if ( ! $product || $product->get_status() !== 'publish' ) {
            return false;
        }

        /* اگه variable هست، parent رو ذخیره کن */
        if ( $product->is_type( 'variation' ) && $product->get_parent_id() ) {
            $product_id = $product->get_parent_id();
        }

        $list = self::get_wishlist( $user_id );

        if ( in_array( (int) $product_id, $list, true ) ) {
            return true;
        }

        $list[] = (int) $product_id;

        update_user_meta( $user_id, self::META_KEY, $list );

        do_action( 'wcup_wishlist_added', $user_id, $product_id );

        return true;
    }

    /* ============================================================
     *  حذف
     * ============================================================ */
    public static function remove( $user_id, $product_id ) {

        if ( ! $user_id || ! $product_id ) {
            return false;
        }

        /* اگه variable هست، parent رو حذف کن */
        $product = wc_get_product( $product_id );
        if ( $product && $product->is_type( 'variation' ) && $product->get_parent_id() ) {
            $product_id = $product->get_parent_id();
        }

        $list = self::get_wishlist( $user_id );

        $index = array_search( (int) $product_id, $list, true );

        if ( $index === false ) {
            return true;
        }

        unset( $list[ $index ] );
        $list = array_values( $list );

        update_user_meta( $user_id, self::META_KEY, $list );

        do_action( 'wcup_wishlist_removed', $user_id, $product_id );

        return true;
    }

    /* ============================================================
     *  Toggle
     * ============================================================ */
    public static function toggle( $user_id, $product_id ) {

        if ( self::is_in_wishlist( $user_id, $product_id ) ) {
            self::remove( $user_id, $product_id );
            return false;
        }

        self::add( $user_id, $product_id );
        return true;
    }

    /* ============================================================
     *  شمارش
     * ============================================================ */
    public static function count( $user_id = 0 ) {
        return count( self::get_wishlist( $user_id ) );
    }

    /* ============================================================
     *  پاک کردن کامل
     * ============================================================ */
    public static function clear( $user_id ) {

        if ( ! $user_id ) {
            return false;
        }

        delete_user_meta( $user_id, self::META_KEY );

        return true;
    }

    /* ============================================================
     *  دکمه روی کارت محصول
     * ============================================================ */
    public function render_loop_button() {

        if ( ! $this->is_enabled() ) {
            return;
        }

        global $product;

        if ( ! $product instanceof WC_Product ) {
            return;
        }

        $user_id = get_current_user_id();
        $in_list = $user_id && self::is_in_wishlist( $user_id, $product->get_id() );

        $classes = 'wcup-wishlist-toggle wcup-wishlist-toggle--loop';
        if ( $in_list ) {
            $classes .= ' is-active';
        }

        ?>
        <button type="button"
                class="<?php echo esc_attr( $classes ); ?>"
                data-product-id="<?php echo esc_attr( $product->get_id() ); ?>"
                aria-label="<?php echo $in_list ? 'حذف از علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی‌ها'; ?>"
                title="<?php echo $in_list ? 'حذف از علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی‌ها'; ?>">
            <svg width="18" height="18" viewBox="0 0 24 24"
                 fill="<?php echo $in_list ? 'currentColor' : 'none'; ?>"
                 stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
            </svg>
        </button>
        <?php
    }

    /* ============================================================
     *  دکمه روی صفحه محصول
     * ============================================================ */
    public function render_single_button() {

        if ( ! $this->is_enabled() ) {
            return;
        }

        global $product;

        if ( ! $product instanceof WC_Product ) {
            return;
        }

        echo $this->get_button_html( $product->get_id(), array(
            'style'       => 'default',
            'text_add'    => 'افزودن به علاقه‌مندی‌ها',
            'text_remove' => 'در علاقه‌مندی‌ها',
        ) );
    }
    /* ============================================================
     *  شورت‌کد دکمه Wishlist
     *  استفاده: [wcup_wishlist_button]
     *  یا: [wcup_wishlist_button product_id="123" style="full"]
     * ============================================================ */
    public function shortcode_button( $atts ) {

        if ( ! $this->is_enabled() ) {
            return '';
        }

        $atts = shortcode_atts( array(
            'product_id'   => 0,
            'style'        => 'default',   /* default | icon | full */
            'text_add'     => '',
            'text_remove'  => '',
            'show_count'   => '0',
        ), $atts, 'wcup_wishlist_button' );

        $product_id = (int) $atts['product_id'];

        /* اگه product_id ندادی، از محصول فعلی بگیر */
        if ( ! $product_id ) {
            global $product;
            if ( $product instanceof WC_Product ) {
                $product_id = $product->get_id();
            }
        }

        if ( ! $product_id ) {
            return '';
        }

        return $this->get_button_html( $product_id, $atts );
    }

    /* ============================================================
     *  ساخت HTML دکمه (مشترک بین شورت‌کد و قالب)
     * ============================================================ */
    public function get_button_html( $product_id, $atts = array() ) {

        $product_id = (int) $product_id;
        if ( ! $product_id ) {
            return '';
        }

        $user_id  = get_current_user_id();
        $in_list  = $user_id && self::is_in_wishlist( $user_id, $product_id );

        $style    = ! empty( $atts['style'] ) ? $atts['style'] : 'default';
        $text_add    = ! empty( $atts['text_add'] )    ? $atts['text_add']    : 'افزودن به علاقه‌مندی‌ها';
        $text_remove = ! empty( $atts['text_remove'] ) ? $atts['text_remove'] : 'در علاقه‌مندی‌ها';

        $classes = 'wcup-wishlist-toggle wcup-wishlist-toggle--single';
        if ( $in_list ) {
            $classes .= ' is-active';
        }

        if ( 'icon' === $style ) {
            $classes .= ' wcup-wishlist-toggle--icon';
        } elseif ( 'full' === $style ) {
            $classes .= ' wcup-wishlist-toggle--full';
        }

        ob_start();
        ?>
        <button type="button"
                class="<?php echo esc_attr( $classes ); ?>"
                data-product-id="<?php echo esc_attr( $product_id ); ?>"
                aria-label="<?php echo esc_attr( $in_list ? $text_remove : $text_add ); ?>"
                title="<?php echo esc_attr( $in_list ? $text_remove : $text_add ); ?>">
            <svg width="18" height="18" viewBox="0 0 24 24"
                 fill="<?php echo $in_list ? 'currentColor' : 'none'; ?>"
                 stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
            </svg>

            <?php if ( 'icon' !== $style ) : ?>
                <span class="wcup-wishlist-toggle-text">
                    <?php echo esc_html( $in_list ? $text_remove : $text_add ); ?>
                </span>
            <?php endif; ?>

            <?php if ( ! empty( $atts['show_count'] ) && $user_id ) :
                $count = self::count( $user_id );
                if ( $count > 0 ) : ?>
                    <span class="wcup-wishlist-toggle-count"><?php echo esc_html( wcup_helpers::fa_num( $count ) ); ?></span>
                <?php endif;
            endif; ?>
        </button>
        <?php
        return ob_get_clean();
    }

    /* ============================================================
     *  نسخهٔ قالبی دکمه (برای فراخوانی دستی در PHP)
     * ============================================================ */
    public function render_button( $product_id = 0, $atts = array() ) {
        echo $this->get_button_html( $product_id, $atts );
    }
	
    /* ============================================================
     *  رندر endpoint
     * ============================================================ */
    public function render_endpoint() {

        if ( ! $this->is_enabled() ) {
            echo '<div class="wcup-vo-error" style="padding:30px;background:#fdecec;border-radius:16px;color:#c0392b;text-align:center;">';
            echo 'سیستم علاقه‌مندی‌ها غیرفعال است.';
            echo '</div>';
            return;
        }

        $template = locate_template( 'woocommerce/myaccount/wishlist.php' );

        if ( $template ) {
            include $template;
            return;
        }

        echo '<div class="wcup-vo-error" style="padding:30px;background:#fdecec;border-radius:16px;color:#c0392b;text-align:center;">';
        echo 'قالب wishlist.php پیدا نشد.';
        echo '</div>';
    }

    /* ============================================================
     *  AJAX: Toggle
     * ============================================================ */
    public function ajax_toggle() {

        check_ajax_referer( self::NONCE_KEY, 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array(
                'message'   => 'برای افزودن به علاقه‌مندی‌ها باید وارد حساب شوید.',
                'login_url' => wc_get_page_permalink( 'myaccount' ),
                'code'      => 'not_logged_in',
            ) );
        }

        if ( ! $this->is_enabled() ) {
            wp_send_json_error( array( 'message' => 'سیستم علاقه‌مندی‌ها غیرفعال است.' ) );
        }

        $user_id    = get_current_user_id();
        $product_id = isset( $_POST['product_id'] ) ? (int) $_POST['product_id'] : 0;

        if ( ! $user_id || ! $product_id ) {
            wp_send_json_error( array( 'message' => 'اطلاعات نامعتبر.' ) );
        }

        $product = wc_get_product( $product_id );

        if ( ! $product ) {
            wp_send_json_error( array( 'message' => 'محصول یافت نشد.' ) );
        }

        $now_in_list = self::toggle( $user_id, $product_id );
        $new_count   = self::count( $user_id );

        wp_send_json_success( array(
            'in_wishlist' => $now_in_list,
            'count'       => $new_count,
            'count_fa'    => wcup_helpers::fa_num( $new_count ),
            'message'     => $now_in_list
                ? 'به علاقه‌مندی‌ها اضافه شد.'
                : 'از علاقه‌مندی‌ها حذف شد.',
        ) );
    }

    /* ============================================================
     *  پاک‌سازی هنگام حذف محصول
     * ============================================================ */
    public function cleanup_on_product_delete( $post_id ) {

        if ( get_post_type( $post_id ) !== 'product' ) {
            return;
        }

        global $wpdb;

        /* به‌روزرسانی همهٔ کاربرانی که این محصول رو دارن */
        $users = $wpdb->get_col( $wpdb->prepare(
            "SELECT user_id FROM {$wpdb->usermeta}
             WHERE meta_key = %s
             AND meta_value LIKE %s",
            self::META_KEY,
            '%' . $wpdb->esc_like( (string) $post_id ) . '%'
        ) );

        foreach ( $users as $user_id ) {
            self::remove( $user_id, $post_id );
        }
    }

    /* ============================================================
     *  آمار سیستم‌های خارجی (برای مهاجرت)
     * ============================================================ */
    public static function get_plugin_stats() {

        $stats = array(
            'yith'     => array( 'detected' => false, 'count' => 0, 'label' => 'YITH WooCommerce Wishlist' ),
            'ti'       => array( 'detected' => false, 'count' => 0, 'label' => 'TI WooCommerce Wishlist' ),
            'generic'  => array( 'detected' => false, 'count' => 0, 'label' => 'WooCommerce Wishlist (Meta)' ),
            'total_users' => 0,
        );

        /* ── YITH ── */
        if ( class_exists( 'YITH_WCWL' ) || function_exists( 'yith_wcwl_count_products' ) ) {
            $stats['yith']['detected'] = true;
            $stats['yith']['count']    = self::count_yith_entries();
        }

        /* ── TI Wishlist ── */
        if ( defined( 'TINVWL_VERSION' ) || class_exists( 'TInvWL' ) ) {
            $stats['ti']['detected'] = true;
            $stats['ti']['count']    = self::count_ti_entries();
        }

        /* ── Meta عمومی ── */
        global $wpdb;
        $generic = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->usermeta}
             WHERE meta_key IN ('wishlist', 'wishlist_count', '_wishlist_count', '_yith_wcwl_products')
             AND meta_value != ''"
        );
        if ( $generic > 0 ) {
            $stats['generic']['detected'] = true;
            $stats['generic']['count']    = $generic;
        }

        /* ── آمار کاربران ── */
        if ( class_exists( 'wcup_wishlist' ) ) {
            $stats['total_users'] = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->usermeta}
                 WHERE meta_key = '_wcup_wishlist'
                 AND meta_value != '' AND meta_value != 'a:0:{}'"
            );
        }

        return $stats;
    }

    /* ============================================================
     *  شمارش رکوردهای YITH
     * ============================================================ */
    private static function count_yith_entries() {

        global $wpdb;

        /* نسخهٔ جدید: جدول جدا */
        $table = $wpdb->prefix . 'yith_wcwl';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) === $table ) {
            return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        }

        /* نسخهٔ قدیم: user_meta */
        $meta_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->usermeta}
             WHERE meta_key = '_yith_wcwl_products'
             AND meta_value != ''"
        );

        return $meta_count;
    }

    /* ============================================================
     *  شمارش رکوردهای TI
     * ============================================================ */
    private static function count_ti_entries() {

        global $wpdb;

        $table = $wpdb->prefix . 'tinvwl_items';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) === $table ) {
            return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        }

        $meta_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->usermeta}
             WHERE meta_key = 'wishlist'
             AND meta_value != ''"
        );

        return $meta_count;
    }

    /* ============================================================
     *  مهاجرت از YITH
     * ============================================================ */
    public static function migrate_from_yith() {

        global $wpdb;

        $migrated = 0;
        $errors   = 0;

        /* ── نسخهٔ جدید: جدول ── */
        $table = $wpdb->prefix . 'yith_wcwl';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) === $table ) {

            $rows = $wpdb->get_results(
                "SELECT user_id, prod_id FROM {$table}",
                ARRAY_A
            );

            if ( ! empty( $rows ) ) {
                foreach ( $rows as $row ) {
                    $user_id    = (int) $row['user_id'];
                    $product_id = (int) $row['prod_id'];

                    if ( ! $user_id || ! $product_id ) {
                        $errors++;
                        continue;
                    }

                    if ( self::add( $user_id, $product_id ) ) {
                        $migrated++;
                    } else {
                        $errors++;
                    }
                }
            }

            return array(
                'success'  => true,
                'migrated' => $migrated,
                'errors'   => $errors,
                'source'   => 'YITH (table)',
            );
        }

        /* ── نسخهٔ قدیم: user_meta ── */
        $users = $wpdb->get_results(
            "SELECT user_id, meta_value FROM {$wpdb->usermeta}
             WHERE meta_key = '_yith_wcwl_products'
             AND meta_value != ''"
        );

        if ( ! empty( $users ) ) {
            foreach ( $users as $row ) {
                $user_id    = (int) $row->user_id;
                $products   = maybe_unserialize( $row->meta_value );

                if ( ! is_array( $products ) ) {
                    $errors++;
                    continue;
                }

                foreach ( $products as $product_id ) {
                    $product_id = (int) $product_id;
                    if ( ! $product_id ) continue;

                    if ( self::add( $user_id, $product_id ) ) {
                        $migrated++;
                    } else {
                        $errors++;
                    }
                }
            }

            return array(
                'success'  => true,
                'migrated' => $migrated,
                'errors'   => $errors,
                'source'   => 'YITH (meta)',
            );
        }

        return array(
            'success' => false,
            'message' => 'داده‌ای از YITH پیدا نشد.',
        );
    }

    /* ============================================================
     *  مهاجرت از TI Wishlist
     * ============================================================ */
    public static function migrate_from_ti() {

        global $wpdb;

        $migrated = 0;
        $errors   = 0;

        /* ── جدول ── */
        $table = $wpdb->prefix . 'tinvwl_items';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) === $table ) {

            $rows = $wpdb->get_results(
                "SELECT author AS user_id, product_id FROM {$table}",
                ARRAY_A
            );

            if ( ! empty( $rows ) ) {
                foreach ( $rows as $row ) {
                    $user_id    = (int) $row['user_id'];
                    $product_id = (int) $row['product_id'];

                    if ( ! $user_id || ! $product_id ) {
                        $errors++;
                        continue;
                    }

                    if ( self::add( $user_id, $product_id ) ) {
                        $migrated++;
                    } else {
                        $errors++;
                    }
                }
            }

            return array(
                'success'  => true,
                'migrated' => $migrated,
                'errors'   => $errors,
                'source'   => 'TI (table)',
            );
        }

        /* ── user_meta ── */
        $users = $wpdb->get_results(
            "SELECT user_id, meta_value FROM {$wpdb->usermeta}
             WHERE meta_key IN ('wishlist', '_ti_wishlist')
             AND meta_value != ''"
        );

        if ( ! empty( $users ) ) {
            foreach ( $users as $row ) {
                $user_id  = (int) $row->user_id;
                $products = maybe_unserialize( $row->meta_value );

                if ( ! is_array( $products ) ) {
                    $errors++;
                    continue;
                }

                foreach ( $products as $product_id ) {
                    $product_id = (int) $product_id;
                    if ( ! $product_id ) continue;

                    if ( self::add( $user_id, $product_id ) ) {
                        $migrated++;
                    } else {
                        $errors++;
                    }
                }
            }

            return array(
                'success'  => true,
                'migrated' => $migrated,
                'errors'   => $errors,
                'source'   => 'TI (meta)',
            );
        }

        return array(
            'success' => false,
            'message' => 'داده‌ای از TI پیدا نشد.',
        );
    }

    /* ============================================================
     *  مهاجرت از Meta عمومی
     * ============================================================ */
    public static function migrate_from_meta() {

        global $wpdb;

        $migrated = 0;
        $errors   = 0;

        $users = $wpdb->get_results(
            "SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta}
             WHERE meta_key IN ('wishlist', '_wishlist', 'wishlist_items')
             AND meta_value != ''"
        );

        if ( empty( $users ) ) {
            return array(
                'success' => false,
                'message' => 'داده‌ای از Meta پیدا نشد.',
            );
        }

        foreach ( $users as $row ) {
            $user_id  = (int) $row->user_id;
            $products = maybe_unserialize( $row->meta_value );

            if ( ! is_array( $products ) ) {
                $errors++;
                continue;
            }

            foreach ( $products as $product_id ) {
                $product_id = (int) $product_id;
                if ( ! $product_id ) continue;

                if ( self::add( $user_id, $product_id ) ) {
                    $migrated++;
                } else {
                    $errors++;
                }
            }
        }

        return array(
            'success'  => true,
            'migrated' => $migrated,
            'errors'   => $errors,
            'source'   => 'Meta',
        );
    }
	
    /* ============================================================
     *  پاک‌سازی هنگام حذف کاربر
     * ============================================================ */
    public function cleanup_on_user_delete( $user_id ) {
        self::clear( $user_id );
    }
}