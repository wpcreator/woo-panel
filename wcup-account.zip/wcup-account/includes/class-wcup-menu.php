<?php
defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_menu' ) ) {
    return;
}

class wcup_menu {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {

        /* منو */
        add_filter( 'woocommerce_account_menu_items', array( $this, 'add_custom_items' ), 5 );
        add_filter( 'woocommerce_account_menu_items', array( $this, 'sort_and_translate' ), 20 );
        add_filter( 'woocommerce_account_menu_items', array( $this, 'remove_disabled_items' ), 30 );

        /* Endpointها */
        add_action( 'init',                       array( $this, 'register_endpoints' ) );
        add_filter( 'woocommerce_get_query_vars', array( $this, 'register_query_vars' ) );

        /* ریدایرکت */
        add_filter( 'woocommerce_login_redirect', array( $this, 'login_redirect' ), 20, 2 );

        /* کشور */
        add_filter( 'woocommerce_countries', array( $this, 'limit_countries_to_iran' ) );
    }

    /* ============================================================
     *  ثبت همهٔ endpointها
     * ============================================================ */
    public function register_endpoints() {
        add_rewrite_endpoint( 'reviews',       EP_ROOT | EP_PAGES );
        add_rewrite_endpoint( 'invoices',      EP_ROOT | EP_PAGES );
        add_rewrite_endpoint( 'track-order',   EP_ROOT | EP_PAGES );
        add_rewrite_endpoint( 'notifications', EP_ROOT | EP_PAGES );
        add_rewrite_endpoint( 'wishlist',      EP_ROOT | EP_PAGES );
        add_rewrite_endpoint( 'addresses',     EP_ROOT | EP_PAGES );
    }

    public function register_query_vars( $vars ) {
        $vars['reviews']       = 'reviews';
        $vars['invoices']      = 'invoices';
        $vars['track-order']   = 'track-order';
        $vars['notifications'] = 'notifications';
        $vars['wishlist']      = 'wishlist';
        $vars['addresses']     = 'addresses';
        return $vars;
    }

    /* ============================================================
     *  اضافه کردن آیتم‌های سفارشی
     * ============================================================ */
    public function add_custom_items( $items ) {

        $new_items = array();

        foreach ( $items as $key => $label ) {

            $new_items[ $key ] = $label;

            /* بعد از orders → invoices */
            if ( 'orders' === $key && ! isset( $items['invoices'] ) ) {
                if ( (int) wcup_settings::get( 'menu_invoices', 1 ) ) {
                    $new_items['invoices'] = wcup_settings::get( 'label_invoices', 'فاکتورها' );
                }
            }

            /* بعد از downloads → reviews */
            if ( 'downloads' === $key && ! isset( $items['reviews'] ) ) {
                if ( (int) wcup_settings::get( 'menu_reviews', 1 ) ) {
                    $new_items['reviews'] = wcup_settings::get( 'label_reviews', 'نظرات شما' );
                }
            }

            /* بعد از reviews → track-order */
            if ( 'reviews' === $key && ! isset( $items['track-order'] ) ) {
                if ( (int) wcup_settings::get( 'menu_track_order', 1 ) ) {
                    $new_items['track-order'] = wcup_settings::get( 'label_track_order', 'پیگیری سفارش' );
                }
            }

            /* بعد از track-order → notifications */
            if ( 'track-order' === $key && ! isset( $items['notifications'] ) ) {
                if ( (int) wcup_settings::get( 'menu_notifications', 1 ) ) {
                    $new_items['notifications'] = wcup_settings::get( 'label_notifications', 'اعلان‌ها' );
                }
            }

            /* بعد از notifications → wishlist */
            if ( 'notifications' === $key && ! isset( $items['wishlist'] ) ) {
                if ( (int) wcup_settings::get( 'menu_wishlist', 1 ) ) {
                    $new_items['wishlist'] = wcup_settings::get( 'label_wishlist', 'علاقه‌مندی‌ها' );
                }
            }

            /* بعد از wishlist → addresses */
            if ( 'wishlist' === $key && ! isset( $items['addresses'] ) ) {
                if ( (int) wcup_settings::get( 'menu_addresses', 1 ) ) {
                    $new_items['addresses'] = wcup_settings::get( 'label_addresses', 'آدرس‌های من' );
                }
            }
        }

        /* ═══ fallbackها ═══ */

        /* invoices */
        if ( ! isset( $new_items['invoices'] ) && (int) wcup_settings::get( 'menu_invoices', 1 ) ) {
            $new_items['invoices'] = wcup_settings::get( 'label_invoices', 'فاکتورها' );
        }

        /* reviews */
        if ( ! isset( $new_items['reviews'] ) && (int) wcup_settings::get( 'menu_reviews', 1 ) ) {
            $new_items['reviews'] = wcup_settings::get( 'label_reviews', 'نظرات شما' );
        }

        /* track-order */
        if ( ! isset( $new_items['track-order'] ) && (int) wcup_settings::get( 'menu_track_order', 1 ) ) {
            $new_items['track-order'] = wcup_settings::get( 'label_track_order', 'پیگیری سفارش' );
        }

        /* notifications */
        if ( ! isset( $new_items['notifications'] ) && (int) wcup_settings::get( 'menu_notifications', 1 ) ) {
            $new_items['notifications'] = wcup_settings::get( 'label_notifications', 'اعلان‌ها' );
        }

        /* wishlist */
        if ( ! isset( $new_items['wishlist'] ) && (int) wcup_settings::get( 'menu_wishlist', 1 ) ) {
            $new_items['wishlist'] = wcup_settings::get( 'label_wishlist', 'علاقه‌مندی‌ها' );
        }

        /* addresses */
        if ( ! isset( $new_items['addresses'] ) && (int) wcup_settings::get( 'menu_addresses', 1 ) ) {
            $new_items['addresses'] = wcup_settings::get( 'label_addresses', 'آدرس‌های من' );
        }

        return $new_items;
    }

    /* ============================================================
     *  مرتب‌سازی + ترجمه
     * ============================================================ */
    public function sort_and_translate( $items ) {

        $order = array(
            'dashboard',
            'orders',
            'invoices',
            'downloads',
            'reviews',
            'track-order',
            'notifications',
            'wishlist',
            'addresses',
            'licenses',
            'my-licenses',
            'edit-account',
            'edit-address',
            'customer-logout',
        );

        $sorted = array();
        foreach ( $order as $key ) {
            if ( isset( $items[ $key ] ) ) {
                $sorted[ $key ] = $items[ $key ];
            }
        }
        foreach ( $items as $key => $label ) {
            if ( ! isset( $sorted[ $key ] ) ) {
                $sorted[ $key ] = $label;
            }
        }

        $label_map = array(
            'dashboard'       => wcup_settings::get( 'label_dashboard',     'پیشخوان' ),
            'orders'          => wcup_settings::get( 'label_orders',        'سفارش‌ها' ),
            'invoices'        => wcup_settings::get( 'label_invoices',      'فاکتورها' ),
            'downloads'       => wcup_settings::get( 'label_downloads',     'دانلودها' ),
            'reviews'         => wcup_settings::get( 'label_reviews',       'نظرات شما' ),
            'track-order'     => wcup_settings::get( 'label_track_order',   'پیگیری سفارش' ),
            'notifications'   => wcup_settings::get( 'label_notifications', 'اعلان‌ها' ),
            'wishlist'        => wcup_settings::get( 'label_wishlist',      'علاقه‌مندی‌ها' ),
            'addresses'       => wcup_settings::get( 'label_addresses',     'آدرس‌های من' ),
            'licenses'        => wcup_settings::get( 'label_licenses',      'لایسنس‌های من' ),
            'my-licenses'     => wcup_settings::get( 'label_licenses',      'لایسنس‌های من' ),
            'edit-account'    => wcup_settings::get( 'label_edit_account',  'جزئیات حساب' ),
            'edit-address'    => wcup_settings::get( 'label_edit_address',  'آدرس‌ها' ),
            'customer-logout' => wcup_settings::get( 'label_logout',        'بیرون رفتن' ),
        );

        foreach ( $label_map as $key => $label ) {
            if ( isset( $sorted[ $key ] ) && $label ) {
                $sorted[ $key ] = $label;
            }
        }

        return $sorted;
    }

    /* ============================================================
     *  حذف آیتم‌های غیرفعال
     * ============================================================ */
    public function remove_disabled_items( $items ) {

        $map = array(
            'dashboard'       => 'menu_dashboard',
            'orders'          => 'menu_orders',
            'invoices'        => 'menu_invoices',      /* ⭐ اضافه شد */
            'downloads'       => 'menu_downloads',
            'reviews'         => 'menu_reviews',
            'track-order'     => 'menu_track_order',
            'notifications'   => 'menu_notifications',
            'wishlist'        => 'menu_wishlist',
            'addresses'       => 'menu_addresses',
            'licenses'        => 'menu_licenses',
            'my-licenses'     => 'menu_licenses',
            'edit-account'    => 'menu_edit_account',
            'edit-address'    => 'menu_edit_address',
            'payment-methods' => 'menu_payment_methods',
            'customer-logout' => 'menu_logout',
        );

        foreach ( $map as $item_key => $setting_key ) {
            $enabled = (int) wcup_settings::get( $setting_key, 1 );
            if ( ! $enabled && isset( $items[ $item_key ] ) ) {
                unset( $items[ $item_key ] );
            }
        }

        return $items;
    }

    /* ============================================================
     *  ریدایرکت
     * ============================================================ */
    public function login_redirect( $redirect, $user ) {
        if ( ! empty( $_REQUEST['redirect_to'] ) ) return $redirect;
        if ( user_can( $user, 'manage_options' ) ) return admin_url();
        return wc_get_page_permalink( 'myaccount' );
    }

    /* ============================================================
     *  کشور
     * ============================================================ */
    public function limit_countries_to_iran( $countries ) {
        if ( isset( $countries['IR'] ) ) {
            return array( 'IR' => $countries['IR'] );
        }
        return $countries;
    }
}