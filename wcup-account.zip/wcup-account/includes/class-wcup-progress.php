<?php
/**
 * WCUP Progress — نوار پیشرفت تکمیل پروفایل
 * ============================================================
 *  بخش ۱۸ از فایل قدیمی (نمایش + رندر)
 *  محاسبات در wcup_helpers::get_profile_completion()
 *
 *  @package WCUP_Account
 *  @version 1.0.0
 * ============================================================
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_progress' ) ) {
    return;
}

class wcup_progress {

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {

        /* نمایش نوار پیشرفت در بالای داشبورد */
        add_action( 'woocommerce_account_dashboard', array( $this, 'render_on_dashboard' ), 5 );

        /* Shortcode برای استفاده در قالب‌های دلخواه */
        add_shortcode( 'wcup_progress', array( $this, 'shortcode' ) );
    }

    /* ============================================================
     *  شرط نمایش
     * ============================================================ */
    private function is_enabled() {
        return (bool) wcup_settings::get( 'progress_enabled', 1 );
    }

    /* ============================================================
     *  رندر روی داشبورد
     * ============================================================ */
    public function render_on_dashboard() {

        if ( ! $this->is_enabled() ) {
            return;
        }

        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            return;
        }

        $this->render( $user_id );
    }

    /* ============================================================
     *  Shortcode [wcup_progress]
     * ============================================================ */
    public function shortcode( $atts ) {

        if ( ! $this->is_enabled() ) {
            return '';
        }

        $atts = shortcode_atts( array(
            'user_id' => get_current_user_id(),
        ), $atts, 'wcup_progress' );

        $user_id = (int) $atts['user_id'];
        if ( ! $user_id ) {
            return '';
        }

        ob_start();
        $this->render( $user_id );
        return ob_get_clean();
    }

    /* ============================================================
     *  رندر اصلی
     * ============================================================ */
    public function render( $user_id ) {

        $data = wcup_helpers::get_profile_completion( $user_id );
        $percent = (int) $data['percent'];

        /* فیلتر: کدام مراحل نمایش داده بشن */
        $data['steps'] = $this->filter_steps( $data['steps'] );

        /* اگه ۱۰۰٪ کامله، نشون نده (اختیاری) */
        if ( $percent >= 100 && ! apply_filters( 'wcup_progress_show_when_complete', false ) ) {
            return;
        }

        $percent_fa = wcup_helpers::fa_num( $percent );
        ?>
        <div class="wcup-profile-progress" data-percent="<?php echo esc_attr( $percent ); ?>">

            <div class="wcup-progress-header">
                <span class="wcup-progress-title">📊 تکمیل پروفایل</span>
                <span class="wcup-progress-percent"><?php echo esc_html( $percent_fa ); ?>٪</span>
            </div>

            <div class="wcup-progress-bar">
                <div class="wcup-progress-bar-fill" style="width: <?php echo esc_attr( $percent ); ?>%;"></div>
            </div>

            <div class="wcup-progress-steps">
                <?php foreach ( $data['steps'] as $key => $step ) : ?>
                    <a href="<?php echo esc_url( $step['url'] ); ?>"
                       class="wcup-progress-step <?php echo $step['done'] ? 'is-done' : 'is-pending'; ?>">

                        <span class="wcup-progress-step-icon">
                            <?php if ( $step['done'] ) : ?>
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                     stroke="currentColor" stroke-width="3"
                                     stroke-linecap="round" stroke-linejoin="round">
                                    <polyline points="20 6 9 17 4 12"></polyline>
                                </svg>
                            <?php else : ?>
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                     stroke="currentColor" stroke-width="3"
                                     stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="12" y1="5" x2="12" y2="19"></line>
                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                </svg>
                            <?php endif; ?>
                        </span>

                        <span class="wcup-progress-step-label"><?php echo esc_html( $step['label'] ); ?></span>
                    </a>
                <?php endforeach; ?>
            </div>

        </div>
        <?php
    }

    /* ============================================================
     *  فیلتر مراحل بر اساس تنظیمات
     * ============================================================ */
    private function filter_steps( $steps ) {

        $map = array(
            'first_name'       => 'progress_first_name',
            'last_name'        => 'progress_last_name',
            'email'            => 'progress_email',
            'avatar'           => 'progress_avatar',
            'billing_phone'    => 'progress_phone',
            'billing_address'  => 'progress_address',
            'billing_city'     => 'progress_city',
            'billing_postcode' => 'progress_postcode',
        );

        foreach ( $map as $step_key => $setting_key ) {

            $enabled = (int) wcup_settings::get( $setting_key, 1 );

            if ( ! $enabled && isset( $steps[ $step_key ] ) ) {
                unset( $steps[ $step_key ] );
            }
        }

        return $steps;
    }
}