<?php
defined( 'ABSPATH' ) || exit;

if ( class_exists( 'wcup_settings' ) ) {
    return;
}

class wcup_settings {

    const OPTION_KEY = 'wcup_settings';
    const GROUP      = 'wcup_settings_group';

    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_init', array( $this, 'register' ) );
        add_action( 'init', array( $this, 'maybe_repair' ), 1 );
    }

    public function register() {
        register_setting( self::GROUP, self::OPTION_KEY, array(
            'type'              => 'array',
            'sanitize_callback' => array( $this, 'sanitize' ),
            'default'           => self::get_defaults(),
        ) );
    }

    /* ============================================================
     *  مقادیر پیش‌فرض
     * ============================================================ */
    public static function get_defaults() {
        return array(

            /* ─── تنظیمات عمومی ─── */
            'enabled'                    => 1,
            'load_css'                   => 1,
            'popup_notices'              => 1,
            'persian_numbers'            => 1,
            'avatar_upload'              => 1,
            'remove_wc_styles'           => 0,
            'default_avatar_id'          => 0,

            /* ─── منوی حساب ─── */
            'menu_dashboard'             => 1,
            'menu_orders'                => 1,
            'menu_invoices'              => 1,   /* 🆕 */
            'menu_downloads'             => 1,
            'menu_reviews'               => 1,
            'menu_track_order'           => 1,
            'menu_notifications'         => 1,
            'menu_wishlist'              => 1,
            'menu_addresses'             => 1,
            'menu_licenses'              => 1,
            'menu_edit_account'          => 1,
            'menu_edit_address'          => 1,
            'menu_payment_methods'       => 0,
            'menu_logout'                => 1,

            /* ─── برچسب‌های سفارشی ─── */
            'label_dashboard'            => 'پیشخوان',
            'label_orders'               => 'سفارش‌ها',
            'label_invoices'             => 'فاکتورها',        /* 🆕 */
            'label_downloads'            => 'دانلودها',
            'label_reviews'              => 'نظرات شما',
            'label_track_order'          => 'پیگیری سفارش',
            'label_notifications'        => 'اعلان‌ها',
            'label_wishlist'             => 'علاقه‌مندی‌ها',
            'label_addresses'            => 'آدرس‌های من',
            'label_licenses'             => 'لایسنس‌های من',
            'label_edit_account'         => 'جزئیات حساب',
            'label_edit_address'         => 'آدرس‌ها',
            'label_logout'               => 'بیرون رفتن',

            /* ─── Progress Bar ─── */
            'progress_enabled'           => 1,
            'progress_first_name'        => 1,
            'progress_last_name'         => 1,
            'progress_email'             => 1,
            'progress_avatar'            => 1,
            'progress_phone'             => 1,
            'progress_address'           => 1,
            'progress_city'              => 1,
            'progress_postcode'          => 1,

            /* ─── Tracking ─── */
            'tracking_enabled'           => 1,

            /* ─── شرکت‌های حمل ─── */
            'carriers'                   => array(
                array( 'key' => 'post',   'label' => 'پست جمهوری اسلامی', 'url' => 'https://tracking.post.ir/?id={code}',     'enabled' => 1 ),
                array( 'key' => 'tipax',  'label' => 'تیپاکس',             'url' => 'https://tipaxco.com/tracking?code={code}', 'enabled' => 1 ),
                array( 'key' => 'chapar', 'label' => 'چاپار',              'url' => 'https://chapar.ir/tracking/{code}',        'enabled' => 1 ),
                array( 'key' => 'mahex',  'label' => 'ماهکس',              'url' => 'https://mahex.com/tracking/',              'enabled' => 1 ),
                array( 'key' => 'peyk',   'label' => 'پیک',                'url' => '',                                          'enabled' => 1 ),
                array( 'key' => 'other',  'label' => 'سایر',               'url' => '',                                          'enabled' => 1 ),
            ),

            /* ─── اطلاعیه‌ها ─── */
            'notices_enabled'            => 1,

            /* ─── اعلان‌ها (Notifications) ─── */
            'notifications_enabled'      => 1,
            'notify_on_order_status'     => 1,
            'notify_on_tracking'         => 1,
            'notify_on_comment_approved' => 1,
            'notify_on_wishlist'         => 0,   /* 🆕 اختیاری */
            'notify_on_invoice'          => 1,   /* 🆕 */
            'notifications_retention'    => 90,

            /* ─── علاقه‌مندی‌ها (Wishlist) ─── */
            'wishlist_enabled'           => 1,
            'wishlist_button_loop'       => 1,
            'wishlist_button_single'     => 1,

            /* ─── آدرس‌های متعدد ─── */
            'addresses_enabled'          => 1,
            'addresses_max'              => 10,

            /* ═══════════════════════════════════════════
             *  🧾 فاکتور
             * ═══════════════════════════════════════════ */
            'invoice_enabled'            => 1,
            'invoice_email_on_complete'  => 1,
            'invoice_prefix'             => 'INV',
            'invoice_logo_id'            => 0,
            'invoice_show_qr'            => 1,
            'invoice_show_tracking'      => 1,
            'invoice_show_terms'         => 1,
            'invoice_footer_note'        => 'این فاکتور به‌صورت خودکار توسط سیستم تولید شده است.',
            'invoice_thanks_text'        => 'از خرید شما سپاسگزاریم',
            'invoice_terms_text'         => 'کالاهای فروخته‌شده تا ۷ روز پس از دریافت، در صورت داشتن مشکل، قابل مرجوع هستند.',
            'invoice_fonts_base'         => '',

            /* ═══════════════════════════════════════════
             *  🎛️ کارت‌های داشبورد
             * ═══════════════════════════════════════════ */
            'dash_hero'                  => 1,
            'dash_progress'              => 1,
            'dash_quick_links'           => 1,
            'dash_recent_orders'         => 1,
            'dash_notices'               => 1,
            'dash_show_section_titles'   => 1,

            'stat_total_spent'           => 1,
            'stat_total_orders'          => 1,
            'stat_avg_order'             => 1,
            'stat_member_days'           => 1,
            'stat_completed'             => 1,
            'stat_processing'            => 1,
            'stat_wishlist'              => 1,
            'stat_comments'              => 1,
            'stat_downloads'             => 1,
            'stat_last_order'            => 1,
        );
    }

    /* ============================================================
     *  خواندن تنظیمات
     * ============================================================ */
    public static function get( $key = null, $default = null ) {

        $settings = get_option( self::OPTION_KEY, array() );
        $defaults = self::get_defaults();
        $settings = wp_parse_args( $settings, $defaults );

        if ( null === $key ) {
            return $settings;
        }

        return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
    }

    /* ============================================================
     *  به‌روزرسانی
     * ============================================================ */
    public static function update( $data ) {
        $data = self::instance()->sanitize( (array) $data );
        return update_option( self::OPTION_KEY, $data );
    }

    /* ============================================================
     *  Sanitize — با پشتیبانی از carriers
     * ============================================================ */
    public function sanitize( $input ) {

        $defaults = self::get_defaults();
        $existing = get_option( self::OPTION_KEY, array() );

        if ( ! is_array( $existing ) ) {
            $existing = array();
        }

        $existing = wp_parse_args( $existing, $defaults );
        $output   = array();

        foreach ( $defaults as $key => $default ) {

            /* ── شرکت‌های حمل: آرایهٔ تو در تو ── */
            if ( 'carriers' === $key ) {
                $raw = $input[ $key ] ?? $existing[ $key ] ?? $default;
                $output[ $key ] = $this->sanitize_carriers( $raw );
                continue;
            }

            /* ── فیلد توی فرم بود؟ ── */
            if ( isset( $input[ $key ] ) ) {

                $val = $input[ $key ];

                if ( is_numeric( $default ) ) {
                    $output[ $key ] = (int) $val;
                    continue;
                }

                $val = sanitize_text_field( $val );
                if ( $val === '' && $default !== '' ) {
                    $output[ $key ] = $default;
                } else {
                    $output[ $key ] = $val;
                }
                continue;
            }

            /* ── فیلد توی فرم نبود → مقدار قبلی ── */
            $output[ $key ] = isset( $existing[ $key ] ) ? $existing[ $key ] : $default;
        }

        return $output;
    }

    /* ============================================================
     *  Sanitize — شرکت‌های حمل
     * ============================================================ */
    private function sanitize_carriers( $input ) {

        if ( ! is_array( $input ) ) {
            $defaults = self::get_defaults();
            return $defaults['carriers'];
        }

        $output = array();

        foreach ( $input as $carrier ) {

            if ( ! is_array( $carrier ) ) {
                continue;
            }

            $key   = isset( $carrier['key'] )   ? sanitize_key( $carrier['key'] )            : '';
            $label = isset( $carrier['label'] ) ? sanitize_text_field( $carrier['label'] )   : '';
            $url   = isset( $carrier['url'] )   ? esc_url_raw( $carrier['url'] )             : '';

            /* ردیف خالی → رد کن */
            if ( $label === '' && $key === '' && $url === '' ) {
                continue;
            }

            /* key خالی → خودکار بساز */
            if ( $key === '' ) {
                $key = 'c' . substr( md5( $label . microtime( true ) . wp_rand( 1, 9999 ) ), 0, 8 );
            }

            /* key تکراری → suffix */
            $original_key = $key;
            $suffix = 2;
            while ( isset( $output[ $key ] ) ) {
                $key = $original_key . '_' . $suffix;
                $suffix++;
            }

            $output[ $key ] = array(
                'key'     => $key,
                'label'   => $label,
                'url'     => $url,
                'enabled' => ! empty( $carrier['enabled'] ) ? 1 : 0,
            );
        }

        return array_values( $output );
    }

    /* ============================================================
     *  بازسازی خودکار (یک بار)
     * ============================================================ */
    public function maybe_repair() {

        if ( get_option( 'wcup_settings_repaired' ) ) {
            return;
        }

        $settings = get_option( self::OPTION_KEY, null );

        if ( is_array( $settings ) ) {

            $check_keys = array(
                'menu_dashboard', 'menu_orders', 'menu_downloads',
                'menu_reviews', 'menu_licenses', 'menu_edit_account',
                'menu_logout', 'progress_enabled', 'tracking_enabled',
                'notices_enabled',
            );

            $all_zero = true;
            foreach ( $check_keys as $k ) {
                if ( ! empty( $settings[ $k ] ) ) {
                    $all_zero = false;
                    break;
                }
            }

            if ( ! empty( $settings['enabled'] ) && $all_zero ) {

                $defaults = self::get_defaults();

                foreach ( $defaults as $k => $v ) {
                    $current = isset( $settings[ $k ] ) ? $settings[ $k ] : null;
                    if ( ( $current === null || $current === 0 || $current === '' || $current === '0' ) && ! empty( $v ) ) {
                        $settings[ $k ] = $v;
                    }
                }

                update_option( self::OPTION_KEY, $settings );
            }
        }

        update_option( 'wcup_settings_repaired', 1 );
    }
}