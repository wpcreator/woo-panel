<?php
defined( 'ABSPATH' ) || exit;

/* ============================================================
 *  ⚠️ Wrappers اول تعریف می‌شن
 * ============================================================ */

if ( ! function_exists( 'wcup_fa_num' ) ) {
    function wcup_fa_num( $input ) { return wcup_helpers::fa_num( $input ); }
}
if ( ! function_exists( 'wcup_order_status_badge' ) ) {
    function wcup_order_status_badge( $order ) { return wcup_helpers::order_status_badge( $order ); }
}
if ( ! function_exists( 'wcup_get_carriers' ) ) {
    function wcup_get_carriers() { return wcup_helpers::get_carriers(); }
}
if ( ! function_exists( 'wcup_get_carrier_label' ) ) {
    function wcup_get_carrier_label( $key ) { return wcup_helpers::get_carrier_label( $key ); }
}
if ( ! function_exists( 'wcup_get_tracking_url' ) ) {
    function wcup_get_tracking_url( $order ) { return wcup_helpers::get_tracking_url( $order ); }
}
if ( ! function_exists( 'wcup_get_user_notices' ) ) {
    function wcup_get_user_notices( $user_id ) { return wcup_helpers::get_user_notices( $user_id ); }
}
if ( ! function_exists( 'wcup_render_user_notices' ) ) {
    function wcup_render_user_notices( $user_id ) { wcup_helpers::render_user_notices( $user_id ); }
}
if ( ! function_exists( 'wcup_get_profile_completion' ) ) {
    function wcup_get_profile_completion( $user_id ) { return wcup_helpers::get_profile_completion( $user_id ); }
}
if ( ! function_exists( 'wcup_get_default_avatar_url' ) ) {
    function wcup_get_default_avatar_url( $size = 96 ) { return wcup_helpers::get_default_avatar_url( $size ); }
}
if ( ! function_exists( 'wcup_get_wishlist_count' ) ) {
    function wcup_get_wishlist_count( $user_id = 0 ) { return wcup_helpers::get_wishlist_count( $user_id ); }
}
if ( ! function_exists( 'wcup_get_user_stats' ) ) {
    function wcup_get_user_stats( $user_id = 0 ) { return wcup_helpers::get_user_stats( $user_id ); }
}
if ( ! function_exists( 'wcup_search_user_orders' ) ) {
    function wcup_search_user_orders( $user_id, $search = '' ) { return wcup_helpers::search_user_orders( $user_id, $search ); }
}

/* ⚠️ اگه کلاس قبلاً لود شده، همین‌جا برگرد */
if ( class_exists( 'wcup_helpers' ) ) {
    return;
}

/* ============================================================
 *  کلاس اصلی
 * ============================================================ */
class wcup_helpers {

    /* ============================================================
     *  اعداد فارسی
     * ============================================================ */
    public static function fa_num( $input ) {
        if ( is_array( $input ) ) {
            return array_map( array( __CLASS__, 'fa_num' ), $input );
        }
        $en = array( '0','1','2','3','4','5','6','7','8','9' );
        $fa = array( '۰','۱','۲','۳','۴','۵','۶','۷','۸','۹' );
        return str_replace( $en, $fa, (string) $input );
    }

    /* ============================================================
     *  بج وضعیت سفارش (HTML)
     * ============================================================ */
    public static function order_status_badge( $order ) {
        if ( is_numeric( $order ) ) {
            $order = wc_get_order( $order );
        }
        if ( ! $order instanceof WC_Order ) {
            return '';
        }
        $status = $order->get_status();
        $map = array(
            'pending'    => array( 'label' => 'در انتظار پرداخت', 'class' => 'is-pending' ),
            'processing' => array( 'label' => 'در حال انجام',      'class' => 'is-processing' ),
            'on-hold'    => array( 'label' => 'در انتظار بررسی',   'class' => 'is-on-hold' ),
            'completed'  => array( 'label' => 'تکمیل شده',         'class' => 'is-completed' ),
            'cancelled'  => array( 'label' => 'لغو شده',           'class' => 'is-cancelled' ),
            'refunded'   => array( 'label' => 'مسترد شده',         'class' => 'is-refunded' ),
            'failed'     => array( 'label' => 'ناموفق',            'class' => 'is-failed' ),
        );
        $data = isset( $map[ $status ] ) ? $map[ $status ] : array( 'label' => $status, 'class' => 'is-default' );
        return sprintf(
            '<span class="wcup-status-badge %s">%s</span>',
            esc_attr( $data['class'] ),
            esc_html( $data['label'] )
        );
    }

    /* ============================================================
     *  شرکت‌های حمل — خواندن از تنظیمات
     * ============================================================ */
    public static function get_carriers() {

        $settings = get_option( 'wcup_settings', array() );
        $carriers = isset( $settings['carriers'] ) && is_array( $settings['carriers'] )
            ? $settings['carriers']
            : array();

        if ( empty( $carriers ) ) {
            return self::get_default_carriers();
        }

        $result = array();

        foreach ( $carriers as $c ) {

            if ( empty( $c['key'] ) || empty( $c['enabled'] ) ) {
                continue;
            }

            $result[ $c['key'] ] = array(
                'label' => isset( $c['label'] ) ? $c['label'] : '',
                'url'   => isset( $c['url'] )   ? $c['url']   : '',
            );
        }

        return $result;
    }

    /* ============================================================
     *  شرکت‌های پیش‌فرض (fallback)
     * ============================================================ */
    public static function get_default_carriers() {
        return array(
            'post'   => array( 'label' => 'پست جمهوری اسلامی', 'url' => 'https://tracking.post.ir/?id={code}' ),
            'tipax'  => array( 'label' => 'تیپاکس',             'url' => 'https://tipaxco.com/tracking?code={code}' ),
            'chapar' => array( 'label' => 'چاپار',              'url' => 'https://chapar.ir/tracking/{code}' ),
            'mahex'  => array( 'label' => 'ماهکس',              'url' => 'https://mahex.com/tracking/{code}' ),
            'peyk'   => array( 'label' => 'پیک',                'url' => '' ),
            'other'  => array( 'label' => 'سایر',               'url' => '' ),
        );
    }

    /* ============================================================
     *  برچسب شرکت حمل
     * ============================================================ */
    public static function get_carrier_label( $key ) {

        if ( ! $key ) {
            return '—';
        }

        $carriers = self::get_carriers();

        if ( isset( $carriers[ $key ]['label'] ) ) {
            return $carriers[ $key ]['label'];
        }

        return $key;
    }

    /* ============================================================
     *  URL رهگیری
     * ============================================================ */
    public static function get_tracking_url( $order ) {
        if ( ! $order instanceof WC_Order ) {
            return '';
        }
        $carrier = $order->get_meta( '_wcup_tracking_carrier' );
        $code    = $order->get_meta( '_wcup_tracking_code' );
        $url     = $order->get_meta( '_wcup_tracking_url' );

        if ( $url ) {
            return $url;
        }
        $carriers = self::get_carriers();
        if ( isset( $carriers[ $carrier ]['url'] ) && $carriers[ $carrier ]['url'] ) {
            return str_replace( '{code}', rawurlencode( $code ), $carriers[ $carrier ]['url'] );
        }
        return '';
    }

    /* ============================================================
     *  جستجوی سفارشات کاربر
     * ============================================================ */
    public static function search_user_orders( $user_id, $search = '' ) {

        if ( ! $user_id || ! function_exists( 'wc_get_orders' ) ) {
            return array();
        }

        $base_args = array(
            'customer' => $user_id,
            'limit'    => 20,
            'orderby'  => 'date',
            'order'    => 'DESC',
            'status'   => 'any',
        );

        if ( $search === '' ) {
            return wc_get_orders( $base_args );
        }

        $search_clean = trim( $search );

        /* ── جستجو بر اساس شماره سفارش ── */
        if ( is_numeric( $search_clean ) ) {
            $args        = $base_args;
            $args['id']  = (int) $search_clean;
            $orders      = wc_get_orders( $args );

            if ( ! empty( $orders ) ) {
                return $orders;
            }
        }

        /* ── فیلتر دستی روی سفارشات کاربر ── */
        $orders = wc_get_orders( $base_args );

        $filtered = array();

        if ( is_array( $orders ) ) {
            foreach ( $orders as $o ) {
                if ( ! $o instanceof WC_Order ) continue;

                $order_number  = (string) $o->get_order_number();
                $billing_email = (string) $o->get_billing_email();
                $billing_phone = (string) $o->get_billing_phone();

                if (
                    $order_number === $search_clean ||
                    $billing_email === $search_clean ||
                    $billing_phone === $search_clean
                ) {
                    $filtered[] = $o;
                }
            }
        }

        return $filtered;
    }

    /* ============================================================
     *  اطلاعیه‌های کاربر
     * ============================================================ */
    public static function get_user_notices( $user_id ) {

        $dismissed = get_user_meta( $user_id, '_wcup_dismissed_notices', true );
        $dismissed = is_array( $dismissed ) ? $dismissed : array();

        $notices = get_posts( array(
            'post_type'      => 'wcup_notice',
            'post_status'    => 'publish',
            'posts_per_page' => 10,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ) );

        $result = array();

        foreach ( $notices as $notice ) {
            if ( in_array( $notice->ID, $dismissed, true ) ) {
                continue;
            }
            $result[] = array(
                'id'          => $notice->ID,
                'title'       => $notice->post_title,
                'content'     => apply_filters( 'the_content', $notice->post_content ),
                'type'        => get_post_meta( $notice->ID, '_wcup_notice_type', true ) ?: 'info',
                'priority'    => get_post_meta( $notice->ID, '_wcup_notice_priority', true ) ?: 'normal',
                'dismissible' => get_post_meta( $notice->ID, '_wcup_notice_dismissible', true ) === '1',
                'date'        => $notice->post_date,
            );
        }

        usort( $result, function ( $a, $b ) {
            if ( $a['priority'] === $b['priority'] ) return 0;
            return $a['priority'] === 'high' ? -1 : 1;
        } );

        return $result;
    }

    /* ============================================================
     *  رندر اطلاعیه‌ها
     * ============================================================ */
    public static function render_user_notices( $user_id ) {

        $notices = self::get_user_notices( $user_id );
        if ( empty( $notices ) ) return;

        foreach ( $notices as $notice ) :
            $type_class = 'wcup-notice--' . esc_attr( $notice['type'] );
            ?>
            <div class="wcup-notice <?php echo esc_attr( $type_class ); ?>"
                 data-notice-id="<?php echo esc_attr( $notice['id'] ); ?>">

                <div class="wcup-notice-icon">
                    <?php echo self::notice_icon( $notice['type'] ); // phpcs:ignore ?>
                </div>

                <div class="wcup-notice-body">
                    <?php if ( $notice['title'] ) : ?>
                        <div class="wcup-notice-title"><?php echo esc_html( $notice['title'] ); ?></div>
                    <?php endif; ?>
                    <div class="wcup-notice-content"><?php echo wp_kses_post( $notice['content'] ); ?></div>
                </div>

                <?php if ( $notice['dismissible'] ) : ?>
                    <button type="button"
                            class="wcup-notice-close"
                            data-notice-id="<?php echo esc_attr( $notice['id'] ); ?>"
                            aria-label="بستن">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.5"
                             stroke-linecap="round" stroke-linejoin="round">
                            <line x1="18" y1="6" x2="6" y2="18"></line>
                            <line x1="6" y1="6" x2="18" y2="18"></line>
                        </svg>
                    </button>
                <?php endif; ?>
            </div>
            <?php
        endforeach;
    }

    /* ============================================================
     *  آیکون اطلاعیه
     * ============================================================ */
    public static function notice_icon( $type ) {
        switch ( $type ) {
            case 'success':
                return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>';
            case 'warning':
                return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>';
            case 'danger':
                return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>';
            default:
                return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>';
        }
    }

    /* ============================================================
     *  URL آواتار پیش‌فرض
     * ============================================================ */
    public static function get_default_avatar_url( $size = 96 ) {

        if ( class_exists( 'wcup_settings' ) ) {
            $custom_default = (int) wcup_settings::get( 'default_avatar_id', 0 );
            if ( $custom_default ) {
                $url = wp_get_attachment_image_url( $custom_default, array( $size, $size ) );
                if ( $url ) {
                    return $url;
                }
            }
        }

        if ( defined( 'WCUP_PATH' ) && defined( 'WCUP_URL' ) ) {
            $file = WCUP_PATH . 'assets/img/default-avatar.png';
            if ( file_exists( $file ) ) {
                return WCUP_URL . 'assets/img/default-avatar.png';
            }
        }

        return get_avatar_url( 0, array( 'size' => $size ) );
    }

    /* ============================================================
     *  شمارش علاقه‌مندی‌ها — فقط سیستم داخلی
     * ============================================================ */
    public static function get_wishlist_count( $user_id = 0 ) {

        if ( ! $user_id ) {
            $user_id = get_current_user_id();
        }

        if ( ! $user_id ) {
            return 0;
        }

        /* فقط سیستم داخلی WCUP */
        if ( class_exists( 'wcup_wishlist' ) ) {
            return (int) wcup_wishlist::count( $user_id );
        }

        return 0;
    }

    /* ============================================================
     *  آمار کامل کاربر
     * ============================================================ */
    public static function get_user_stats( $user_id = 0 ) {

        if ( ! $user_id ) {
            $user_id = get_current_user_id();
        }

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return array();
        }

        $total_orders      = 0;
        $completed_orders  = 0;
        $processing_orders = 0;
        $total_spent       = 0;
        $avg_order         = 0;
        $last_order        = null;

        if ( function_exists( 'wc_get_orders' ) ) {

            $all = wc_get_orders( array(
                'customer' => $user_id,
                'limit'    => -1,
                'return'   => 'ids',
                'status'   => array( 'pending', 'processing', 'on-hold', 'completed', 'cancelled', 'refunded', 'failed' ),
            ) );
            $total_orders = is_array( $all ) ? count( $all ) : 0;

            $completed = wc_get_orders( array(
                'customer' => $user_id,
                'limit'    => -1,
                'return'   => 'ids',
                'status'   => 'completed',
            ) );
            $completed_orders = is_array( $completed ) ? count( $completed ) : 0;

            $processing = wc_get_orders( array(
                'customer' => $user_id,
                'limit'    => -1,
                'return'   => 'ids',
                'status'   => array( 'processing', 'on-hold' ),
            ) );
            $processing_orders = is_array( $processing ) ? count( $processing ) : 0;

            $total_spent = (float) wc_get_customer_total_spent( $user_id );

            $paid_count = (int) wc_get_customer_order_count( $user_id );
            $avg_order  = $paid_count > 0 ? $total_spent / $paid_count : 0;

            $last_orders = wc_get_orders( array(
                'customer' => $user_id,
                'limit'    => 1,
                'orderby'  => 'date',
                'order'    => 'DESC',
                'status'   => 'any',
            ) );
            $last_order = ! empty( $last_orders ) ? $last_orders[0] : null;
        }

        $registered_ts = strtotime( $user->user_registered );
        $member_days   = $registered_ts ? (int) floor( ( time() - $registered_ts ) / DAY_IN_SECONDS ) : 0;

        $comment_count = (int) get_comments( array(
            'user_id'   => $user_id,
            'count'     => true,
            'status'    => 'approve',
            'post_type' => 'product',
        ) );

        $download_count = 0;
        if ( function_exists( 'wc_get_customer_available_downloads' ) ) {
            $downloads = wc_get_customer_available_downloads( $user_id );
            $seen      = array();
            if ( is_array( $downloads ) ) {
                foreach ( $downloads as $dl ) {
                    $key = isset( $dl['product_id'] ) ? 'p' . $dl['product_id'] : '';
                    if ( $key === '' && ! empty( $dl['download_name'] ) ) {
                        $key = 'n' . md5( $dl['download_name'] );
                    }
                    if ( $key === '' ) continue;
                    $seen[ $key ] = true;
                }
            }
            $download_count = count( $seen );
        }

        $wishlist_count = self::get_wishlist_count( $user_id );

        $avatar_id  = (int) get_user_meta( $user_id, 'wcup_avatar_id', true );
        $avatar_url = $avatar_id
            ? wp_get_attachment_image_url( $avatar_id, 'thumbnail' )
            : self::get_default_avatar_url( 96 );

        return array(
            'total_orders'      => $total_orders,
            'completed_orders'  => $completed_orders,
            'processing_orders' => $processing_orders,
            'total_spent'       => $total_spent,
            'avg_order'         => $avg_order,
            'member_days'       => $member_days,
            'comment_count'     => $comment_count,
            'download_count'    => $download_count,
            'wishlist_count'    => $wishlist_count,
            'last_order'        => $last_order,
            'avatar_url'        => $avatar_url,
            'registered'        => $user->user_registered,
        );
    }

    /* ============================================================
     *  درصد تکمیل پروفایل
     * ============================================================ */
    public static function get_profile_completion( $user_id ) {

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return array( 'percent' => 0, 'steps' => array(), 'done' => 0, 'total' => 0 );
        }

        $account_url = wc_get_endpoint_url( 'edit-account', '', wc_get_page_permalink( 'myaccount' ) );
        $address_url = wc_get_endpoint_url( 'edit-address', 'billing', wc_get_page_permalink( 'myaccount' ) );

        $checks = array(
            'first_name'       => array( 'label' => 'نام',            'done' => ! empty( $user->first_name ),                                  'url' => $account_url ),
            'last_name'        => array( 'label' => 'نام خانوادگی',    'done' => ! empty( $user->last_name ),                                   'url' => $account_url ),
            'email'            => array( 'label' => 'ایمیل',           'done' => is_email( $user->user_email ),                                 'url' => $account_url ),
            'avatar'           => array( 'label' => 'عکس پروفایل',    'done' => (bool) get_user_meta( $user_id, 'wcup_avatar_id', true ),      'url' => $account_url ),
            'billing_phone'    => array( 'label' => 'شماره تماس',      'done' => (bool) get_user_meta( $user_id, 'billing_phone', true ),       'url' => $address_url ),
            'billing_address'  => array( 'label' => 'آدرس',            'done' => (bool) get_user_meta( $user_id, 'billing_address_1', true ),   'url' => $address_url ),
            'billing_city'     => array( 'label' => 'شهر',             'done' => (bool) get_user_meta( $user_id, 'billing_city', true ),        'url' => $address_url ),
            'billing_postcode' => array( 'label' => 'کد پستی',         'done' => (bool) get_user_meta( $user_id, 'billing_postcode', true ),    'url' => $address_url ),
        );

        $done_count = 0;
        foreach ( $checks as $check ) {
            if ( $check['done'] ) $done_count++;
        }

        $total   = count( $checks );
        $percent = $total ? round( ( $done_count / $total ) * 100 ) : 0;

        return array(
            'percent' => (int) $percent,
            'steps'   => $checks,
            'done'    => $done_count,
            'total'   => $total,
        );
    }
}