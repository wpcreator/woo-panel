<?php
/**
 * My Account > Orders (Custom Override)
 * @version 3.0.1
 */

defined( 'ABSPATH' ) || exit;

/* 🔧 TEST: چک وجود توابع */
if ( ! function_exists( 'wcup_fa_num' ) ) {
    /* fallback */
    function wcup_fa_num( $input ) {
        $en = array( '0','1','2','3','4','5','6','7','8','9' );
        $fa = array( '۰','۱','۲','۳','۴','۵','۶','۷','۸','۹' );
        return str_replace( $en, $fa, (string) $input );
    }
}

/* ============================================================
 *  تب‌های فیلتر
 * ============================================================ */
$status_tabs = array(
    'all'        => array( 'label' => 'همه',            'statuses' => array( 'pending', 'processing', 'on-hold', 'completed', 'cancelled', 'refunded', 'failed' ) ),
    'processing' => array( 'label' => 'در حال انجام',   'statuses' => array( 'processing' ) ),
    'completed'  => array( 'label' => 'تکمیل شده',      'statuses' => array( 'completed' ) ),
    'pending'    => array( 'label' => 'در انتظار',      'statuses' => array( 'pending', 'on-hold' ) ),
    'cancelled'  => array( 'label' => 'لغو شده',        'statuses' => array( 'cancelled', 'refunded', 'failed' ) ),
);

$active_tab = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : 'all';
if ( ! isset( $status_tabs[ $active_tab ] ) ) {
    $active_tab = 'all';
}
$current_statuses = $status_tabs[ $active_tab ]['statuses'];

/* ============================================================
 *  گرفتن سفارش‌ها
 * ============================================================ */
$current_page = max( 1, get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1 );
$per_page     = 10;
$user_id      = get_current_user_id();

/* 🔧 safe query */
$orders       = array();
$total_orders = 0;
$max_pages    = 1;

try {
    $customer_orders = wc_get_orders( array(
        'customer' => $user_id,
        'limit'    => $per_page,
        'page'     => $current_page,
        'paginate' => true,
        'orderby'  => 'date',
        'order'    => 'DESC',
        'status'   => $current_statuses,
    ) );

    if ( is_object( $customer_orders ) ) {
        $orders       = isset( $customer_orders->orders ) ? $customer_orders->orders : array();
        $total_orders = isset( $customer_orders->total ) ? (int) $customer_orders->total : 0;
        $max_pages    = isset( $customer_orders->max_num_pages ) ? (int) $customer_orders->max_num_pages : 1;
    }
} catch ( Throwable $e ) {
    if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
        error_log( 'WCUP orders query failed: ' . $e->getMessage() );
    }
}

/* URL پایه */
$base_url = wc_get_endpoint_url( 'orders', '', wc_get_page_permalink( 'myaccount' ) );
if ( 'all' !== $active_tab ) {
    $base_url = add_query_arg( 'status', $active_tab, $base_url );
}

/* ============================================================
 *  order status info
 * ============================================================ */
if ( ! function_exists( 'wcup_get_order_status_info' ) ) {
    function wcup_get_order_status_info( $status ) {
        $map = array(
            'pending'        => array( 'label' => 'در انتظار پرداخت', 'class' => 'pending' ),
            'processing'     => array( 'label' => 'در حال انجام',     'class' => 'processing' ),
            'on-hold'        => array( 'label' => 'در انتظار بررسی',  'class' => 'on-hold' ),
            'completed'      => array( 'label' => 'تکمیل شده',        'class' => 'completed' ),
            'cancelled'      => array( 'label' => 'لغو شده',          'class' => 'cancelled' ),
            'refunded'       => array( 'label' => 'مسترد شده',        'class' => 'refunded' ),
            'failed'         => array( 'label' => 'ناموفق',           'class' => 'failed' ),
            'checkout-draft' => array( 'label' => 'پیش‌نویس',         'class' => 'pending' ),
        );
        return isset( $map[ $status ] )
            ? $map[ $status ]
            : array( 'label' => $status, 'class' => 'pending' );
    }
}

/* ============================================================
 *  شمارش سفارش‌ها در هر تب (با try/catch)
 * ============================================================ */
$tab_counts = array();

foreach ( $status_tabs as $tab_key => $tab_data ) {

    $tab_counts[ $tab_key ] = 0;

    try {
        $result = wc_get_orders( array(
            'customer' => $user_id,
            'limit'    => 1,
            'paginate' => true,
            'status'   => $tab_data['statuses'],
        ) );

        if ( is_object( $result ) && isset( $result->total ) ) {
            $tab_counts[ $tab_key ] = (int) $result->total;
        }
    } catch ( Throwable $e ) {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( 'WCUP count failed for tab ' . $tab_key . ': ' . $e->getMessage() );
        }
    }
}
?>

<div class="wcup-orders-page" dir="rtl">

    <!-- ═══ تب‌های فیلتر ═══ -->
    <div class="wcup-ord-tabs">
        <?php foreach ( $status_tabs as $tab_key => $tab_data ) :
            $is_active = ( $tab_key === $active_tab );
            $count     = isset( $tab_counts[ $tab_key ] ) ? $tab_counts[ $tab_key ] : 0;

            $tab_url = ( 'all' === $tab_key )
                ? wc_get_endpoint_url( 'orders', '', wc_get_page_permalink( 'myaccount' ) )
                : add_query_arg( 'status', $tab_key, wc_get_endpoint_url( 'orders', '', wc_get_page_permalink( 'myaccount' ) ) );
        ?>
            <a href="<?php echo esc_url( $tab_url ); ?>"
               class="wcup-ord-tab <?php echo $is_active ? 'is-active' : ''; ?>">
                <span><?php echo esc_html( $tab_data['label'] ); ?></span>
                <span class="wcup-ord-tab-count">
                    <?php echo esc_html( wcup_fa_num( $count ) ); ?>
                </span>
            </a>
        <?php endforeach; ?>
    </div>

    <?php if ( empty( $orders ) ) : ?>

        <div class="wcup-ord-empty">
            <div class="wcup-ord-empty-icon">🛍️</div>
            <div class="wcup-ord-empty-title">
                <?php if ( 'all' === $active_tab ) : ?>
                    هنوز سفارشی ثبت نکردی
                <?php else : ?>
                    سفارشی با این وضعیت پیدا نشد
                <?php endif; ?>
            </div>
            <div class="wcup-ord-empty-desc">
                <?php if ( 'all' === $active_tab ) : ?>
                    وقتی اولین سفارشت رو ثبت کنی، اینجا نمایش داده میشه.
                <?php else : ?>
                    می‌تونی تب «همه» رو بزنی تا همهٔ سفارش‌هات رو ببینی.
                <?php endif; ?>
            </div>
            <?php if ( 'all' === $active_tab ) : ?>
                <a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"
                   class="wcup-ord-empty-btn">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2.5"
                         stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="9" cy="21" r="1"></circle>
                        <circle cx="20" cy="21" r="1"></circle>
                        <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                    </svg>
                    <span>شروع خرید</span>
                </a>
            <?php endif; ?>
        </div>

    <?php else : ?>

        <div class="wcup-ord-list">
            <?php foreach ( $orders as $order ) :

                if ( ! $order instanceof WC_Order ) {
                    continue;
                }

                $order_number = $order->get_order_number();
                $order_date   = $order->get_date_created();
                $order_total  = $order->get_formatted_order_total();
                $order_status = $order->get_status();
                $item_count   = $order->get_item_count();
                $order_url    = $order->get_view_order_url();
                $badge        = wcup_get_order_status_info( $order_status );

                $items              = $order->get_items();
                $first_product_name = '';
                $first_product_img  = '';

                if ( ! empty( $items ) ) {
                    foreach ( $items as $item ) {
                        $product = $item->get_product();
                        if ( $product ) {
                            $first_product_name = $item->get_name();
                            $img_id = $product->get_image_id();
                            if ( $img_id ) {
                                $first_product_img = wp_get_attachment_image_url( $img_id, 'thumbnail' );
                            }
                            break;
                        }
                    }
                }
                if ( ! $first_product_img ) {
                    $first_product_img = wc_placeholder_img_src();
                }

                $date_str = $order_date ? date_i18n( 'j F Y', $order_date->getTimestamp() ) : '—';
            ?>

                <div class="wcup-ord-card">

                    <div class="wcup-ord-card-head">
                        <div class="wcup-ord-card-head-info">
                            <a href="<?php echo esc_url( $order_url ); ?>"
                               class="wcup-ord-card-number">
                                سفارش #<?php echo esc_html( wcup_fa_num( $order_number ) ); ?>
                            </a>
                            <div class="wcup-ord-card-sub">
                                <span class="wcup-ord-card-date"><?php echo esc_html( $date_str ); ?></span>
                                <span class="wcup-ord-card-dot">●</span>
                                <span class="wcup-ord-card-items">
                                    <?php echo esc_html( wcup_fa_num( $item_count ) ); ?> آیتم
                                </span>
                            </div>
                        </div>

                        <div class="wcup-ord-badge wcup-ord-badge--<?php echo esc_attr( $badge['class'] ); ?>">
                            <?php echo esc_html( $badge['label'] ); ?>
                        </div>
                    </div>

                    <a href="<?php echo esc_url( $order_url ); ?>" class="wcup-ord-product">
                        <div class="wcup-ord-product-img-wrap">
                            <img src="<?php echo esc_url( $first_product_img ); ?>"
                                 alt="<?php echo esc_attr( $first_product_name ); ?>"
                                 class="wcup-ord-product-img"
                                 loading="lazy">
                        </div>
                        <div class="wcup-ord-product-name">
                            <?php echo esc_html( $first_product_name ); ?>
                            <?php if ( $item_count > 1 ) : ?>
                                <span class="wcup-ord-product-more">
                                    و <?php echo esc_html( wcup_fa_num( $item_count - 1 ) ); ?> محصول دیگر
                                </span>
                            <?php endif; ?>
                        </div>
                    </a>

                    <div class="wcup-ord-card-foot">
                        <div class="wcup-ord-card-price">
                            <?php echo wp_kses_post( $order_total ); ?>
                        </div>
                        <a href="<?php echo esc_url( $order_url ); ?>" class="wcup-ord-view-btn">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                                 stroke="currentColor" stroke-width="2.5"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <line x1="19" y1="12" x2="5" y2="12"></line>
                                <polyline points="12 19 5 12 12 5"></polyline>
                            </svg>
                            <span>مشاهده</span>
                        </a>
                    </div>

                </div>

            <?php endforeach; ?>
        </div>

        <?php if ( $max_pages > 1 ) : ?>
            <div class="wcup-ord-pagination">

                <?php if ( $current_page > 1 ) :
                    $prev_url = ( $current_page - 1 > 1 )
                        ? add_query_arg( 'paged', $current_page - 1, $base_url )
                        : $base_url;
                ?>
                    <a href="<?php echo esc_url( $prev_url ); ?>" class="wcup-ord-page-btn">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.5"
                             stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="9 18 15 12 9 6"></polyline>
                        </svg>
                        <span>قبلی</span>
                    </a>
                <?php endif; ?>

                <div class="wcup-ord-page-numbers">
                    <?php for ( $i = 1; $i <= $max_pages; $i++ ) :
                        $page_url = ( $i === 1 ) ? $base_url : add_query_arg( 'paged', $i, $base_url );
                        $is_cur   = ( $i === $current_page );
                    ?>
                        <a href="<?php echo esc_url( $page_url ); ?>"
                           class="wcup-ord-page-num <?php echo $is_cur ? 'is-active' : ''; ?>">
                            <?php echo esc_html( wcup_fa_num( $i ) ); ?>
                        </a>
                    <?php endfor; ?>
                </div>

                <?php if ( $current_page < $max_pages ) :
                    $next_url = add_query_arg( 'paged', $current_page + 1, $base_url );
                ?>
                    <a href="<?php echo esc_url( $next_url ); ?>" class="wcup-ord-page-btn">
                        <span>بعدی</span>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.5"
                             stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="15 18 9 12 15 6"></polyline>
                        </svg>
                    </a>
                <?php endif; ?>

            </div>
        <?php endif; ?>

    <?php endif; ?>

</div>