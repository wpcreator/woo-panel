<?php
/**
 * @var WC_Order $order
 * @var string   $invoice_number
 * @var string   $date_str
 * @var array    $items
 * @var callable $fa
 * @var string   $css
 * @var string   $invoice_thanks_text
 * @var string   $invoice_footer_note
 * @var string   $invoice_terms_text
 * @var int      $invoice_show_qr
 * @var int      $invoice_show_tracking
 * @var int      $invoice_show_terms
 */
defined( 'ABSPATH' ) || exit;
?>

<style>
<?php echo $css; // phpcs:ignore -- CSS امن از فایل خودمون ?>
</style>

<div class="wcup-inv" dir="rtl" lang="fa">

    <!-- ═══ Header ═══ -->
    <div class="wcup-inv-header">
        <div class="wcup-inv-header-right">
            <?php if ( $logo_url ) : ?>
                <img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $shop_name ); ?>" class="wcup-inv-logo">
            <?php else : ?>
                <div class="wcup-inv-logo-text"><?php echo esc_html( $shop_name ); ?></div>
            <?php endif; ?>
        </div>

        <div class="wcup-inv-header-left">
            <div class="wcup-inv-title" dir="rtl">فاکتور فروش</div>
            <div class="wcup-inv-number" dir="ltr"><?php echo esc_html( $invoice_number ); ?></div>
        </div>
    </div>

    <!-- ═══ Info Grid ═══ -->
    <table class="wcup-inv-info-grid" cellspacing="0" cellpadding="0">
        <tr>
            <td class="wcup-inv-info-box" dir="rtl">
                <div class="wcup-inv-info-title">فروشنده</div>
                <div class="wcup-inv-info-content">
                    <strong><?php echo esc_html( $shop_name ); ?></strong>
                    <?php if ( $shop_address ) : ?>
                        <div><?php echo esc_html( $shop_address ); ?></div>
                    <?php endif; ?>
                    <?php if ( $shop_phone ) : ?>
                        <div>تلفن: <?php echo esc_html( $fa( $shop_phone ) ); ?></div>
                    <?php endif; ?>
                    <?php if ( $shop_email ) : ?>
                        <div><?php echo esc_html( $shop_email ); ?></div>
                    <?php endif; ?>
                </div>
            </td>
            <td class="wcup-inv-info-spacer"></td>
            <td class="wcup-inv-info-box" dir="rtl">
                <div class="wcup-inv-info-title">خریدار</div>
                <div class="wcup-inv-info-content">
                    <?php if ( $billing_name ) : ?>
                        <strong><?php echo esc_html( $billing_name ); ?></strong>
                    <?php endif; ?>
                    <?php if ( $billing_company ) : ?>
                        <div><?php echo esc_html( $billing_company ); ?></div>
                    <?php endif; ?>
                    <?php if ( $billing_address ) : ?>
                        <div><?php echo esc_html( $billing_address ); ?></div>
                    <?php endif; ?>
                    <?php if ( $billing_phone ) : ?>
                        <div>تلفن: <?php echo esc_html( $fa( $billing_phone ) ); ?></div>
                    <?php endif; ?>
                    <?php if ( $billing_email ) : ?>
                        <div><?php echo esc_html( $billing_email ); ?></div>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
    </table>

    <!-- ═══ Meta Row ═══ -->
    <table class="wcup-inv-meta" cellspacing="0" cellpadding="0">
        <tr>
            <td class="wcup-inv-meta-item" dir="rtl">
                <span class="label">شمارهٔ فاکتور:</span>
                <span class="value" dir="ltr"><?php echo esc_html( $invoice_number ); ?></span>
            </td>
            <td class="wcup-inv-meta-item" dir="rtl">
                <span class="label">شمارهٔ سفارش:</span>
                <span class="value">#<?php echo esc_html( $fa( $order->get_order_number() ) ); ?></span>
            </td>
            <td class="wcup-inv-meta-item" dir="rtl">
                <span class="label">تاریخ:</span>
                <span class="value"><?php echo esc_html( $fa( $date_str ) ); ?></span>
            </td>
            <td class="wcup-inv-meta-item" dir="rtl">
                <span class="label">وضعیت:</span>
                <span class="value"><?php echo esc_html( $status_label ); ?></span>
            </td>
        </tr>
    </table>

    <!-- ═══ Items Table ═══ -->
    <table class="wcup-inv-table" cellspacing="0" cellpadding="0" dir="rtl">
        <thead>
            <tr>
                <th class="col-num">#</th>
                <th class="col-name">شرح کالا</th>
                <th class="col-qty">تعداد</th>
                <th class="col-price">قیمت واحد</th>
                <th class="col-total">جمع</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ( $items as $i => $item ) :
                $unit_price = $item['qty'] > 0 ? ( $item['total'] / $item['qty'] ) : 0;
            ?>
                <tr>
                    <td class="col-num"><?php echo esc_html( $fa( $i + 1 ) ); ?></td>
                    <td class="col-name" dir="rtl">
                        <div class="wcup-inv-item-row">
                            <?php if ( ! empty( $item['img'] ) ) : ?>
                                <img src="<?php echo esc_url( $item['img'] ); ?>"
                                     alt="<?php echo esc_attr( $item['name'] ); ?>"
                                     class="wcup-inv-item-img"
                                     loading="lazy">
                            <?php endif; ?>
                            <div class="wcup-inv-item-info">
                                <strong><?php echo esc_html( $item['name'] ); ?></strong>
                                <?php if ( $item['sku'] ) : ?>
                                    <div class="wcup-inv-sku">کد: <?php echo esc_html( $item['sku'] ); ?></div>
                                <?php endif; ?>
                                <?php if ( $item['meta'] ) : ?>
                                    <div class="wcup-inv-item-meta"><?php echo wp_kses_post( $item['meta'] ); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td class="col-qty"><?php echo esc_html( $fa( $item['qty'] ) ); ?></td>
                    <td class="col-price" dir="rtl"><?php echo wp_kses_post( wc_price( $unit_price ) ); ?></td>
                    <td class="col-total" dir="rtl"><?php echo wp_kses_post( wc_price( $item['total'] ) ); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- ═══ Totals ═══ -->
    <table class="wcup-inv-totals" cellspacing="0" cellpadding="0">
        <tr>
            <td class="wcup-inv-totals-spacer"></td>
            <td class="wcup-inv-totals-cell">
                <table class="wcup-inv-totals-table" cellspacing="0" cellpadding="0" dir="rtl">
                    <tr>
                        <td>جمع کل:</td>
                        <td dir="rtl"><?php echo wp_kses_post( wc_price( $subtotal ) ); ?></td>
                    </tr>

                    <?php if ( $discount > 0 ) : ?>
                        <tr class="wcup-inv-discount">
                            <td>تخفیف:</td>
                            <td dir="rtl">− <?php echo wp_kses_post( wc_price( $discount ) ); ?></td>
                        </tr>
                    <?php endif; ?>

                    <?php if ( $shipping > 0 ) : ?>
                        <tr>
                            <td>هزینهٔ ارسال:</td>
                            <td dir="rtl"><?php echo wp_kses_post( wc_price( $shipping ) ); ?></td>
                        </tr>
                    <?php endif; ?>

                    <?php if ( $tax > 0 ) : ?>
                        <tr>
                            <td>مالیات:</td>
                            <td dir="rtl"><?php echo wp_kses_post( wc_price( $tax ) ); ?></td>
                        </tr>
                    <?php endif; ?>

                    <tr class="wcup-inv-total-final">
                        <td>مبلغ نهایی:</td>
                        <td dir="rtl"><?php echo wp_kses_post( $formatted_total ); ?></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>

    <!-- ═══ Payment & Tracking ═══ -->
    <?php
    $show_payment   = ! empty( $payment_method );
    $show_txn       = ! empty( $transaction_id );
    $show_tracking  = ! empty( $invoice_show_tracking ) && ! empty( $tracking_code );

    $show_extra = $show_payment || $show_txn || $show_tracking;
    ?>
    <?php if ( $show_extra ) : ?>
        <table class="wcup-inv-extra" cellspacing="0" cellpadding="0">
            <tr>
                <?php if ( $show_payment ) : ?>
                    <td class="wcup-inv-extra-item" dir="rtl">
                        <span class="label">روش پرداخت:</span>
                        <span class="value"><?php echo esc_html( $payment_method ); ?></span>
                    </td>
                <?php endif; ?>
                <?php if ( $show_txn ) : ?>
                    <td class="wcup-inv-extra-item" dir="rtl">
                        <span class="label">کد پیگیری:</span>
                        <span class="value"><?php echo esc_html( $fa( $transaction_id ) ); ?></span>
                    </td>
                <?php endif; ?>
                <?php if ( $show_tracking ) : ?>
                    <td class="wcup-inv-extra-item" dir="rtl">
                        <span class="label">کد رهگیری مرسوله:</span>
                        <span class="value"><?php echo esc_html( $fa( $tracking_code ) ); ?></span>
                    </td>
                <?php endif; ?>
            </tr>
        </table>
    <?php endif; ?>

    <!-- ═══ Terms (اگه فعاله) ═══ -->
    <?php if ( ! empty( $invoice_show_terms ) && ! empty( $invoice_terms_text ) ) : ?>
        <div class="wcup-inv-terms" dir="rtl" style="margin:20px 32px 0;padding:14px 18px;background:#fffbeb;border:1px solid #fde68a;border-radius:10px;color:#92400e;font-size:11.5px;line-height:1.8;text-align:right;">
            <strong style="display:block;margin-bottom:6px;color:#b45309;font-size:12.5px;">📋 شرایط و قوانین</strong>
            <?php echo nl2br( esc_html( $invoice_terms_text ) ); ?>
        </div>
    <?php endif; ?>

    <!-- ═══ Footer ═══ -->
    <table class="wcup-inv-footer" cellspacing="0" cellpadding="0">
        <tr>
            <?php if ( ! empty( $invoice_show_qr ) ) : ?>
                <td class="wcup-inv-footer-qr">
                    <img src="<?php echo esc_url( $qr_url ); ?>" alt="QR" class="wcup-inv-qr">
                    <div class="wcup-inv-qr-text">اسکن کنید<br>برای اعتبارسنجی</div>
                </td>
            <?php endif; ?>
            <td class="wcup-inv-footer-note" dir="rtl">
                <div class="wcup-inv-thanks"><?php echo esc_html( $invoice_thanks_text ); ?></div>
                <div class="wcup-inv-note"><?php echo esc_html( $invoice_footer_note ); ?></div>
            </td>
        </tr>
    </table>

</div>