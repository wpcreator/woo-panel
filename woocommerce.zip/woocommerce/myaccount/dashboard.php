<?php
/**
 * My Account > Dashboard — Full Stats (Toggleable)
 * @version 5.1.0
 */

defined( 'ABSPATH' ) || exit;

$current_user = wp_get_current_user();
$user_id      = $current_user->ID;

/* ═══ آمار کامل ═══ */
$stats = function_exists( 'wcup_get_user_stats' ) ? wcup_get_user_stats( $user_id ) : array();

/* ═══ پیشرفت پروفایل ═══ */
$profile = function_exists( 'wcup_get_profile_completion' )
    ? wcup_get_profile_completion( $user_id )
    : array( 'percent' => 0, 'done' => 0, 'total' => 0, 'steps' => array() );

/* ═══ تنظیمات — فعال/غیرفعال بودن کارت‌ها ═══ */
$opt = function ( $key, $default = 1 ) {
    return (int) wcup_settings::get( $key, $default );
};

/* ═══ نمایش برچسب‌های بخش‌بندی ═══ */
$show_section_titles = (bool) $opt( 'dash_show_section_titles' );

/* ═══ کلاس کمکی برای بخش‌ها ═══ */
$section_class = 'wcup-stats-section' . ( $show_section_titles ? '' : ' wcup-stats-section--no-title' );

/* ═══ لینک‌ها ═══ */
$my_account_url = wc_get_page_permalink( 'myaccount' );
$orders_url     = wc_get_endpoint_url( 'orders', '', $my_account_url );
$downloads_url  = wc_get_endpoint_url( 'downloads', '', $my_account_url );
$edit_url       = wc_get_endpoint_url( 'edit-account', '', $my_account_url );

/* ═══ ۳ سفارش آخر ═══ */
$recent_orders = ( function_exists( 'wc_get_orders' ) && $opt( 'dash_recent_orders' ) ) ? wc_get_orders( array(
    'customer' => $user_id,
    'limit'    => 3,
    'orderby'  => 'date',
    'order'    => 'DESC',
    'status'   => array( 'pending', 'processing', 'on-hold', 'completed' ),
) ) : array();

/* ═══ آیا حداقل یه کارت آماری فعاله؟ ═══ */
$has_purchase_stats = $opt( 'stat_total_spent' ) || $opt( 'stat_total_orders' ) || $opt( 'stat_avg_order' ) || $opt( 'stat_member_days' );
$has_status_stats   = $opt( 'stat_completed' ) || $opt( 'stat_processing' );
$has_activity_stats = $opt( 'stat_wishlist' ) || $opt( 'stat_comments' ) || $opt( 'stat_downloads' );
?>

<div class="wcup-dashboard" dir="rtl">

    <!-- ═══════════════════════════════════════════════════════
         ★ ۱) اطلاعیه‌ها
    ═══════════════════════════════════════════════════════════ -->
    <?php
    if ( $opt( 'dash_notices' ) && function_exists( 'wcup_render_user_notices' ) ) {
        wcup_render_user_notices( $user_id );
    }
    ?>


    <!-- ═══════════════════════════════════════════════════════
         ★ ۲) کارت خوش‌آمدگویی
    ═══════════════════════════════════════════════════════════ -->
    <?php if ( $opt( 'dash_hero' ) ) : ?>
    <div class="wcup-db-hero">
        <div class="wcup-db-hero-avatar">
            <img src="<?php echo esc_url( $stats['avatar_url'] ?? '' ); ?>"
                 alt="<?php echo esc_attr( $current_user->display_name ); ?>"
                 width="72" height="72" loading="lazy">
        </div>
        <div class="wcup-db-hero-body">
            <div class="wcup-db-hero-greet">خوش آمدی،</div>
            <div class="wcup-db-hero-name"><?php echo esc_html( $current_user->display_name ?: $current_user->user_login ); ?></div>
            <div class="wcup-db-hero-meta">
                <span>📅 عضو از <?php echo esc_html( wcup_fa_num( date_i18n( 'j F Y', strtotime( $current_user->user_registered ) ) ) ); ?></span>
                <?php if ( $opt( 'stat_member_days' ) ) : ?>
                    <span class="wcup-db-hero-dot">●</span>
                    <span>⏱️ <?php echo esc_html( wcup_fa_num( $stats['member_days'] ?? 0 ) ); ?> روز عضویت</span>
                <?php endif; ?>
            </div>
        </div>
        <a href="<?php echo esc_url( $edit_url ); ?>" class="wcup-db-hero-edit">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
            </svg>
            <span>ویرایش</span>
        </a>
    </div>
    <?php endif; ?>


    <!-- ═══════════════════════════════════════════════════════
         ★ ۳) پیشرفت پروفایل
    ═══════════════════════════════════════════════════════════ -->
    <?php if ( $opt( 'dash_progress' ) && ( $profile['percent'] ?? 0 ) < 100 ) : ?>
        <div class="wcup-profile-progress">
            <div class="wcup-pp-head">
                <div class="wcup-pp-title-wrap">
                    <div class="wcup-pp-icon" aria-hidden="true">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                    </div>
                    <div>
                        <div class="wcup-pp-title">تکمیل پروفایل</div>
                        <div class="wcup-pp-sub">
                            پروفایلت
                            <strong><?php echo esc_html( wcup_fa_num( $profile['percent'] ) ); ?>%</strong>
                            کامله —
                            <?php echo esc_html( wcup_fa_num( $profile['done'] ) ); ?>
                            از
                            <?php echo esc_html( wcup_fa_num( $profile['total'] ) ); ?>
                            مورد
                        </div>
                    </div>
                </div>
                <div class="wcup-pp-percent">
                    <?php echo esc_html( wcup_fa_num( $profile['percent'] ) ); ?>%
                </div>
            </div>

            <div class="wcup-pp-bar-wrap">
                <div class="wcup-pp-bar" style="width: <?php echo (int) $profile['percent']; ?>%;"></div>
            </div>

            <div class="wcup-pp-steps">
                <?php
                $missing = array_filter( $profile['steps'] ?? array(), function ( $s ) { return ! $s['done']; } );
                if ( ! empty( $missing ) ) :
                    foreach ( $missing as $step ) :
                ?>
                    <a href="<?php echo esc_url( $step['url'] ); ?>" class="wcup-pp-step">
                        <span class="wcup-pp-step-icon">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="12" y1="5" x2="12" y2="19"></line>
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                            </svg>
                        </span>
                        <span><?php echo esc_html( $step['label'] ); ?></span>
                    </a>
                <?php
                    endforeach;
                endif;
                ?>
            </div>
        </div>
    <?php endif; ?>


    <!-- ═══════════════════════════════════════════════════════
         ★ ۴) کارت‌های آماری — خرید
    ═══════════════════════════════════════════════════════════ -->
    <?php if ( $has_purchase_stats ) : ?>
    <div class="<?php echo esc_attr( $section_class ); ?>">
        <?php if ( $show_section_titles ) : ?>
            <h3 class="wcup-stats-section-title">💰 آمار خرید</h3>
        <?php endif; ?>

        <div class="wcup-db-stats">

            <?php if ( $opt( 'stat_total_spent' ) ) : ?>
            <div class="wcup-db-stat wcup-db-stat--primary">
                <div class="wcup-db-stat-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="12" y1="1" x2="12" y2="23"></line>
                        <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                    </svg>
                </div>
                <div class="wcup-db-stat-body">
                    <div class="wcup-db-stat-label">مبلغ کل خرید</div>
                    <div class="wcup-db-stat-value"><?php echo wp_kses_post( wc_price( $stats['total_spent'] ?? 0 ) ); ?></div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ( $opt( 'stat_total_orders' ) ) : ?>
            <div class="wcup-db-stat wcup-db-stat--blue">
                <div class="wcup-db-stat-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <path d="M16 10a4 4 0 0 1-8 0"></path>
                    </svg>
                </div>
                <div class="wcup-db-stat-body">
                    <div class="wcup-db-stat-label">تعداد کل سفارش‌ها</div>
                    <div class="wcup-db-stat-value"><?php echo esc_html( wcup_fa_num( $stats['total_orders'] ?? 0 ) ); ?></div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ( $opt( 'stat_avg_order' ) ) : ?>
            <div class="wcup-db-stat wcup-db-stat--purple">
                <div class="wcup-db-stat-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                    </svg>
                </div>
                <div class="wcup-db-stat-body">
                    <div class="wcup-db-stat-label">میانگین مبلغ سفارش</div>
                    <div class="wcup-db-stat-value"><?php echo wp_kses_post( wc_price( $stats['avg_order'] ?? 0 ) ); ?></div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ( $opt( 'stat_member_days' ) ) : ?>
            <div class="wcup-db-stat wcup-db-stat--red">
                <div class="wcup-db-stat-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="16" y1="2" x2="16" y2="6"></line>
                        <line x1="8" y1="2" x2="8" y2="6"></line>
                        <line x1="3" y1="10" x2="21" y2="10"></line>
                    </svg>
                </div>
                <div class="wcup-db-stat-body">
                    <div class="wcup-db-stat-label">روزهای عضویت</div>
                    <div class="wcup-db-stat-value"><?php echo esc_html( wcup_fa_num( number_format_i18n( $stats['member_days'] ?? 0 ) ) ); ?></div>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
    <?php endif; ?>


    <!-- ═══════════════════════════════════════════════════════
         ★ ۵) کارت‌های آماری — وضعیت
    ═══════════════════════════════════════════════════════════ -->
    <?php if ( $has_status_stats ) : ?>
    <div class="<?php echo esc_attr( $section_class ); ?>">
        <?php if ( $show_section_titles ) : ?>
            <h3 class="wcup-stats-section-title">📊 وضعیت سفارش‌ها</h3>
        <?php endif; ?>

        <div class="wcup-db-stats wcup-db-stats--2">

            <?php if ( $opt( 'stat_completed' ) ) : ?>
            <div class="wcup-db-stat wcup-db-stat--success">
                <div class="wcup-db-stat-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                </div>
                <div class="wcup-db-stat-body">
                    <div class="wcup-db-stat-label">سفارش‌های تکمیل‌شده</div>
                    <div class="wcup-db-stat-value"><?php echo esc_html( wcup_fa_num( $stats['completed_orders'] ?? 0 ) ); ?></div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ( $opt( 'stat_processing' ) ) : ?>
            <div class="wcup-db-stat wcup-db-stat--warning">
                <div class="wcup-db-stat-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12 6 12 12 16 14"></polyline>
                    </svg>
                </div>
                <div class="wcup-db-stat-body">
                    <div class="wcup-db-stat-label">در حال پردازش</div>
                    <div class="wcup-db-stat-value"><?php echo esc_html( wcup_fa_num( $stats['processing_orders'] ?? 0 ) ); ?></div>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
    <?php endif; ?>


    <!-- ═══════════════════════════════════════════════════════
         ★ ۶) کارت‌های آماری — فعالیت
    ═══════════════════════════════════════════════════════════ -->
    <?php if ( $has_activity_stats ) : ?>
    <div class="<?php echo esc_attr( $section_class ); ?>">
        <?php if ( $show_section_titles ) : ?>
            <h3 class="wcup-stats-section-title">⭐ فعالیت‌های من</h3>
        <?php endif; ?>

        <div class="wcup-db-stats <?php
            $count = (int) $opt( 'stat_wishlist' ) + (int) $opt( 'stat_comments' ) + (int) $opt( 'stat_downloads' );
            echo 'wcup-db-stats--' . min( $count, 3 );
        ?>">

            <?php if ( $opt( 'stat_wishlist' ) ) : ?>
            <div class="wcup-db-stat wcup-db-stat--pink">
                <div class="wcup-db-stat-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                    </svg>
                </div>
                <div class="wcup-db-stat-body">
                    <div class="wcup-db-stat-label">علاقه‌مندی‌ها</div>
                    <div class="wcup-db-stat-value"><?php echo esc_html( wcup_fa_num( $stats['wishlist_count'] ?? 0 ) ); ?></div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ( $opt( 'stat_comments' ) ) : ?>
            <div class="wcup-db-stat wcup-db-stat--green">
                <div class="wcup-db-stat-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
                    </svg>
                </div>
                <div class="wcup-db-stat-body">
                    <div class="wcup-db-stat-label">تعداد دیدگاه‌ها</div>
                    <div class="wcup-db-stat-value"><?php echo esc_html( wcup_fa_num( $stats['comment_count'] ?? 0 ) ); ?></div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ( $opt( 'stat_downloads' ) ) : ?>
            <div class="wcup-db-stat wcup-db-stat--cyan">
                <div class="wcup-db-stat-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="7 10 12 15 17 10"></polyline>
                        <line x1="12" y1="15" x2="12" y2="3"></line>
                    </svg>
                </div>
                <div class="wcup-db-stat-body">
                    <div class="wcup-db-stat-label">تعداد دانلودها</div>
                    <div class="wcup-db-stat-value"><?php echo esc_html( wcup_fa_num( $stats['download_count'] ?? 0 ) ); ?></div>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
    <?php endif; ?>


    <!-- ═══════════════════════════════════════════════════════
         ★ ۷) آخرین سفارش
    ═══════════════════════════════════════════════════════════ -->
    <?php
    $last_order = $stats['last_order'] ?? null;
    if ( $opt( 'stat_last_order' ) && $last_order instanceof WC_Order ) :
        $lo_status  = $last_order->get_status();
        $status_map = array(
            'pending'    => array( 'label' => 'در انتظار پرداخت', 'class' => 'pending' ),
            'processing' => array( 'label' => 'در حال انجام',     'class' => 'processing' ),
            'on-hold'    => array( 'label' => 'در انتظار بررسی',  'class' => 'on-hold' ),
            'completed'  => array( 'label' => 'تکمیل شده',        'class' => 'completed' ),
            'cancelled'  => array( 'label' => 'لغو شده',          'class' => 'cancelled' ),
            'refunded'   => array( 'label' => 'مسترد شده',        'class' => 'refunded' ),
            'failed'     => array( 'label' => 'ناموفق',           'class' => 'failed' ),
        );
        $badge  = $status_map[ $lo_status ] ?? array( 'label' => $lo_status, 'class' => 'pending' );
        $lo_date = $last_order->get_date_created();
    ?>
        <div class="<?php echo esc_attr( $section_class ); ?>">
            <?php if ( $show_section_titles ) : ?>
                <h3 class="wcup-stats-section-title">🧾 آخرین سفارش</h3>
            <?php endif; ?>

            <a href="<?php echo esc_url( $last_order->get_view_order_url() ); ?>" class="wcup-db-last-order">
                <div class="wcup-db-lo-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <path d="M16 10a4 4 0 0 1-8 0"></path>
                    </svg>
                </div>
                <div class="wcup-db-lo-body">
                    <div class="wcup-db-lo-head">
                        <span class="wcup-db-lo-number">
                            سفارش #<?php echo esc_html( wcup_fa_num( $last_order->get_order_number() ) ); ?>
                        </span>
                        <span class="wcup-ord-badge wcup-ord-badge--<?php echo esc_attr( $badge['class'] ); ?>">
                            <?php echo esc_html( $badge['label'] ); ?>
                        </span>
                    </div>
                    <div class="wcup-db-lo-meta">
                        <span>📅 <?php echo esc_html( $lo_date ? wcup_fa_num( date_i18n( 'j F Y', $lo_date->getTimestamp() ) ) : '—' ); ?></span>
                        <span class="wcup-db-lo-dot">●</span>
                        <span>📦 <?php echo esc_html( wcup_fa_num( $last_order->get_item_count() ) ); ?> آیتم</span>
                    </div>
                </div>
                <div class="wcup-db-lo-total">
                    <?php echo wp_kses_post( $last_order->get_formatted_order_total() ); ?>
                </div>
                <div class="wcup-db-lo-arrow">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="15 18 9 12 15 6"></polyline>
                    </svg>
                </div>
            </a>
        </div>
    <?php endif; ?>


    <!-- ═══════════════════════════════════════════════════════
         ★ ۸) لینک‌های سریع
    ═══════════════════════════════════════════════════════════ -->
    <?php if ( $opt( 'dash_quick_links' ) ) : ?>
    <div class="wcup-db-quick">
        <a href="<?php echo esc_url( $orders_url ); ?>" class="wcup-db-quick-card">
            <div class="wcup-db-quick-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                    <line x1="3" y1="6" x2="21" y2="6"></line>
                    <path d="M16 10a4 4 0 0 1-8 0"></path>
                </svg>
            </div>
            <div class="wcup-db-quick-body">
                <div class="wcup-db-quick-title">سفارش‌های من</div>
                <div class="wcup-db-quick-desc">مشاهده و پیگیری خریدها</div>
            </div>
        </a>

        <a href="<?php echo esc_url( $downloads_url ); ?>" class="wcup-db-quick-card">
            <div class="wcup-db-quick-icon">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="7 10 12 15 17 10"></polyline>
                    <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
            </div>
            <div class="wcup-db-quick-body">
                <div class="wcup-db-quick-title">دانلودها</div>
                <div class="wcup-db-quick-desc">فایل‌های خریداری‌شده</div>
            </div>
        </a>
    </div>
    <?php endif; ?>


    <!-- ═══════════════════════════════════════════════════════
         ★ ۹) آخرین سفارش‌ها
    ═══════════════════════════════════════════════════════════ -->
    <?php if ( ! empty( $recent_orders ) ) : ?>
        <div class="wcup-db-recent">
            <div class="wcup-db-recent-head">
                <h3 class="wcup-db-recent-title">آخرین سفارش‌ها</h3>
                <a href="<?php echo esc_url( $orders_url ); ?>" class="wcup-db-recent-more">
                    <span>مشاهده همه</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="15 18 9 12 15 6"></polyline>
                    </svg>
                </a>
            </div>

            <div class="wcup-db-recent-list">
                <?php foreach ( $recent_orders as $order ) :
                    if ( ! $order instanceof WC_Order ) continue;
                    $status = $order->get_status();
                    $status_map = array(
                        'pending'    => array( 'label' => 'در انتظار پرداخت', 'class' => 'pending' ),
                        'processing' => array( 'label' => 'در حال انجام',     'class' => 'processing' ),
                        'on-hold'    => array( 'label' => 'در انتظار بررسی',  'class' => 'on-hold' ),
                        'completed'  => array( 'label' => 'تکمیل شده',        'class' => 'completed' ),
                        'cancelled'  => array( 'label' => 'لغو شده',          'class' => 'cancelled' ),
                        'refunded'   => array( 'label' => 'مسترد شده',        'class' => 'refunded' ),
                        'failed'     => array( 'label' => 'ناموفق',           'class' => 'failed' ),
                    );
                    $badge = $status_map[ $status ] ?? array( 'label' => $status, 'class' => 'pending' );
                    $date  = $order->get_date_created();
                ?>
                    <a href="<?php echo esc_url( $order->get_view_order_url() ); ?>" class="wcup-db-recent-item">
                        <div class="wcup-db-recent-item-info">
                            <div class="wcup-db-recent-item-num">
                                سفارش #<?php echo esc_html( wcup_fa_num( $order->get_order_number() ) ); ?>
                            </div>
                            <div class="wcup-db-recent-item-date">
                                <?php echo esc_html( $date ? wcup_fa_num( date_i18n( 'j F Y', $date->getTimestamp() ) ) : '—' ); ?>
                            </div>
                        </div>
                        <span class="wcup-ord-badge wcup-ord-badge--<?php echo esc_attr( $badge['class'] ); ?>">
                            <?php echo esc_html( $badge['label'] ); ?>
                        </span>
                        <div class="wcup-db-recent-item-total">
                            <?php echo wp_kses_post( $order->get_formatted_order_total() ); ?>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

</div>