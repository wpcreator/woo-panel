<?php
/**
 * My Account > My Addresses (Custom Override)
 * ----------------------------------------------------------
 *  نمایش کارتی آدرس‌های پیش‌فرض (صورتحساب + ارسال)
 *
 * @version 3.0.0
 */

defined( 'ABSPATH' ) || exit;

$customer_id = get_current_user_id();

/* ★ گرفتن انواع آدرس */
if ( ! wc_ship_to_billing_address_only() && wc_shipping_enabled() ) {
    $get_addresses = apply_filters(
        'woocommerce_my_account_get_addresses',
        array(
            'billing'  => 'آدرس صورتحساب',
            'shipping' => 'آدرس ارسال',
        ),
        $customer_id
    );
} else {
    $get_addresses = apply_filters(
        'woocommerce_my_account_get_addresses',
        array(
            'billing' => 'آدرس صورتحساب',
        ),
        $customer_id
    );
}

/* ★ آیکون‌ها */
$address_icons = array(
    'billing'  => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>',
    'shipping' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>',
);
?>

<div class="wcup-addresses" dir="rtl">

    <!-- ═══ Header ═══ -->
    <div class="wcup-addr-header">
        <div class="wcup-addr-header-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                <circle cx="12" cy="10" r="3"></circle>
            </svg>
        </div>
        <div class="wcup-addr-header-body">
            <h2 class="wcup-addr-title">آدرس‌های من</h2>
            <p class="wcup-addr-sub">
                این آدرس‌ها به‌صورت پیش‌فرض در صفحهٔ تسویه‌حساب استفاده می‌شن.
            </p>
        </div>
    </div>

    <!-- ═══ Address Cards ═══ -->
    <div class="wcup-addr-grid">

        <?php foreach ( $get_addresses as $name => $address_title ) :

            $address     = wc_get_account_formatted_address( $name );
            $edit_url    = wc_get_endpoint_url( 'edit-address', $name );
            $icon        = isset( $address_icons[ $name ] ) ? $address_icons[ $name ] : $address_icons['billing'];
            $has_address = ! empty( trim( wp_strip_all_tags( (string) $address ) ) );
        ?>

            <div class="wcup-addr-card <?php echo $has_address ? 'has-address' : 'is-empty'; ?>">

                <!-- Head -->
                <div class="wcup-addr-card-head">
                    <div class="wcup-addr-card-icon" aria-hidden="true">
                        <?php echo $icon; // phpcs:ignore ?>
                    </div>
                    <h3 class="wcup-addr-card-title">
                        <?php echo esc_html( $address_title ); ?>
                    </h3>
                </div>

                <!-- Body -->
                <div class="wcup-addr-card-body">
                    <?php if ( $has_address ) : ?>
                        <address class="wcup-addr-card-address">
                            <?php echo wp_kses_post( $address ); ?>
                        </address>
                    <?php else : ?>
                        <div class="wcup-addr-card-empty">
                            <div class="wcup-addr-card-empty-icon">📍</div>
                            <div class="wcup-addr-card-empty-text">
                                هنوز این نوع آدرس رو ثبت نکردی.
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Footer -->
                <div class="wcup-addr-card-footer">
                    <a href="<?php echo esc_url( $edit_url ); ?>"
                       class="wcup-addr-card-btn">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.5"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                        </svg>
                        <span><?php echo $has_address ? 'ویرایش آدرس' : 'افزودن آدرس'; ?></span>
                    </a>
                </div>

            </div>

        <?php endforeach; ?>

    </div>

</div>