<?php
/**
 * My Account > Edit Account (Custom Override)
 * @version 3.0.1
 */

defined( 'ABSPATH' ) || exit;

$user_id = get_current_user_id();
$user    = get_userdata( $user_id );

/* ============================================================
 *  ★ عکس پروفایل فعلی
 * ============================================================ */
$avatar_id  = (int) get_user_meta( $user_id, 'wcup_avatar_id', true );
$avatar_url = $avatar_id
    ? wp_get_attachment_image_url( $avatar_id, 'thumbnail' )
    : wcup_get_default_avatar_url( 96 );

/* fallback اگه عکس پاک شده بود */
if ( ! $avatar_url ) {
    $avatar_url = wcup_get_default_avatar_url( 96 );
}

do_action( 'woocommerce_before_edit_account_form' );
?>

<div class="wcup-edit-account" dir="rtl">

    <!-- ═══ Tabs ═══ -->
    <div class="wcup-ea-tabs">
        <button type="button"
                class="wcup-ea-tab is-active"
                data-target="info">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2.2"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
            </svg>
            <span>ویرایش اطلاعات</span>
        </button>

        <button type="button"
                class="wcup-ea-tab"
                data-target="password">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2.2"
                 stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
            </svg>
            <span>تغییر رمز عبور</span>
        </button>
    </div>

    <!-- ═══ Form ═══ -->
    <form class="woocommerce-EditAccountForm edit-account"
          action=""
          method="post"
          enctype="multipart/form-data">

        <?php do_action( 'woocommerce_edit_account_form_start' ); ?>

        <!-- ═══════════════════════════════════════════════════
             ★ پنل ۱: ویرایش اطلاعات
        ═══════════════════════════════════════════════════════ -->
        <div class="wcup-ea-panel is-active" data-panel="info">

            <!-- بخش آواتار -->
            <div class="wcup-ea-avatar-section">
                <label for="wcup-avatar-input" class="wcup-ea-avatar-preview">
                    <img src="<?php echo esc_url( $avatar_url ); ?>"
                         alt="عکس پروفایل"
                         class="wcup-ea-avatar-img"
                         id="wcup-ea-avatar-preview">
                    <div class="wcup-ea-avatar-overlay">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.2"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
                            <circle cx="12" cy="13" r="4"></circle>
                        </svg>
                    </div>
                </label>

                <div class="wcup-ea-avatar-body">
                    <div class="wcup-ea-avatar-title">عکس پروفایل</div>
                    <div class="wcup-ea-avatar-desc">
                        یک تصویر مربعی (حداقل ۲۰۰×۲۰۰ پیکسل) انتخاب کن.
                        فرمت‌های مجاز: JPG، PNG، WebP. حداکثر ۲ مگابایت.
                    </div>

                    <div class="wcup-ea-avatar-actions">
                        <label for="wcup-avatar-input" class="wcup-ea-avatar-btn">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                 stroke="currentColor" stroke-width="2.5"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                <polyline points="17 8 12 3 7 8"></polyline>
                                <line x1="12" y1="3" x2="12" y2="15"></line>
                            </svg>
                            <span>انتخاب تصویر</span>
                        </label>

                        <?php if ( $avatar_id ) : ?>
                            <button type="button"
                                    class="wcup-ea-avatar-remove"
                                    id="wcup-ea-avatar-remove">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                     stroke="currentColor" stroke-width="2.5"
                                     stroke-linecap="round" stroke-linejoin="round">
                                    <polyline points="3 6 5 6 21 6"></polyline>
                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                </svg>
                                <span>حذف تصویر</span>
                            </button>
                        <?php endif; ?>
                    </div>

                    <input type="file"
                           name="wcup_avatar"
                           id="wcup-avatar-input"
                           accept="image/jpeg,image/png,image/webp,image/gif"
                           class="wcup-ea-avatar-input">

                </div>
            </div>

            <!-- نام و نام خانوادگی -->
            <div class="wcup-ea-row">
                <div class="wcup-ea-field">
                    <label for="account_first_name" class="wcup-ea-label">
                        نام <span class="wcup-ea-required">*</span>
                    </label>
                    <input type="text"
                           class="wcup-ea-input woocommerce-Input woocommerce-Input--text"
                           name="account_first_name"
                           id="account_first_name"
                           autocomplete="given-name"
                           value="<?php echo esc_attr( $user->first_name ); ?>">
                </div>

                <div class="wcup-ea-field">
                    <label for="account_last_name" class="wcup-ea-label">
                        نام خانوادگی <span class="wcup-ea-required">*</span>
                    </label>
                    <input type="text"
                           class="wcup-ea-input woocommerce-Input woocommerce-Input--text"
                           name="account_last_name"
                           id="account_last_name"
                           autocomplete="family-name"
                           value="<?php echo esc_attr( $user->last_name ); ?>">
                </div>
            </div>

            <!-- نام نمایشی -->
            <div class="wcup-ea-field">
                <label for="account_display_name" class="wcup-ea-label">
                    نام نمایشی <span class="wcup-ea-required">*</span>
                </label>
                <input type="text"
                       class="wcup-ea-input woocommerce-Input woocommerce-Input--text"
                       name="account_display_name"
                       id="account_display_name"
                       value="<?php echo esc_attr( $user->display_name ); ?>">
                <p class="wcup-ea-hint">
                    اسم شما به این صورت در حساب کاربری و نظرات دیده خواهد شد.
                </p>
            </div>

            <!-- ایمیل -->
            <div class="wcup-ea-field">
                <label for="account_email" class="wcup-ea-label">
                    آدرس ایمیل <span class="wcup-ea-required">*</span>
                </label>
                <input type="email"
                       class="wcup-ea-input woocommerce-Input woocommerce-Input--email"
                       name="account_email"
                       id="account_email"
                       autocomplete="email"
                       value="<?php echo esc_attr( $user->user_email ); ?>">
            </div>

        </div>

        <!-- ═══════════════════════════════════════════════════
             ★ پنل ۲: تغییر رمز عبور
        ═══════════════════════════════════════════════════════ -->
        <div class="wcup-ea-panel" data-panel="password">

            <div class="wcup-ea-field">
                <label for="password_current" class="wcup-ea-label">
                    رمز عبور فعلی (در صورت تغییر)
                </label>
                <input type="password"
                       class="wcup-ea-input woocommerce-Input woocommerce-Input--password"
                       name="password_current"
                       id="password_current"
                       autocomplete="current-password">
            </div>

            <div class="wcup-ea-field">
                <label for="password_1" class="wcup-ea-label">
                    رمز عبور جدید (در صورت تغییر)
                </label>
                <input type="password"
                       class="wcup-ea-input woocommerce-Input woocommerce-Input--password"
                       name="password_1"
                       id="password_1"
                       autocomplete="new-password">
            </div>

            <div class="wcup-ea-field">
                <label for="password_2" class="wcup-ea-label">
                    تکرار رمز عبور جدید
                </label>
                <input type="password"
                       class="wcup-ea-input woocommerce-Input woocommerce-Input--password"
                       name="password_2"
                       id="password_2"
                       autocomplete="new-password">
            </div>

            <div class="wcup-ea-hint wcup-ea-hint--block">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.2"
                     stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="16" x2="12" y2="12"></line>
                    <line x1="12" y1="8" x2="12.01" y2="8"></line>
                </svg>
                <span>اگه نمی‌خوای رمز عبورت رو عوض کنی، این بخش رو خالی بذار.</span>
            </div>

        </div>

        <?php do_action( 'woocommerce_edit_account_form' ); ?>

        <!-- ═══ Actions ═══ -->
        <div class="wcup-ea-actions">
            <?php wp_nonce_field( 'save_account_details', 'save-account-details-nonce' ); ?>

            <button type="submit"
                    class="wcup-ea-submit"
                    name="save_account_details"
                    value="<?php esc_attr_e( 'Save changes', 'woocommerce' ); ?>">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                    <polyline points="17 21 17 13 7 13 7 21"></polyline>
                    <polyline points="7 3 7 8 15 8"></polyline>
                </svg>
                <span>ذخیره تغییرات</span>
            </button>

            <input type="hidden" name="action" value="save_account_details" />
        </div>

        <?php do_action( 'woocommerce_edit_account_form_end' ); ?>
    </form>
</div>

<script>
/* ═══ تب‌ها ═══ */
(function () {
    var tabs   = document.querySelectorAll('.wcup-ea-tab');
    var panels = document.querySelectorAll('.wcup-ea-panel');
    if (!tabs.length) return;

    tabs.forEach(function (tab) {
        tab.addEventListener('click', function () {
            var target = tab.getAttribute('data-target');

            tabs.forEach(function (t) { t.classList.remove('is-active'); });
            panels.forEach(function (p) { p.classList.remove('is-active'); });

            tab.classList.add('is-active');
            var panel = document.querySelector('.wcup-ea-panel[data-panel="' + target + '"]');
            if (panel) panel.classList.add('is-active');
        });
    });
})();

/* ═══ پیش‌نمایش آواتار ═══ */
(function () {
    var input   = document.getElementById('wcup-avatar-input');
    var preview = document.getElementById('wcup-ea-avatar-preview');
    if (!input || !preview) return;

    input.addEventListener('change', function () {
        var file = input.files && input.files[0];
        if (!file) return;

        /* چک نوع فایل */
        if (!file.type.match(/^image\//)) {
            alert('فقط فایل تصویری مجاز است.');
            input.value = '';
            return;
        }

        /* چک حجم (۲ مگابایت) */
        if (file.size > 2 * 1024 * 1024) {
            alert('حجم تصویر نباید بیشتر از ۲ مگابایت باشد.');
            input.value = '';
            return;
        }

        var reader = new FileReader();
        reader.onload = function (e) {
            preview.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
})();

/* ═══ حذف آواتار (AJAX) ═══ */
(function () {
    var removeBtn = document.getElementById('wcup-ea-avatar-remove');
    var preview   = document.getElementById('wcup-ea-avatar-preview');

    if (!removeBtn || !preview) return;

    removeBtn.addEventListener('click', function () {

        if (!confirm('از حذف عکس پروفایل مطمئنی؟')) return;

        var data = window.wcupAvatarData;
        if (!data || !data.ajaxUrl) return;

        /* غیرفعال کردن دکمه هنگام درخواست */
        removeBtn.disabled = true;
        removeBtn.classList.add('is-loading');

        var xhr = new XMLHttpRequest();
        xhr.open('POST', data.ajaxUrl, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');

        xhr.onload = function () {
            removeBtn.disabled = false;
            removeBtn.classList.remove('is-loading');

            if (xhr.status !== 200) {
                alert('خطای شبکه. دوباره امتحان کن.');
                return;
            }

            var res;
            try {
                res = JSON.parse(xhr.responseText);
            } catch (e) {
                alert('پاسخ نامعتبر از سرور.');
                return;
            }

            if (!res || !res.success) {
                alert((res && res.data && res.data.message) || 'حذف انجام نشد.');
                return;
            }

            /* آواتار پیش‌فرض */
            if (res.data.default_url) {
                preview.src = res.data.default_url;
            }

            /* پنهان کردن دکمهٔ حذف */
            removeBtn.style.display = 'none';

            /* نمایش پیام موفقیت */
            var notice = document.createElement('div');
            notice.className = 'wcup-ea-notice wcup-ea-notice--success';
            notice.textContent = res.data.message || 'عکس پروفایل حذف شد.';
            preview.closest('.wcup-ea-avatar-section').appendChild(notice);

            /* حذف پیام بعد از ۳ ثانیه */
            setTimeout(function () {
                if (notice.parentNode) notice.parentNode.removeChild(notice);
            }, 3000);
        };

        xhr.onerror = function () {
            removeBtn.disabled = false;
            removeBtn.classList.remove('is-loading');
            alert('خطای شبکه. دوباره امتحان کن.');
        };

        var body = 'action=wcup_delete_avatar'
                 + '&nonce=' + encodeURIComponent(data.nonce);

        xhr.send(body);
    });
})();
</script>

<?php do_action( 'woocommerce_after_edit_account_form' ); ?>