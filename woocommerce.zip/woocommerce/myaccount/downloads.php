<?php
/**
 * My Account > Downloads (Custom Override)
 * طراحی کارتی + حذف فایل‌های تکراری + لینک محصول + نسخه از متا
 *
 * @version 3.0.0
 */

defined( 'ABSPATH' ) || exit;

$user_id   = get_current_user_id();
$downloads = wc_get_customer_available_downloads( $user_id );

/* ============================================================
 *  ★ حذف تکراری‌ها بر اساس نام فایل
 * ============================================================ */
$seen   = [];
$unique = [];

foreach ( (array) $downloads as $dl ) {
    $key = '';

    if ( ! empty( $dl['download_name'] ) ) {
        $key = strtolower( trim( $dl['download_name'] ) );
    }

    if ( $key === '' && ! empty( $dl['file'] ) ) {
        $key = is_array( $dl['file'] )
            ? ( $dl['file']['file'] ?? '' )
            : (string) $dl['file'];
    }

    if ( $key === '' ) {
        $key = ( $dl['product_id'] ?? 0 ) . '|' . ( $dl['download_id'] ?? 0 );
    }

    if ( $key === '' ) $key = md5( serialize( $dl ) );

    if ( isset( $seen[ $key ] ) ) continue;
    $seen[ $key ] = true;
    $unique[] = $dl;
}

$downloads = $unique;
?>

<div class="wcup-downloads-page" dir="rtl">

    <!-- ═══ Notice ═══ -->
    <div class="wcup-dl-page-notice">
        <div class="wcup-dl-page-notice-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="16" x2="12" y2="12"></line>
                <line x1="12" y1="8" x2="12.01" y2="8"></line>
            </svg>
        </div>
        <div class="wcup-dl-page-notice-text">
            <strong>راهنما</strong>
            <p>فایل‌های خریداری‌شده شما اینجاست. برای دریافت آخرین نسخه، روی دکمه «دانلود» بزنید.</p>
        </div>
    </div>

    <?php if ( empty( $downloads ) ) : ?>

        <!-- ═══ Empty ═══ -->
        <div class="wcup-dl-page-empty">
            <div class="wcup-dl-page-empty-icon">📦</div>
            <div class="wcup-dl-page-empty-title">هنوز فایلی برای دانلود ندارید</div>
            <div class="wcup-dl-page-empty-desc">
                پس از تکمیل سفارش، فایل‌های شما اینجا نمایش داده می‌شوند.
            </div>
        </div>

    <?php else : ?>

        <!-- ═══ Downloads List ═══ -->
        <div class="wcup-dl-page-list">
            <?php foreach ( $downloads as $dl ) :

                $product_id = (int) ( $dl['product_id'] ?? 0 );
                $product    = $product_id ? wc_get_product( $product_id ) : null;

                /* ---------- ★ نام محصول ---------- */
                $product_name = '';
                if ( $product ) {
                    $product_name = $product->get_name();
                } elseif ( ! empty( $dl['product_name'] ) ) {
                    $product_name = $dl['product_name'];
                }
                if ( $product_name === '' ) {
                    $product_name = 'محصول #' . $product_id;
                }

                /* ---------- ★ لینک محصول (بدون پارامترهای اتریبیوت) ---------- */
                $product_url = '';
                if ( $product ) {
                    // اگه variation باشه، لینک والدش رو بگیر
                    $link_id = $product->get_parent_id() ? $product->get_parent_id() : $product_id;
                    $product_url = get_permalink( $link_id );

                    // اگه لینک پارامتر داشت (مثل ?attribute_pa_...)، حذفش کن
                    if ( $product_url && strpos( $product_url, '?' ) !== false ) {
                        $product_url = strtok( $product_url, '?' );
                    }
                }

                /* ---------- تصویر ---------- */
                $img = '';
                if ( $product ) {
                    $img = wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' );
                }
                if ( ! $img ) $img = wc_placeholder_img_src();

                /* ---------- ★ نسخه: خواندن از فیلدهای مختلف محصول ---------- */
                $version = '';

                /* کی‌های ACF (اگه اسم فیلدت فرق داره اینجا اضافه کن) */
                $acf_keys = array( 'download_version', 'version', 'product_version' );

                /* متا کی‌های معمول ووکامرس/پلاگین‌ها */
                $meta_keys = array(
                    '_wcup_download_version',
                    '_download_version',
                    '_wc_download_version',
                    '_product_version',
                    'download_version',
                    '_version',
                    'version',
                );

                /* اگه محصول variation باشه، والدش هم چک بشه */
                $target_ids = array( $product_id );
                if ( $product && $product->get_parent_id() ) {
                    $target_ids[] = $product->get_parent_id();
                }

                /* 1) اول ACF */
                if ( function_exists( 'get_field' ) ) {
                    foreach ( $target_ids as $pid ) {
                        foreach ( $acf_keys as $ak ) {
                            $v = get_field( $ak, $pid );
                            if ( is_string( $v ) && trim( $v ) !== '' ) {
                                $version = trim( $v );
                                break 2;
                            }
                            if ( is_numeric( $v ) ) {
                                $version = (string) $v;
                                break 2;
                            }
                        }
                    }
                }

                /* 2) بعد متا کی‌های ووکامرس */
                if ( $version === '' ) {
                    foreach ( $target_ids as $pid ) {
                        foreach ( $meta_keys as $mk ) {
                            $v = get_post_meta( $pid, $mk, true );
                            if ( is_array( $v ) ) {
                                $v = reset( $v );
                            }
                            if ( is_string( $v ) && trim( $v ) !== '' ) {
                                $version = trim( $v );
                                break 2;
                            }
                            if ( is_numeric( $v ) && $v != 0 ) {
                                $version = (string) $v;
                                break 2;
                            }
                        }
                    }
                }

                /* 3) در نهایت از فایل‌های دانلودی خود ووکامرس */
                if ( $version === '' && $product ) {
                    $prod_files = $product->get_downloads();
                    if ( ! empty( $prod_files ) ) {
                        foreach ( $prod_files as $pf ) {
                            if ( method_exists( $pf, 'get_version' ) ) {
                                $v = $pf->get_version();
                                if ( $v ) { $version = (string) $v; break; }
                            }
                            $data = method_exists( $pf, 'get_data' ) ? $pf->get_data() : array();
                            if ( ! empty( $data['version'] ) ) {
                                $version = (string) $data['version'];
                                break;
                            }
                        }
                    }
                }

                /* ---------- انقضا ---------- */
                $expires = $dl['access_expires'] ?? '';
                $expires_text = $expires
                    ? date_i18n( 'Y/m/d', strtotime( $expires ) )
                    : 'هرگز';

                /* ---------- باقی‌مانده ---------- */
                $remaining = $dl['remaining'] ?? '';
                $remaining_text = ( $remaining === '' || $remaining === null )
                    ? 'بی‌نهایت'
                    : (string) $remaining;

                $download_url = $dl['download_url'] ?? '#';
            ?>

            <div class="wcup-dl-page-card">

                <!-- Head: تصویر + نام محصول (هر دو لینک به صفحه محصول) -->
                <div class="wcup-dl-page-head">
                    <?php if ( $product_url ) : ?>
                        <a href="<?php echo esc_url( $product_url ); ?>"
                           class="wcup-dl-page-img-link">
                            <img src="<?php echo esc_url( $img ); ?>"
                                 alt="<?php echo esc_attr( $product_name ); ?>"
                                 class="wcup-dl-page-img" loading="lazy">
                        </a>
                    <?php else : ?>
                        <img src="<?php echo esc_url( $img ); ?>"
                             alt="<?php echo esc_attr( $product_name ); ?>"
                             class="wcup-dl-page-img" loading="lazy">
                    <?php endif; ?>

                    <div class="wcup-dl-page-title">
                        <?php if ( $product_url ) : ?>
                            <a href="<?php echo esc_url( $product_url ); ?>"
                               class="wcup-dl-page-title-link">
                                <?php echo esc_html( $product_name ); ?>
                            </a>
                        <?php else : ?>
                            <?php echo esc_html( $product_name ); ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Meta rows -->
                <div class="wcup-dl-page-meta">
                    <div class="wcup-dl-page-meta-row">
                        <span class="wcup-dl-page-meta-label">دانلودهای باقی‌مانده</span>
                        <span class="wcup-dl-page-meta-value"><?php echo esc_html( $remaining_text ); ?></span>
                    </div>
                    <div class="wcup-dl-page-meta-row">
                        <span class="wcup-dl-page-meta-label">انقضا</span>
                        <span class="wcup-dl-page-meta-value"><?php echo esc_html( $expires_text ); ?></span>
                    </div>
                </div>

                <!-- File row: نسخه + دکمه دانلود -->
                <div class="wcup-dl-page-file">

                    <div class="wcup-dl-page-file-info">
                        <?php if ( $version !== '' ) : ?>
                            <span class="wcup-dl-page-file-version">
                                نسخه <?php echo esc_html( $version ); ?>
                            </span>
                        <?php else : ?>
                            <span class="wcup-dl-page-file-version is-empty">
                                آخرین نسخه
                            </span>
                        <?php endif; ?>
                    </div>

                    <a href="<?php echo esc_url( $download_url ); ?>"
                       class="wcup-dl-page-btn"
                       download>
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.5"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                            <polyline points="7 10 12 15 17 10"></polyline>
                            <line x1="12" y1="15" x2="12" y2="3"></line>
                        </svg>
                        <span>دانلود</span>
                    </a>

                </div>

            </div>

            <?php endforeach; ?>
        </div>

    <?php endif; ?>

</div>