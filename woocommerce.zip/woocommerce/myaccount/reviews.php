<?php
/**
 * My Account > Reviews (Custom)
 * ----------------------------------------------------------
 *  نمایش نظرات کاربر روی محصولات + پاسخ‌های مدیر
 *
 * @version 3.0.0
 */

defined( 'ABSPATH' ) || exit;

$user_id = get_current_user_id();

/* ============================================================
 *  ★ صفحه‌بندی
 * ============================================================ */
$current_page = max( 1, get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1 );
$per_page     = 10;
$offset       = ( $current_page - 1 ) * $per_page;

/* ============================================================
 *  ★ گرفتن نظرات کاربر
 * ============================================================ */
$comments_query = new WP_Comment_Query( array(
    'user_id'   => $user_id,
    'post_type' => 'product',
    'status'    => 'approve',
    'number'    => $per_page,
    'offset'    => $offset,
    'orderby'   => 'comment_date_gmt',
    'order'     => 'DESC',
) );

$comments = $comments_query->comments;

/* ★ تعداد کل */
$total_comments = (int) get_comments( array(
    'user_id'   => $user_id,
    'post_type' => 'product',
    'status'    => 'approve',
    'count'     => true,
) );

$max_pages = (int) ceil( $total_comments / $per_page );

/* ★ آواتار کاربر */
$custom_avatar_id  = (int) get_user_meta( $user_id, 'wcup_avatar_id', true );
$custom_avatar_url = $custom_avatar_id
    ? wp_get_attachment_image_url( $custom_avatar_id, 'thumbnail' )
    : wcup_get_default_avatar_url( 56 );

$display_name = wp_get_current_user()->display_name ?: wp_get_current_user()->user_login;
?>

<div class="wcup-reviews" dir="rtl">

    <!-- ═══ Header Card ═══ -->
    <div class="wcup-rv-header">
        <div class="wcup-rv-header-icon" aria-hidden="true">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
            </svg>
        </div>
        <div class="wcup-rv-header-body">
            <h2 class="wcup-rv-title">نظرات شما</h2>
            <p class="wcup-rv-sub">
                <?php if ( $total_comments > 0 ) : ?>
                    دیدگاه‌های تاییدشده‌ای که در سایت ثبت کرده‌اید
                    (<?php echo esc_html( wcup_fa_num( $total_comments ) ); ?> نظر).
                <?php else : ?>
                    دیدگاه‌های تاییدشده‌ای که در سایت ثبت کرده‌اید.
                <?php endif; ?>
            </p>
        </div>
    </div>

    <?php if ( empty( $comments ) ) : ?>

        <!-- ═══ Empty ═══ -->
        <div class="wcup-rv-empty">
            <div class="wcup-rv-empty-icon">💬</div>
            <div class="wcup-rv-empty-title">هنوز نظری ثبت نکردی</div>
            <div class="wcup-rv-empty-desc">
                بعد از خرید محصولات، می‌تونی تجربه‌ات رو با دیگران به اشتراک بذاری.
            </div>
        </div>

    <?php else : ?>

        <!-- ═══ Reviews List ═══ -->
        <div class="wcup-rv-list">
            <?php foreach ( $comments as $comment ) :

                $comment_date = $comment->comment_date;
                $comment_ts   = strtotime( $comment_date );
                $date_str     = date_i18n( 'j F Y', $comment_ts );

                $product_id   = (int) $comment->comment_post_ID;
                $product      = $product_id ? wc_get_product( $product_id ) : null;
                $product_name = $product ? $product->get_name() : '';
                $product_url  = $product ? get_permalink( $product_id ) : '';

                /* ★ پیدا کردن پاسخ‌های مدیر (child comments) */
                $replies = get_comments( array(
                    'parent' => $comment->comment_ID,
                    'status' => 'approve',
                    'order'  => 'ASC',
                ) );
            ?>

                <div class="wcup-rv-card">

                    <!-- ★ Head: نویسنده + تاریخ -->
                    <div class="wcup-rv-card-head">

                        <div class="wcup-rv-author">
                            <div class="wcup-rv-avatar">
                                    <img src="<?php echo esc_url( $custom_avatar_url ); ?>"
                                         alt="<?php echo esc_attr( $display_name ); ?>"
                                         class="wcup-rv-avatar-img">
                            </div>

                            <div class="wcup-rv-author-info">
                                <div class="wcup-rv-author-name">
                                    <?php echo esc_html( $display_name ); ?>
                                </div>
                                <?php if ( $product_name ) : ?>
                                    <a href="<?php echo esc_url( $product_url ); ?>"
                                       class="wcup-rv-product">
                                        در <?php echo esc_html( $product_name ); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="wcup-rv-date">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                 stroke="currentColor" stroke-width="2.2"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg>
                            <span><?php echo esc_html( $date_str ); ?></span>
                        </div>

                    </div>

                    <!-- ★ متن نظر -->
                    <div class="wcup-rv-content">
                        <?php echo wp_kses_post( wpautop( $comment->comment_content ) ); ?>
                    </div>

                    <!-- ★ پاسخ‌های مدیر -->
                    <?php if ( ! empty( $replies ) ) : ?>
                        <div class="wcup-rv-replies">
                            <?php foreach ( $replies as $reply ) :
                                $reply_date = date_i18n( 'j F Y', strtotime( $reply->comment_date ) );
                                $reply_author = $reply->comment_author ?: 'مدیر سایت';
                            ?>
                                <div class="wcup-rv-reply">
                                    <div class="wcup-rv-reply-head">
                                        <div class="wcup-rv-reply-author">
                                            <span class="wcup-rv-reply-badge">پاسخ</span>
                                            <strong><?php echo esc_html( $reply_author ); ?></strong>
                                        </div>
                                        <div class="wcup-rv-reply-date">
                                            <?php echo esc_html( $reply_date ); ?>
                                        </div>
                                    </div>
                                    <div class="wcup-rv-reply-content">
                                        <?php echo wp_kses_post( wpautop( $reply->comment_content ) ); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                </div>

            <?php endforeach; ?>
        </div>

        <!-- ═══ Pagination ═══ -->
        <?php if ( $max_pages > 1 ) : ?>
            <div class="wcup-rv-pagination">
                <?php
                $base_url = wc_get_endpoint_url( 'reviews', '', wc_get_page_permalink( 'myaccount' ) );
                $base_url = trailingslashit( $base_url );
                ?>

                <?php if ( $current_page > 1 ) :
                    $prev_url = ( $current_page - 1 === 1 )
                        ? untrailingslashit( $base_url )
                        : $base_url . 'page/' . ( $current_page - 1 ) . '/';
                ?>
                    <a href="<?php echo esc_url( $prev_url ); ?>" class="wcup-rv-page-btn">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.5"
                             stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="9 18 15 12 9 6"></polyline>
                        </svg>
                        <span>قبلی</span>
                    </a>
                <?php endif; ?>

                <div class="wcup-rv-page-numbers">
                    <?php for ( $i = 1; $i <= $max_pages; $i++ ) :
                        $page_url = ( $i === 1 )
                            ? untrailingslashit( $base_url )
                            : $base_url . 'page/' . $i . '/';
                        $is_cur   = ( $i === $current_page );
                    ?>
                        <a href="<?php echo esc_url( $page_url ); ?>"
                           class="wcup-rv-page-num <?php echo $is_cur ? 'is-active' : ''; ?>">
                            <?php echo esc_html( wcup_fa_num( $i ) ); ?>
                        </a>
                    <?php endfor; ?>
                </div>

                <?php if ( $current_page < $max_pages ) :
                    $next_url = $base_url . 'page/' . ( $current_page + 1 ) . '/';
                ?>
                    <a href="<?php echo esc_url( $next_url ); ?>" class="wcup-rv-page-btn">
                        <span>بعدی</span>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.5"
                             stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="15 18 9 12 15 6"></polyline>
                        </svg>
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

    <?php endif; ?>

</div>