<?php
/**
 * My Account — Navigation (Custom Sidebar, Fully Dynamic)
 * ----------------------------------------------------------
 *  - منو کامل از ووکامرس خونده میشه
 *  - آیکون‌ها فقط برای endpointهای شناخته‌شده مپ میشن
 *  - endpointهای ناشناخته → آیکون پیش‌فرض
 *  - URL و کلاس is-active خودکار محاسبه میشن
 *  - آواتار سفارشی کاربر نمایش داده میشه
 *  - Badge اعلان‌ها به صورت جدا رندر میشه
 *
 * @version 4.0.0
 */

defined( 'ABSPATH' ) || exit;

/* اطلاعات کاربر */
$current_user = wp_get_current_user();
$display_name = $current_user->display_name ?: $current_user->user_login;

/* منو از ووکامرس */
$items = wc_get_account_menu_items();

/* آدرس پایه */
$my_account_url = wc_get_page_permalink( 'myaccount' );

/* ============================================================
 *  مسیر فعلی
 * ============================================================ */
$current_path = '';
if ( isset( $_SERVER['REQUEST_URI'] ) ) {
    $current_path = strtok( $_SERVER['REQUEST_URI'], '?' );
}
$current_path = trailingslashit( $current_path );

/* ============================================================
 *  آواتار کاربر
 * ============================================================ */
$custom_avatar_id  = (int) get_user_meta( $current_user->ID, 'wcup_avatar_id', true );
$custom_avatar_url = $custom_avatar_id
    ? wp_get_attachment_image_url( $custom_avatar_id, 'thumbnail' )
    : wcup_get_default_avatar_url( 96 );

/* ============================================================
 *  شمارش اعلان‌های نخوانده
 * ============================================================ */
$unread_notifications = 0;
if ( class_exists( 'wcup_notifications' ) ) {
    $unread_notifications = (int) wcup_notifications::count( $current_user->ID, true );
}

/* ============================================================
 *  نقشهٔ آیکون‌ها
 * ============================================================ */
$icons = array(

    'dashboard' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"></rect><rect x="14" y="3" width="7" height="7" rx="1.5"></rect><rect x="14" y="14" width="7" height="7" rx="1.5"></rect><rect x="3" y="14" width="7" height="7" rx="1.5"></rect></svg>',

    'orders' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>',

    'downloads' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>',

    'licenses' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>',

    'my-licenses' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>',

    'edit-account' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>',

    'edit-address' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>',

    'payment-methods' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>',

    'customer-logout' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>',

    'subscriptions' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>',

    'wishlist' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>',

    'points' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>',

    'coupons' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>',

    'reviews' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>',

    'track-order' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>',

    'notifications' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>',
);

/* آیکون پیش‌فرض */
$icon_default = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>';
?>

<div class="wcup-nav">

    <!-- ═══ کارت کاربر ═══ -->
    <div class="wcup-nav-user">
        <div class="wcup-nav-user-avatar">
            <img src="<?php echo esc_url( $custom_avatar_url ); ?>"
                 alt="<?php echo esc_attr( $display_name ); ?>"
                 class="wcup-nav-avatar-img"
                 width="52" height="52"
                 loading="lazy">
        </div>
        <div class="wcup-nav-user-text">
            <strong class="wcup-nav-user-name"><?php echo esc_html( $display_name ); ?></strong>
            <span class="wcup-nav-user-greet">خوش آمدید</span>
        </div>
    </div>

    <!-- ═══ منوی ناوبری ═══ -->
    <nav class="wcup-nav-menu" aria-label="منوی حساب کاربری">
        <?php foreach ( $items as $endpoint => $label ) :

            /* ---------- ★ پاک‌سازی label از badge (اگه از add_badge_to_menu اومده) ---------- */
            $clean_label = $label;

            if ( strpos( $label, '<span' ) !== false ) {
                $clean_label = trim( preg_replace( '/<span[^>]*>.*?<\/span>/i', '', $label ) );
            }

            /* ---------- ★ ساخت URL ---------- */
            if ( 'dashboard' === $endpoint ) {
                $url = $my_account_url;
            } else {
                $url = wc_get_endpoint_url( $endpoint, '', $my_account_url );
            }

            /* ---------- ★ تشخیص فعال بودن ---------- */
            $link_path = wp_parse_url( $url, PHP_URL_PATH );
            $link_path = trailingslashit( $link_path );

            $is_active = ( $current_path === $link_path );

            /* ---------- ★ آیکون ---------- */
            $icon = isset( $icons[ $endpoint ] ) ? $icons[ $endpoint ] : $icon_default;

            /* ---------- ★ کلاس‌ها ---------- */
            $link_classes = 'wcup-nav-item';
            if ( $is_active ) {
                $link_classes .= ' is-active';
            }

            $aria_current = $is_active ? ' aria-current="page"' : '';
        ?>

            <a href="<?php echo esc_url( $url ); ?>"
               class="<?php echo esc_attr( $link_classes ); ?>"
               <?php echo $aria_current; // phpcs:ignore ?>>

                <span class="wcup-nav-item-icon" aria-hidden="true">
                    <?php echo $icon; // phpcs:ignore -- SVG مجاز ?>
                </span>

                <span class="wcup-nav-item-label">
                    <?php echo esc_html( $clean_label ); ?>
                </span>

                <?php if ( 'notifications' === $endpoint && $unread_notifications > 0 ) : ?>
                    <span class="wcup-nav-badge">
                        <?php echo esc_html( wcup_helpers::fa_num( $unread_notifications ) ); ?>
                    </span>
                <?php endif; ?>

                <span class="wcup-nav-item-arrow" aria-hidden="true">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2.5"
                         stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="15 18 9 12 15 6"></polyline>
                    </svg>
                </span>

            </a>

        <?php endforeach; ?>
    </nav>

</div>