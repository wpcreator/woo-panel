<?php
/**
 * My Account > Track Order
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

$user_id  = get_current_user_id();
$search   = isset( $_GET['track'] ) ? sanitize_text_field( wp_unslash( $_GET['track'] ) ) : '';
$has_search = $search !== '';

/* ═══ جستجوی سفارشات ═══ */
$orders = array();

if ( $user_id && function_exists( 'wcup_search_user_orders' ) ) {

    if ( $has_search ) {
        $orders = wcup_search_user_orders( $user_id, $search );
    } else {
        /* اگه جستجو خالی، آخرین ۵ سفارش */
        $orders = wc_get_orders( array(
            'customer' => $user_id,
            'limit'    => 5,
            'orderby'  => 'date',
            'order'    => 'DESC',
            'status'   => 'any',
        ) );
    }
}

/* ═══ لینک تمیز کردن جستجو ═══ */
$track_url = wc_get_endpoint_url( 'track-order', '', wc_get_page_permalink( 'myaccount' ) );
?>

<div class="wcup-track-order" dir="rtl">

    <!-- ═══════════════════════════════════════════════════════
         ★ Header
    ═══════════════════════════════════════════════════════════ -->
    <div class="wcup-to-header">
        <div class="wcup-to-header-icon" aria-hidden="true">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="1" y="3" width="15" height="13"></rect>
                <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                <circle cx="5.5" cy="18.5" r="2.5"></circle>
                <circle cx="18.5" cy="18.5" r="2.5"></circle>
            </svg>
        </div>
        <div class="wcup-to-header-body">
            <h2 class="wcup-to-title">پیگیری سفارش</h2>
            <p class="wcup-to-sub">
                با شماره سفارش، ایمیل یا شماره تماس، سفارشات خودت رو پیگیری کن.
            </p>
        </div>
    </div>


    <!-- ═══════════════════════════════════════════════════════
         ★ Search Form
    ═══════════════════════════════════════════════════════════ -->
    <form method="get"
          action="<?php echo esc_url( $track_url ); ?>"
          class="wcup-to-search">

        <div class="wcup-to-search-field">
            <div class="wcup-to-search-input-wrap">
                <span class="wcup-to-search-icon" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                </span>
                <input type="text"
                       name="track"
                       class="wcup-to-search-input"
                       value="<?php echo esc_attr( $search ); ?>"
                       placeholder="شماره سفارش، ایمیل یا شماره تماس..."
                       autocomplete="off">
            </div>

            <button type="submit" class="wcup-to-search-btn">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
                <span>جستجو</span>
            </button>
        </div>

        <?php if ( $has_search ) : ?>
            <div class="wcup-to-search-clear">
                <a href="<?php echo esc_url( $track_url ); ?>" class="wcup-to-clear-link">
                    ✕ پاک کردن جستجو
                </a>
            </div>
        <?php endif; ?>
    </form>


    <!-- ═══════════════════════════════════════════════════════
         ★ Results
    ═══════════════════════════════════════════════════════════ -->

    <?php if ( ! $user_id ) : ?>

        <!-- کاربر لاگین نیست -->
        <div class="wcup-to-empty">
            <div class="wcup-to-empty-icon">🔒</div>
            <div class="wcup-to-empty-title">برای پیگیری سفارش، وارد حساب شو</div>
            <div class="wcup-to-empty-desc">
                برای دیدن سفارشات، ابتدا وارد حساب کاربری خودت شو.
            </div>
            <a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>"
               class="wcup-to-empty-btn">
                ورود به حساب
            </a>
        </div>

    <?php elseif ( empty( $orders ) ) : ?>

        <!-- نتیجه‌ای پیدا نشد -->
        <div class="wcup-to-empty">
            <div class="wcup-to-empty-icon"><?php echo $has_search ? '🔍' : '📦'; ?></div>
            <div class="wcup-to-empty-title">
                <?php if ( $has_search ) : ?>
                    سفارشی با «<?php echo esc_html( $search ); ?>» پیدا نشد
                <?php else : ?>
                    هنوز سفارشی ثبت نکردی
                <?php endif; ?>
            </div>
            <div class="wcup-to-empty-desc">
                <?php if ( $has_search ) : ?>
                    مطمئن شو که اطلاعات رو درست وارد کردی.
                    فقط سفارشات خودت قابل پیگیری هستن.
                <?php else : ?>
                    وقتی اولین سفارشت رو ثبت کنی، اینجا نمایش داده می‌شه.
                <?php endif; ?>
            </div>
        </div>

    <?php else : ?>

        <!-- لیست سفارشات -->
        <?php if ( $has_search ) : ?>
            <div class="wcup-to-results-count">
                ✅ <strong><?php echo esc_html( wcup_fa_num( count( $orders ) ) ); ?></strong>
                سفارش پیدا شد
            </div>
        <?php endif; ?>

        <div class="wcup-to-list">
            <?php foreach ( $orders as $order ) :

                if ( ! $order instanceof WC_Order ) continue;

                $order_id     = $order->get_id();
                $order_number = $order->get_order_number();
                $order_date   = $order->get_date_created();
                $order_status = $order->get_status();
                $order_total  = $order->get_formatted_order_total();

                /* Badge */
                $status_map = array(
                    'pending'    => array( 'label' => 'در انتظار پرداخت', 'class' => 'pending' ),
                    'processing' => array( 'label' => 'در حال انجام',     'class' => 'processing' ),
                    'on-hold'    => array( 'label' => 'در انتظار بررسی',  'class' => 'on-hold' ),
                    'completed'  => array( 'label' => 'تکمیل شده',        'class' => 'completed' ),
                    'cancelled'  => array( 'label' => 'لغو شده',          'class' => 'cancelled' ),
                    'refunded'   => array( 'label' => 'مسترد شده',        'class' => 'refunded' ),
                    'failed'     => array( 'label' => 'ناموفق',           'class' => 'failed' ),
                );
                $badge = $status_map[ $order_status ] ?? array( 'label' => $order_status, 'class' => 'pending' );

                /* رهگیری */
                $tracking_code    = $order->get_meta( '_wcup_tracking_code' );
                $tracking_carrier = $order->get_meta( '_wcup_tracking_carrier' );
                $tracking_url     = function_exists( 'wcup_get_tracking_url' ) ? wcup_get_tracking_url( $order ) : '';
                $carrier_label    = function_exists( 'wcup_get_carrier_label' ) ? wcup_get_carrier_label( $tracking_carrier ) : $tracking_carrier;

                /* آیتم‌ها */
                $items      = $order->get_items();
                $item_count = $order->get_item_count();

                $date_str = $order_date ? date_i18n( 'j F Y', $order_date->getTimestamp() ) : '—';
            ?>

                <div class="wcup-to-card">

                    <!-- Head -->
                    <div class="wcup-to-card-head">
                        <div class="wcup-to-card-head-info">
                            <a href="<?php echo esc_url( $order->get_view_order_url() ); ?>"
                               class="wcup-to-card-number">
                                سفارش #<?php echo esc_html( wcup_fa_num( $order_number ) ); ?>
                            </a>
                            <div class="wcup-to-card-sub">
                                <span>📅 <?php echo esc_html( wcup_fa_num( $date_str ) ); ?></span>
                                <span class="wcup-to-card-dot">●</span>
                                <span>📦 <?php echo esc_html( wcup_fa_num( $item_count ) ); ?> آیتم</span>
                            </div>
                        </div>
                        <span class="wcup-ord-badge wcup-ord-badge--<?php echo esc_attr( $badge['class'] ); ?>">
                            <?php echo esc_html( $badge['label'] ); ?>
                        </span>
                    </div>

                    <!-- Items Summary -->
                    <?php if ( ! empty( $items ) ) : ?>
                        <div class="wcup-to-items">
                            <?php
                            $shown = 0;
                            foreach ( $items as $item ) :
                                if ( $shown >= 3 ) break;
                                $product = $item->get_product();
                                $img_url = $product && $product->get_image_id()
                                    ? wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' )
                                    : wc_placeholder_img_src();
                                $shown++;
                            ?>
                                <div class="wcup-to-item">
                                    <img src="<?php echo esc_url( $img_url ); ?>"
                                         alt="<?php echo esc_attr( $item->get_name() ); ?>"
                                         class="wcup-to-item-img" loading="lazy">
                                    <div class="wcup-to-item-info">
                                        <div class="wcup-to-item-name"><?php echo esc_html( $item->get_name() ); ?></div>
                                        <div class="wcup-to-item-qty">
                                            × <?php echo esc_html( wcup_fa_num( $item->get_quantity() ) ); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>

                            <?php if ( $item_count > 3 ) : ?>
                                <div class="wcup-to-item-more">
                                    و <?php echo esc_html( wcup_fa_num( $item_count - 3 ) ); ?> محصول دیگه...
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <!-- Tracking Info -->
                    <?php if ( $tracking_code ) : ?>
                        <div class="wcup-to-tracking">
                            <div class="wcup-to-tracking-row">
                                <span class="wcup-to-tracking-label">🚚 شرکت حمل:</span>
                                <span class="wcup-to-tracking-value"><?php echo esc_html( $carrier_label ?: '—' ); ?></span>
                            </div>
                            <div class="wcup-to-tracking-row">
                                <span class="wcup-to-tracking-label">🔢 کد رهگیری:</span>
                                <span class="wcup-to-tracking-code"><?php echo esc_html( $tracking_code ); ?></span>
                            </div>

                            <?php if ( $tracking_url ) : ?>
                                <a href="<?php echo esc_url( $tracking_url ); ?>"
                                   target="_blank"
                                   rel="noopener noreferrer"
                                   class="wcup-to-tracking-btn">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                         stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                                        <polyline points="15 3 21 3 21 9"></polyline>
                                        <line x1="10" y1="14" x2="21" y2="3"></line>
                                    </svg>
                                    <span>رهگیری آنلاین</span>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php else : ?>
                        <div class="wcup-to-no-tracking">
                            <span class="wcup-to-no-tracking-icon">⏳</span>
                            <span>اطلاعات رهگیری هنوز ثبت نشده. بعد از ارسال سفارش، اینجا نمایش داده می‌شه.</span>
                        </div>
                    <?php endif; ?>

                    <!-- Foot -->
                    <div class="wcup-to-card-foot">
                        <div class="wcup-to-card-total">
                            <?php echo wp_kses_post( $order_total ); ?>
                        </div>
                        <a href="<?php echo esc_url( $order->get_view_order_url() ); ?>"
                           class="wcup-to-view-btn">
                            <span>مشاهده جزئیات</span>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                 stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="19" y1="12" x2="5" y2="12"></line>
                                <polyline points="12 19 5 12 12 5"></polyline>
                            </svg>
                        </a>
                    </div>

                </div>

            <?php endforeach; ?>
        </div>

        <?php if ( ! $has_search ) : ?>
            <div class="wcup-to-footer-hint">
                💡 برای دیدن همهٔ سفارشات، به <a href="<?php echo esc_url( wc_get_endpoint_url( 'orders', '', wc_get_page_permalink( 'myaccount' ) ) ); ?>">سفارش‌ها</a> برو.
            </div>
        <?php endif; ?>

    <?php endif; ?>

</div>