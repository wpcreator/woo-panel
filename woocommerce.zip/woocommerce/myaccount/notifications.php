<?php
/**
 * My Account > Notifications
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

$user_id = get_current_user_id();

if ( ! $user_id || ! class_exists( 'wcup_notifications' ) ) {
    return;
}

/* صفحه‌بندی */
$current_page = max( 1, get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1 );
$per_page     = 20;
$offset       = ( $current_page - 1 ) * $per_page;

/* فیلتر */
$filter = isset( $_GET['filter'] ) ? sanitize_key( $_GET['filter'] ) : 'all';

$args = array(
    'limit'  => $per_page,
    'offset' => $offset,
    'unread' => $filter === 'unread',
);

$notifications = wcup_notifications::get( $user_id, $args );
$total         = wcup_notifications::count( $user_id, $filter === 'unread' );
$unread_count  = wcup_notifications::count( $user_id, true );
$max_pages     = (int) ceil( $total / $per_page );

/* آیکون‌ها */
$icons = array(
    'order'    => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>',
    'truck'    => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>',
    'star'     => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>',
    'system'   => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>',
);

$base_url = wc_get_endpoint_url( 'notifications', '', wc_get_page_permalink( 'myaccount' ) );
?>

<div class="wcup-notifications-page" dir="rtl">

    <!-- ═══ Header ═══ -->
    <div class="wcup-nf-header">
        <div class="wcup-nf-header-icon">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
            </svg>
        </div>
        <div class="wcup-nf-header-body">
            <h2 class="wcup-nf-title">اعلان‌ها</h2>
            <p class="wcup-nf-sub">
                <?php if ( $unread_count > 0 ) : ?>
                    <strong><?php echo esc_html( wcup_helpers::fa_num( $unread_count ) ); ?></strong> اعلان نخوانده داری
                <?php else : ?>
                    همهٔ اعلان‌ها خوانده شدن ✅
                <?php endif; ?>
            </p>
        </div>
        <?php if ( $unread_count > 0 ) : ?>
            <button type="button" class="wcup-nf-btn-mark-all" id="wcup-nf-mark-all">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                <span>همه رو خوانده کن</span>
            </button>
        <?php endif; ?>
    </div>

    <!-- ═══ Filters ═══ -->
    <div class="wcup-nf-filters">
        <a href="<?php echo esc_url( $base_url ); ?>"
           class="wcup-nf-filter <?php echo $filter === 'all' ? 'is-active' : ''; ?>">
            همه
        </a>
        <a href="<?php echo esc_url( add_query_arg( 'filter', 'unread', $base_url ) ); ?>"
           class="wcup-nf-filter <?php echo $filter === 'unread' ? 'is-active' : ''; ?>">
            نخوانده‌ها
            <?php if ( $unread_count > 0 ) : ?>
                <span class="wcup-nf-filter-badge"><?php echo esc_html( wcup_helpers::fa_num( $unread_count ) ); ?></span>
            <?php endif; ?>
        </a>
    </div>

    <!-- ═══ List ═══ -->
    <?php if ( empty( $notifications ) ) : ?>

        <div class="wcup-nf-empty">
            <div class="wcup-nf-empty-icon">🔔</div>
            <div class="wcup-nf-empty-title">
                <?php if ( $filter === 'unread' ) : ?>
                    هیچ اعلان نخوانده‌ای نداری
                <?php else : ?>
                    هنوز اعلانی نداری
                <?php endif; ?>
            </div>
            <div class="wcup-nf-empty-desc">
                وقتی وضعیت سفارشت تغییر کنه، نظرت تأیید بشه، یا اطلاعیه‌ای ثبت بشه، اینجا نمایش داده می‌شه.
            </div>
        </div>

    <?php else : ?>

        <div class="wcup-nf-list" id="wcup-nf-list">
            <?php foreach ( $notifications as $notif ) :
                $is_unread  = ! (int) $notif->is_read;
                $icon_key   = $notif->icon ? $notif->icon : $notif->type;
                $icon_svg   = isset( $icons[ $icon_key ] ) ? $icons[ $icon_key ] : $icons['system'];
                $time_str   = human_time_diff( strtotime( $notif->created_at ), current_time( 'timestamp' ) );
            ?>
                <div class="wcup-nf-item <?php echo $is_unread ? 'is-unread' : ''; ?>"
                     data-id="<?php echo esc_attr( $notif->id ); ?>"
                     data-type="<?php echo esc_attr( $notif->type ); ?>">

                    <div class="wcup-nf-item-icon">
                        <?php echo $icon_svg; // phpcs:ignore ?>
                        <?php if ( $is_unread ) : ?>
                            <span class="wcup-nf-item-dot"></span>
                        <?php endif; ?>
                    </div>

                    <div class="wcup-nf-item-body">
                        <div class="wcup-nf-item-head">
                            <span class="wcup-nf-item-title"><?php echo esc_html( $notif->title ); ?></span>
                            <span class="wcup-nf-item-time"><?php echo esc_html( $time_str ); ?> پیش</span>
                        </div>

                        <?php if ( $notif->message ) : ?>
                            <div class="wcup-nf-item-message"><?php echo wp_kses_post( $notif->message ); ?></div>
                        <?php endif; ?>

                        <div class="wcup-nf-item-actions">
                            <?php if ( $notif->link ) : ?>
                                <a href="<?php echo esc_url( $notif->link ); ?>"
                                   class="wcup-nf-item-link">
                                    مشاهده
                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                        <polyline points="15 18 9 12 15 6"></polyline>
                                    </svg>
                                </a>
                            <?php endif; ?>

                            <button type="button"
                                    class="wcup-nf-item-delete"
                                    data-id="<?php echo esc_attr( $notif->id ); ?>"
                                    title="حذف">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                    <polyline points="3 6 5 6 21 6"></polyline>
                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                </svg>
                            </button>
                        </div>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ( $max_pages > 1 ) : ?>
            <div class="wcup-nf-pagination">
                <?php
                $filter_arg = $filter !== 'all' ? array( 'filter' => $filter ) : array();
                ?>
                <div class="wcup-nf-page-numbers">
                    <?php for ( $i = 1; $i <= $max_pages; $i++ ) :
                        $page_url = ( $i === 1 )
                            ? add_query_arg( $filter_arg, $base_url )
                            : add_query_arg( array_merge( array( 'paged' => $i ), $filter_arg ), $base_url );
                        $is_cur   = ( $i === $current_page );
                    ?>
                        <a href="<?php echo esc_url( $page_url ); ?>"
                           class="wcup-nf-page-num <?php echo $is_cur ? 'is-active' : ''; ?>">
                            <?php echo esc_html( wcup_helpers::fa_num( $i ) ); ?>
                        </a>
                    <?php endfor; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- دکمهٔ حذف همه -->
        <div class="wcup-nf-footer">
            <button type="button" class="wcup-nf-btn-delete-all" id="wcup-nf-delete-all">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="3 6 5 6 21 6"></polyline>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                </svg>
                <span>حذف همهٔ اعلان‌ها</span>
            </button>
        </div>

    <?php endif; ?>

</div>