<?php
/**
 * My Account — Wrapper (2-column layout)
 * @version 3.0.0
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="wcup-account-wrap">

    <aside class="wcup-account-sidebar">
        <?php do_action( 'woocommerce_account_navigation' ); ?>
    </aside>

    <main class="wcup-account-main">
        <?php
        /* ★ پیام‌ها دیگه inline نمایش داده نمیشن — به Toast تبدیل میشن */
        do_action( 'woocommerce_account_content' );
        ?>
    </main>

</div>