<?php
/**
 * My Account > Login / Register (Custom Override)
 * ----------------------------------------------------------
 *  ساختار:
 *    - تب‌بندی بین ورود و ثبت‌نام
 *    - فرم ورود با «یادآوری من» و «فراموشی رمز»
 *    - فرم ثبت‌نام با ایمیل + رمز
 *    - پیام‌های ووکامرس (خطا / موفقیت)
 *
 * @version 3.0.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_customer_login_form' );

/* ============================================================
 *  ★ تنظیمات ووکامرس
 * ============================================================ */
$registration_enabled = 'yes' === get_option( 'woocommerce_enable_myaccount_registration' );
$generate_username    = 'yes' === get_option( 'woocommerce_registration_generate_username' );
$generate_password    = 'yes' === get_option( 'woocommerce_registration_generate_password' );

$my_account_url = wc_get_page_permalink( 'myaccount' );

/* تب فعال بر اساس URL */
$current_action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : '';
$active_tab     = ( 'register' === $current_action || isset( $_POST['register'] ) ) ? 'register' : 'login';
?>

<div class="wcup-auth" dir="rtl">

    <?php wc_print_notices(); ?>

    <!-- ═══════════════════════════════════════════════════
         ★ Tabs (فقط اگه ثبت‌نام فعاله)
    ═══════════════════════════════════════════════════════ -->
    <?php if ( $registration_enabled ) : ?>
        <div class="wcup-auth-tabs">
            <button type="button"
                    class="wcup-auth-tab <?php echo 'login' === $active_tab ? 'is-active' : ''; ?>"
                    data-target="login">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.2"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
                    <polyline points="10 17 15 12 10 7"></polyline>
                    <line x1="15" y1="12" x2="3" y2="12"></line>
                </svg>
                <span>ورود به حساب</span>
            </button>

            <button type="button"
                    class="wcup-auth-tab <?php echo 'register' === $active_tab ? 'is-active' : ''; ?>"
                    data-target="register">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.2"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <line x1="19" y1="8" x2="19" y2="14"></line>
                    <line x1="22" y1="11" x2="16" y2="11"></line>
                </svg>
                <span>ثبت‌نام</span>
            </button>
        </div>
    <?php endif; ?>


    <!-- ═══════════════════════════════════════════════════
         ★ پنل ۱: ورود
    ═══════════════════════════════════════════════════ -->
    <div class="wcup-auth-panel <?php echo 'login' === $active_tab ? 'is-active' : ''; ?>"
         data-panel="login">

        <div class="wcup-auth-head">
            <h2 class="wcup-auth-title">ورود به حساب کاربری</h2>
            <p class="wcup-auth-sub">خوش برگشتی! وارد شو و خریدت رو ادامه بده.</p>
        </div>

        <form class="woocommerce-form woocommerce-form-login login"
              method="post"
              novalidate>

            <?php do_action( 'woocommerce_login_form_start' ); ?>

            <div class="wcup-auth-field">
                <label for="username" class="wcup-auth-label">
                    نام کاربری یا ایمیل <span class="wcup-auth-required">*</span>
                </label>
                <div class="wcup-auth-input-wrap">
                    <span class="wcup-auth-input-icon" aria-hidden="true">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.2"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                    </span>
                    <input type="text"
                           class="wcup-auth-input woocommerce-Input woocommerce-Input--text"
                           name="username"
                           id="username"
                           autocomplete="username"
                           placeholder="مثلاً: amir@example.com">
                </div>
            </div>

            <div class="wcup-auth-field">
                <label for="password" class="wcup-auth-label">
                    رمز عبور <span class="wcup-auth-required">*</span>
                </label>
                <div class="wcup-auth-input-wrap">
                    <span class="wcup-auth-input-icon" aria-hidden="true">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.2"
                             stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                        </svg>
                    </span>
                    <input type="password"
                           class="wcup-auth-input woocommerce-Input woocommerce-Input--text"
                           name="password"
                           id="password"
                           autocomplete="current-password"
                           placeholder="رمز عبور خود را وارد کنید">
                    <button type="button"
                            class="wcup-auth-toggle-pass"
                            aria-label="نمایش رمز عبور"
                            data-target="password">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.2"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                    </button>
                </div>
            </div>

            <?php do_action( 'woocommerce_login_form' ); ?>

            <div class="wcup-auth-row">
                <label class="wcup-auth-check">
                    <input type="checkbox"
                           name="rememberme"
                           id="rememberme"
                           value="forever">
                    <span class="wcup-auth-check-box"></span>
                    <span class="wcup-auth-check-label">مرا به خاطر بسپار</span>
                </label>

                <a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"
                   class="wcup-auth-forgot">
                    رمز عبور را فراموش کردی؟
                </a>
            </div>

            <?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>

            <button type="submit"
                    class="wcup-auth-submit"
                    name="login"
                    value="ورود">
                <span>ورود به حساب</span>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5"
                     stroke-linecap="round" stroke-linejoin="round">
                    <line x1="19" y1="12" x2="5" y2="12"></line>
                    <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
            </button>

            <?php do_action( 'woocommerce_login_form_end' ); ?>
        </form>
    </div>


    <!-- ═══════════════════════════════════════════════════
         ★ پنل ۲: ثبت‌نام
    ═══════════════════════════════════════════════════ -->
    <?php if ( $registration_enabled ) : ?>
        <div class="wcup-auth-panel <?php echo 'register' === $active_tab ? 'is-active' : ''; ?>"
             data-panel="register">

            <div class="wcup-auth-head">
                <h2 class="wcup-auth-title">ساخت حساب کاربری جدید</h2>
                <p class="wcup-auth-sub">با ثبت‌نام سریع، به تمام امکانات حساب کاربری دسترسی پیدا کن.</p>
            </div>

            <form method="post"
                  class="woocommerce-form woocommerce-form-register register"
                  <?php do_action( 'woocommerce_register_form_tag' ); ?>>

                <?php do_action( 'woocommerce_register_form_start' ); ?>

                <!-- نام کاربری (فقط اگه خودکار نباشه) -->
                <?php if ( ! $generate_username ) : ?>
                    <div class="wcup-auth-field">
                        <label for="reg_username" class="wcup-auth-label">
                            نام کاربری <span class="wcup-auth-required">*</span>
                        </label>
                        <div class="wcup-auth-input-wrap">
                            <span class="wcup-auth-input-icon" aria-hidden="true">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                                     stroke="currentColor" stroke-width="2.2"
                                     stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                    <circle cx="12" cy="7" r="4"></circle>
                                </svg>
                            </span>
                            <input type="text"
                                   class="wcup-auth-input woocommerce-Input woocommerce-Input--text"
                                   name="username"
                                   id="reg_username"
                                   autocomplete="username"
                                   placeholder="نام کاربری دلخواه">
                        </div>
                    </div>
                <?php endif; ?>

                <!-- ایمیل -->
                <div class="wcup-auth-field">
                    <label for="reg_email" class="wcup-auth-label">
                        آدرس ایمیل <span class="wcup-auth-required">*</span>
                    </label>
                    <div class="wcup-auth-input-wrap">
                        <span class="wcup-auth-input-icon" aria-hidden="true">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                                 stroke="currentColor" stroke-width="2.2"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                                <polyline points="22,6 12,13 2,6"></polyline>
                            </svg>
                        </span>
                        <input type="email"
                               class="wcup-auth-input woocommerce-Input woocommerce-Input--email"
                               name="email"
                               id="reg_email"
                               autocomplete="email"
                               placeholder="example@email.com">
                    </div>
                </div>

                <!-- رمز عبور (فقط اگه خودکار نباشه) -->
                <?php if ( ! $generate_password ) : ?>
                    <div class="wcup-auth-field">
                        <label for="reg_password" class="wcup-auth-label">
                            رمز عبور <span class="wcup-auth-required">*</span>
                        </label>
                        <div class="wcup-auth-input-wrap">
                            <span class="wcup-auth-input-icon" aria-hidden="true">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                                     stroke="currentColor" stroke-width="2.2"
                                     stroke-linecap="round" stroke-linejoin="round">
                                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                    <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                                </svg>
                            </span>
                            <input type="password"
                                   class="wcup-auth-input woocommerce-Input woocommerce-Input--text"
                                   name="password"
                                   id="reg_password"
                                   autocomplete="new-password"
                                   placeholder="رمز عبور خود را وارد کنید">
                            <button type="button"
                                    class="wcup-auth-toggle-pass"
                                    aria-label="نمایش رمز عبور"
                                    data-target="reg_password">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                                     stroke="currentColor" stroke-width="2.2"
                                     stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                    <circle cx="12" cy="12" r="3"></circle>
                                </svg>
                            </button>
                        </div>
                    </div>
                <?php else : ?>
                    <div class="wcup-auth-hint">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.2"
                             stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="16" x2="12" y2="12"></line>
                            <line x1="12" y1="8" x2="12.01" y2="8"></line>
                        </svg>
                        <span>یک لینک تعیین رمز عبور به ایمیلت ارسال می‌شود.</span>
                    </div>
                <?php endif; ?>

                <?php do_action( 'woocommerce_register_form' ); ?>

                <?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>

                <button type="submit"
                        class="wcup-auth-submit"
                        name="register"
                        value="ثبت‌نام">
                    <span>ساخت حساب کاربری</span>
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2.5"
                         stroke-linecap="round" stroke-linejoin="round">
                        <line x1="19" y1="12" x2="5" y2="12"></line>
                        <polyline points="12 19 5 12 12 5"></polyline>
                    </svg>
                </button>

                <?php do_action( 'woocommerce_register_form_end' ); ?>
            </form>
        </div>
    <?php endif; ?>

</div>


<script>
/* ═══ تب‌ها ═══ */
(function () {
    var tabs   = document.querySelectorAll('.wcup-auth-tab');
    var panels = document.querySelectorAll('.wcup-auth-panel');
    if (!tabs.length) return;

    tabs.forEach(function (tab) {
        tab.addEventListener('click', function () {
            var target = tab.getAttribute('data-target');

            tabs.forEach(function (t) { t.classList.remove('is-active'); });
            panels.forEach(function (p) { p.classList.remove('is-active'); });

            tab.classList.add('is-active');
            var panel = document.querySelector('.wcup-auth-panel[data-panel="' + target + '"]');
            if (panel) panel.classList.add('is-active');
        });
    });
})();

/* ═══ نمایش/مخفی رمز عبور ═══ */
(function () {
    document.querySelectorAll('.wcup-auth-toggle-pass').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var inputId = btn.getAttribute('data-target');
            var input   = document.getElementById(inputId);
            if (!input) return;

            var isPass = input.type === 'password';
            input.type = isPass ? 'text' : 'password';
            btn.classList.toggle('is-visible', isPass);
        });
    });
})();
</script>

<?php do_action( 'woocommerce_after_customer_login_form' ); ?>