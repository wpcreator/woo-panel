<?php
/**
 * My Account > Wishlist
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

$user_id = get_current_user_id();

if ( ! $user_id || ! class_exists( 'wcup_wishlist' ) ) {
    return;
}

/* صفحه‌بندی */
$current_page = max( 1, get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1 );
$per_page     = 20;

$wishlist_ids = wcup_wishlist::get_wishlist( $user_id );
$total        = count( $wishlist_ids );
$max_pages    = (int) ceil( $total / $per_page );

/* صفحه‌بندی */
$offset = ( $current_page - 1 ) * $per_page;
$paged_ids = array_slice( $wishlist_ids, $offset, $per_page );

/* دریافت محصولات */
$products = array();
foreach ( $paged_ids as $product_id ) {
    $product = wc_get_product( $product_id );
    if ( $product ) {
        $products[] = $product;
    }
}

$base_url = wc_get_endpoint_url( 'wishlist', '', wc_get_page_permalink( 'myaccount' ) );
?>

<div class="wcup-wishlist-page" dir="rtl">

    <!-- ═══ Header ═══ -->
    <div class="wcup-wl-header">
        <div class="wcup-wl-header-icon">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
            </svg>
        </div>
        <div class="wcup-wl-header-body">
            <h2 class="wcup-wl-title">علاقه‌مندی‌ها</h2>
            <p class="wcup-wl-sub">
                <?php if ( $total > 0 ) : ?>
                    <strong><?php echo esc_html( wcup_helpers::fa_num( $total ) ); ?></strong> محصول ذخیره کردی
                <?php else : ?>
                    محصولاتی که دوست داری رو اینجا ذخیره کن
                <?php endif; ?>
            </p>
        </div>

        <?php if ( $total > 0 ) : ?>
            <button type="button" class="wcup-wl-btn-clear" id="wcup-wl-clear">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="3 6 5 6 21 6"></polyline>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                </svg>
                <span>پاک‌سازی کامل</span>
            </button>
        <?php endif; ?>
    </div>

    <?php if ( empty( $products ) ) : ?>

        <!-- ═══ Empty ═══ -->
        <div class="wcup-wl-empty">
            <div class="wcup-wl-empty-icon">💝</div>
            <div class="wcup-wl-empty-title">هنوز چیزی به علاقه‌مندی‌ها اضافه نکردی</div>
            <div class="wcup-wl-empty-desc">
                محصولاتی که دوست داری رو با کلیک روی آیکون قلب ذخیره کن تا بعداً راحت پیداشون کنی.
            </div>
            <a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"
               class="wcup-wl-empty-btn">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="9" cy="21" r="1"></circle>
                    <circle cx="20" cy="21" r="1"></circle>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                </svg>
                <span>شروع خرید</span>
            </a>
        </div>

    <?php else : ?>

        <!-- ═══ Grid ═══ -->
        <div class="wcup-wl-grid">
            <?php foreach ( $products as $product ) :

                $product_id = $product->get_id();
                $name       = $product->get_name();
                $permalink  = $product->get_permalink();
                $price_html = $product->get_price_html();
                $img_url    = wp_get_attachment_image_url( $product->get_image_id(), 'woocommerce_thumbnail' );
                if ( ! $img_url ) {
                    $img_url = wc_placeholder_img_src( 'woocommerce_thumbnail' );
                }
                $in_stock   = $product->is_in_stock();
                $purchasable = $product->is_purchasable();
            ?>

                <div class="wcup-wl-card" data-product-id="<?php echo esc_attr( $product_id ); ?>">

                    <!-- Image -->
                    <a href="<?php echo esc_url( $permalink ); ?>" class="wcup-wl-card-img-link">
                        <img src="<?php echo esc_url( $img_url ); ?>"
                             alt="<?php echo esc_attr( $name ); ?>"
                             class="wcup-wl-card-img"
                             loading="lazy">

                        <?php if ( ! $in_stock ) : ?>
                            <span class="wcup-wl-card-badge wcup-wl-card-badge--out">ناموجود</span>
                        <?php elseif ( $product->is_on_sale() ) : ?>
                            <span class="wcup-wl-card-badge wcup-wl-card-badge--sale">تخفیف</span>
                        <?php endif; ?>

                        <!-- Remove Button -->
                        <button type="button"
                                class="wcup-wl-card-remove"
                                data-product-id="<?php echo esc_attr( $product_id ); ?>"
                                aria-label="حذف از علاقه‌مندی‌ها">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                                 stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                        </button>
                    </a>

                    <!-- Body -->
                    <div class="wcup-wl-card-body">
                        <a href="<?php echo esc_url( $permalink ); ?>" class="wcup-wl-card-title">
                            <?php echo esc_html( $name ); ?>
                        </a>

                        <div class="wcup-wl-card-price">
                            <?php echo wp_kses_post( $price_html ); ?>
                        </div>
                    </div>

                    <!-- Foot -->
                    <div class="wcup-wl-card-foot">
                        <?php if ( $in_stock && $purchasable ) : ?>
                            <a href="<?php echo esc_url( $product->add_to_cart_url() ); ?>"
                               data-quantity="1"
                               data-product_id="<?php echo esc_attr( $product_id ); ?>"
                               class="wcup-wl-card-btn wcup-wl-card-btn--cart button add_to_cart_button ajax_add_to_cart">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                     stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="9" cy="21" r="1"></circle>
                                    <circle cx="20" cy="21" r="1"></circle>
                                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                                </svg>
                                <span>افزودن به سبد</span>
                            </a>
                        <?php else : ?>
                            <a href="<?php echo esc_url( $permalink ); ?>" class="wcup-wl-card-btn">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                     stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="19" y1="12" x2="5" y2="12"></line>
                                    <polyline points="12 19 5 12 12 5"></polyline>
                                </svg>
                                <span>مشاهده محصول</span>
                            </a>
                        <?php endif; ?>
                    </div>

                </div>

            <?php endforeach; ?>
        </div>

        <!-- ═══ Pagination ═══ -->
        <?php if ( $max_pages > 1 ) : ?>
            <div class="wcup-wl-pagination">
                <div class="wcup-wl-page-numbers">
                    <?php for ( $i = 1; $i <= $max_pages; $i++ ) :
                        $page_url = ( $i === 1 ) ? $base_url : add_query_arg( 'paged', $i, $base_url );
                        $is_cur   = ( $i === $current_page );
                    ?>
                        <a href="<?php echo esc_url( $page_url ); ?>"
                           class="wcup-wl-page-num <?php echo $is_cur ? 'is-active' : ''; ?>">
                            <?php echo esc_html( wcup_helpers::fa_num( $i ) ); ?>
                        </a>
                    <?php endfor; ?>
                </div>
            </div>
        <?php endif; ?>

    <?php endif; ?>

</div>