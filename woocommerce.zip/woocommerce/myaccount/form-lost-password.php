<?php
/**
 * My Account > Lost Password (Custom Override)
 * ----------------------------------------------------------
 *  ساختار:
 *    - کارت فرم فراموشی رمز
 *    - فیلد ورودی (نام کاربری یا ایمیل)
 *    - دکمهٔ ارسال لینک بازنشانی
 *    - لینک بازگشت به ورود
 *
 * @version 3.0.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_lost_password_form' );
?>

<div class="wcup-lost-pass" dir="rtl">

    <?php wc_print_notices(); ?>

    <div class="wcup-lp-card">

        <!-- ═══ Icon ═══ -->
        <div class="wcup-lp-icon" aria-hidden="true">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
            </svg>
        </div>

        <!-- ═══ Head ═══ -->
        <div class="wcup-lp-head">
            <h2 class="wcup-lp-title">بازیابی رمز عبور</h2>
            <p class="wcup-lp-sub">
                نام کاربری یا آدرس ایمیلت رو وارد کن. یه لینک برای تعیین رمز جدید برات ارسال می‌کنیم.
            </p>
        </div>

        <!-- ═══ Form ═══ -->
        <form method="post"
              class="woocommerce-ResetPassword lost_reset_password wcup-lp-form">

            <div class="wcup-lp-field">
                <label for="user_login" class="wcup-lp-label">
                    نام کاربری یا ایمیل
                </label>
                <div class="wcup-lp-input-wrap">
                    <span class="wcup-lp-input-icon" aria-hidden="true">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.2"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                            <polyline points="22,6 12,13 2,6"></polyline>
                        </svg>
                    </span>
                    <input type="text"
                           class="wcup-lp-input woocommerce-Input woocommerce-Input--text input-text"
                           name="user_login"
                           id="user_login"
                           autocomplete="username"
                           placeholder="مثلاً: amir@example.com">
                </div>
            </div>

            <?php do_action( 'woocommerce_lostpassword_form' ); ?>

            <input type="hidden" name="wc_reset_password" value="true" />

            <?php wp_nonce_field( 'lost_password', 'woocommerce-lost-password-nonce' ); ?>

            <button type="submit"
                    class="wcup-lp-submit"
                    value="<?php esc_attr_e( 'Reset password', 'woocommerce' ); ?>">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5"
                     stroke-linecap="round" stroke-linejoin="round">
                    <line x1="22" y1="2" x2="11" y2="13"></line>
                    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                </svg>
                <span>ارسال لینک بازیابی</span>
            </button>

        </form>

        <!-- ═══ Footer: back to login ═══ -->
        <div class="wcup-lp-footer">
            <a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>"
               class="wcup-lp-back">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5"
                     stroke-linecap="round" stroke-linejoin="round">
                    <line x1="19" y1="12" x2="5" y2="12"></line>
                    <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                <span>بازگشت به صفحه ورود</span>
            </a>
        </div>

    </div>

</div>

<?php do_action( 'woocommerce_after_lost_password_form' ); ?>