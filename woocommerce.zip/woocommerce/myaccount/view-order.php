<?php
/**
 * My Account > View Order (Custom Override)
 * @version 3.1.1
 */

defined( 'ABSPATH' ) || exit;

/* ============================================================
 *  گرفتن $order_id
 * ============================================================ */
if ( ! isset( $order_id ) || ! $order_id ) {

    global $wp;

    if ( isset( $wp->query_vars['view-order'] ) ) {
        $order_id = absint( $wp->query_vars['view-order'] );
    }

    if ( ! $order_id ) {
        $order_id = absint( get_query_var( 'view-order' ) );
    }

    if ( ! $order_id && ! empty( $_SERVER['REQUEST_URI'] ) ) {
        if ( preg_match( '#/view-order/(\d+)#', $_SERVER['REQUEST_URI'], $m ) ) {
            $order_id = absint( $m[1] );
        }
    }
}

/* ============================================================
 *  اگه $order_id صفر بود
 * ============================================================ */
if ( ! $order_id ) {
    echo '<div class="wcup-vo-error" style="padding:30px;background:#fdecec;border-radius:16px;color:#c0392b;text-align:center;">';
    echo '<strong>سفارش مورد نظر یافت نشد.</strong>';
    echo '<p style="margin-top:8px;">لطفاً از <a href="' . esc_url( wc_get_endpoint_url( 'orders', '', wc_get_page_permalink( 'myaccount' ) ) ) . '">لیست سفارش‌ها</a> یک سفارش رو انتخاب کن.</p>';
    echo '</div>';
    return;
}

$order = wc_get_order( $order_id );
if ( ! $order ) {
    echo '<div class="wcup-vo-error" style="padding:30px;background:#fdecec;border-radius:16px;color:#c0392b;text-align:center;">';
    echo '<strong>سفارش با شناسهٔ ' . esc_html( $order_id ) . ' پیدا نشد.</strong>';
    echo '</div>';
    return;
}

/* دسترسی */
if ( $order->get_customer_id() !== get_current_user_id() && ! current_user_can( 'manage_woocommerce' ) ) {
    echo '<div class="wcup-vo-error" style="padding:30px;background:#fdecec;border-radius:16px;color:#c0392b;text-align:center;">';
    echo '<strong>شما اجازهٔ مشاهدهٔ این سفارش را ندارید.</strong>';
    echo '</div>';
    return;
}

$order_number   = $order->get_order_number();
$order_date     = $order->get_date_created();
$order_status   = $order->get_status();
$order_total    = $order->get_formatted_order_total();
$payment_method = $order->get_payment_method_title();
$order_currency = $order->get_currency();

/* Badge */
$status_map = array(
    'pending'    => array( 'label' => 'در انتظار پرداخت', 'class' => 'pending' ),
    'processing' => array( 'label' => 'در حال انجام',     'class' => 'processing' ),
    'on-hold'    => array( 'label' => 'در انتظار بررسی',  'class' => 'on-hold' ),
    'completed'  => array( 'label' => 'تکمیل شده',        'class' => 'completed' ),
    'cancelled'  => array( 'label' => 'لغو شده',          'class' => 'cancelled' ),
    'refunded'   => array( 'label' => 'مسترد شده',        'class' => 'refunded' ),
    'failed'     => array( 'label' => 'ناموفق',           'class' => 'failed' ),
);
$badge = $status_map[ $order_status ] ?? array( 'label' => $order_status, 'class' => 'pending' );

$date_str = $order_date ? date_i18n( 'j F Y', $order_date->getTimestamp() ) : '—';
$back_url = wc_get_endpoint_url( 'orders', '', wc_get_page_permalink( 'myaccount' ) );

wc_print_notices();
?>

<div class="wcup-view-order" dir="rtl">

    <!-- ═══ کارت ۱: اطلاعات سفارش ═══ -->
    <div class="wcup-vo-info">

        <a href="<?php echo esc_url( $back_url ); ?>" class="wcup-vo-back">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2.5"
                 stroke-linecap="round" stroke-linejoin="round">
                <line x1="5" y1="12" x2="19" y2="12"></line>
                <polyline points="12 5 19 12 12 19"></polyline>
            </svg>
            <span>لیست سفارش‌ها</span>
        </a>

        <div class="wcup-vo-info-main">
            <div class="wcup-vo-info-text">
                <div class="wcup-vo-info-number">
                    سفارش #<?php echo esc_html( wcup_fa_num( $order_number ) ); ?>
                </div>
                <div class="wcup-vo-info-date">
                    ثبت شده در <?php echo esc_html( $date_str ); ?>
                </div>
            </div>

            <div class="wcup-vo-info-badge-wrap">
                <span class="wcup-vo-info-badge-label">وضعیت:</span>
                <span class="wcup-vo-badge wcup-vo-badge--<?php echo esc_attr( $badge['class'] ); ?>">
                    <?php echo esc_html( $badge['label'] ); ?>
                </span>
            </div>
        </div>

    </div>

    <!-- ═══ کارت ۲: محصولات ═══ -->
    <?php
    $order_items = $order->get_items();
    if ( ! empty( $order_items ) ) :
    ?>
        <div class="wcup-vo-products">
            <?php foreach ( $order_items as $item_id => $item ) :

                $product = $item->get_product();
                if ( ! $product ) continue;

                $product_name = $item->get_name();
                $product_link = $product->get_permalink();
                $img_id       = $product->get_image_id();
                $img_url      = $img_id
                    ? wp_get_attachment_image_url( $img_id, 'medium' )
                    : wc_placeholder_img_src();

                $is_downloadable = $product->is_downloadable();
                $has_download    = false;

                if ( $is_downloadable && $order->has_downloadable_item() && $order->is_download_permitted() ) {
                    $downloads = $order->get_downloadable_items();
                    foreach ( $downloads as $dl ) {
                        if ( (int) $dl['product_id'] === $product->get_id() ) {
                            $has_download = true;
                            break;
                        }
                    }
                }
            ?>
                <div class="wcup-vo-product">

                    <a href="<?php echo esc_url( $product_link ); ?>" class="wcup-vo-product-img-link">
                        <img src="<?php echo esc_url( $img_url ); ?>"
                             alt="<?php echo esc_attr( $product_name ); ?>"
                             class="wcup-vo-product-img"
                             loading="lazy">
                    </a>

                    <div class="wcup-vo-product-body">
                        <a href="<?php echo esc_url( $product_link ); ?>" class="wcup-vo-product-title">
                            <?php echo esc_html( $product_name ); ?>
                        </a>

                        <?php
                        $meta_html = wc_display_item_meta( $item, array(
                            'before'    => '<div class="wcup-vo-product-meta">',
                            'after'     => '</div>',
                            'separator' => '',
                            'echo'      => false,
                        ) );
                        if ( $meta_html ) {
                            echo wp_kses_post( $meta_html );
                        }
                        ?>
                    </div>

                    <?php if ( $has_download ) : ?>
                        <div class="wcup-vo-downloads">
                            <button type="button"
                                    class="wcup-vo-downloads-toggle"
                                    aria-expanded="false"
                                    aria-controls="wcup-vo-dl-<?php echo esc_attr( $item_id ); ?>">
                                <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                                     stroke="currentColor" stroke-width="2.5"
                                     stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                    <polyline points="7 10 12 15 17 10"></polyline>
                                    <line x1="12" y1="15" x2="12" y2="3"></line>
                                </svg>
                                <span>گزینه‌های دانلود</span>
                                <svg class="wcup-vo-downloads-chevron"
                                     width="14" height="14" viewBox="0 0 24 24" fill="none"
                                     stroke="currentColor" stroke-width="2.5"
                                     stroke-linecap="round" stroke-linejoin="round">
                                    <polyline points="6 9 12 15 18 9"></polyline>
                                </svg>
                            </button>

                            <div class="wcup-vo-downloads-panel"
                                 id="wcup-vo-dl-<?php echo esc_attr( $item_id ); ?>"
                                 hidden>
                                <?php
                                $downloads = $order->get_downloadable_items();
                                foreach ( $downloads as $dl ) :
                                    if ( (int) $dl['product_id'] !== $product->get_id() ) continue;
                                ?>
                                    <a href="<?php echo esc_url( $dl['download_url'] ); ?>" class="wcup-vo-download-link">
                                        <span><?php echo esc_html( $dl['download_name'] ); ?></span>
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                                             stroke="currentColor" stroke-width="2.5"
                                             stroke-linecap="round" stroke-linejoin="round">
                                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                            <polyline points="7 10 12 15 17 10"></polyline>
                                            <line x1="12" y1="15" x2="12" y2="3"></line>
                                        </svg>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- ═══ کارت ۳: رهگیری ═══ -->
    <?php
    $tracking_code    = $order->get_meta( '_wcup_tracking_code' );
    $tracking_carrier = $order->get_meta( '_wcup_tracking_carrier' );

    if ( $tracking_code ) :
        $carriers     = function_exists( 'wcup_get_carriers' ) ? wcup_get_carriers() : array();
        $carrier_name = isset( $carriers[ $tracking_carrier ]['label'] )
            ? $carriers[ $tracking_carrier ]['label']
            : 'شرکت حمل';
        $tracking_url = function_exists( 'wcup_get_tracking_url' ) ? wcup_get_tracking_url( $order ) : '';
    ?>
        <div class="wcup-vo-tracking">
            <div class="wcup-vo-tracking-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2"
                     stroke-linecap="round" stroke-linejoin="round">
                    <rect x="1" y="3" width="15" height="13"></rect>
                    <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                    <circle cx="5.5" cy="18.5" r="2.5"></circle>
                    <circle cx="18.5" cy="18.5" r="2.5"></circle>
                </svg>
            </div>

            <div class="wcup-vo-tracking-body">
                <div class="wcup-vo-tracking-title">رهگیری مرسوله</div>
                <div class="wcup-vo-tracking-info">
                    <div class="wcup-vo-tracking-row">
                        <span class="wcup-vo-tracking-label">شرکت حمل:</span>
                        <span class="wcup-vo-tracking-value"><?php echo esc_html( $carrier_name ); ?></span>
                    </div>
                    <div class="wcup-vo-tracking-row">
                        <span class="wcup-vo-tracking-label">کد رهگیری:</span>
                        <span class="wcup-vo-tracking-code"><?php echo esc_html( $tracking_code ); ?></span>
                    </div>
                </div>
            </div>

            <?php if ( $tracking_url ) : ?>
                <a href="<?php echo esc_url( $tracking_url ); ?>"
                   target="_blank"
                   rel="noopener noreferrer"
                   class="wcup-vo-tracking-btn">
                    <span>رهگیری آنلاین</span>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2.5"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                        <polyline points="15 3 21 3 21 9"></polyline>
                        <line x1="10" y1="14" x2="21" y2="3"></line>
                    </svg>
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- ═══ کارت ۴: جزئیات سفارش ═══ -->
    <div class="wcup-vo-details">

        <h3 class="wcup-vo-details-title">جزئیات سفارش</h3>

        <div class="wcup-vo-table">
            <div class="wcup-vo-table-head">
                <div class="wcup-vo-table-col--product">محصول</div>
                <div class="wcup-vo-table-col--total">مجموع</div>
            </div>

            <?php foreach ( $order_items as $item_id => $item ) :
                $product_name = $item->get_name();
                $qty          = $item->get_quantity();
                $line_total   = $order->get_formatted_line_subtotal( $item );
            ?>
                <div class="wcup-vo-table-row">
                    <div class="wcup-vo-table-col--product">
                        <?php echo esc_html( $product_name ); ?>
                        <strong class="wcup-vo-table-qty">
                            × <?php echo esc_html( wcup_fa_num( $qty ) ); ?>
                        </strong>
                    </div>
                    <div class="wcup-vo-table-col--total">
                        <?php echo wp_kses_post( $line_total ); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- ═══════════════════════════════════════════════════
             ⭐ فاکتور — فقط یه if/elseif/endif
        ═══════════════════════════════════════════════════ -->
        <?php
        if ( class_exists( 'wcup_invoice' ) && wcup_invoice::instance()->can_download( $order ) ) :

            $invoice_url = wcup_invoice::instance()->get_invoice_url( $order );
        ?>
            <div class="wcup-vo-invoice-row">
                <a href="<?php echo esc_url( $invoice_url ); ?>"
                   target="_blank"
                   rel="noopener"
                   class="wcup-vo-invoice-btn wcup-vo-invoice-btn--primary">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2.5"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <polyline points="10 9 9 9 8 9"></polyline>
                    </svg>
                    <span>مشاهدهٔ فاکتور</span>
                </a>
            </div>

        <?php
        elseif ( shortcode_exists( 'faktorak_invoice_button' ) ) :
        ?>
            <div class="wcup-vo-invoice-row">
                <div class="wcup-vo-invoice-shortcode">
                    <?php echo do_shortcode( '[faktorak_invoice_button]' ); ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="wcup-vo-totals">

            <div class="wcup-vo-total-row">
                <span class="wcup-vo-total-label">جمع جزء:</span>
                <span class="wcup-vo-total-value">
                    <?php echo wp_kses_post( wc_price( $order->get_subtotal(), array( 'currency' => $order_currency ) ) ); ?>
                </span>
            </div>

            <?php if ( $payment_method ) : ?>
                <div class="wcup-vo-total-row">
                    <span class="wcup-vo-total-label">روش پرداخت:</span>
                    <span class="wcup-vo-total-value wcup-vo-total-value--bold">
                        <?php echo esc_html( $payment_method ); ?>
                    </span>
                </div>
            <?php endif; ?>

            <div class="wcup-vo-total-row wcup-vo-total-row--final">
                <span class="wcup-vo-total-label">قیمت نهایی:</span>
                <span class="wcup-vo-total-value wcup-vo-total-value--final">
                    <?php echo wp_kses_post( $order->get_formatted_order_total() ); ?>
                </span>
            </div>

        </div>

    </div>

    <!-- ═══ سفارش دوباره ═══ -->
    <?php if ( $order->has_status( array( 'completed', 'processing' ) ) && $order->get_items() ) : ?>
        <?php
        $reorder_url = wp_nonce_url(
            add_query_arg(
                array(
                    'order_again' => $order->get_id(),
                    'order_id'    => $order->get_id(),
                ),
                wc_get_cart_url()
            ),
            'woocommerce-order_again'
        );
        ?>
        <div class="wcup-vo-actions">
            <a href="<?php echo esc_url( $reorder_url ); ?>" class="wcup-vo-btn-reorder">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5"
                     stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="23 4 23 10 17 10"></polyline>
                    <polyline points="1 20 1 14 7 14"></polyline>
                    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                </svg>
                <span>سفارش دوباره</span>
            </a>
        </div>
    <?php endif; ?>

</div>

<script>
(function () {
    document.querySelectorAll('.wcup-vo-downloads-toggle').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var panelId = btn.getAttribute('aria-controls');
            var panel   = document.getElementById(panelId);
            if (!panel) return;

            var isOpen = !panel.hidden;
            panel.hidden = isOpen;
            btn.setAttribute('aria-expanded', isOpen ? 'false' : 'true');
            btn.classList.toggle('is-open', !isOpen);
        });
    });
})();
</script>