<?php
/**
 * My Account > Reset Password (Custom Override)
 * ----------------------------------------------------------
 *  ساختار:
 *    - کارت تعیین رمز عبور جدید
 *    - فیلد رمز جدید + تکرار آن
 *    - دکمهٔ ذخیره رمز
 *    - لینک بازگشت به ورود
 *
 * @version 3.0.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_reset_password_form' );
?>

<div class="wcup-reset-pass" dir="rtl">

    <?php wc_print_notices(); ?>

    <div class="wcup-rp-card">

        <!-- ═══ Icon ═══ -->
        <div class="wcup-rp-icon" aria-hidden="true">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2"
                 stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path>
            </svg>
        </div>

        <!-- ═══ Head ═══ -->
        <div class="wcup-rp-head">
            <h2 class="wcup-rp-title">تعیین رمز عبور جدید</h2>
            <p class="wcup-rp-sub">
                یک رمز عبور قوی انتخاب کن. بعد از ذخیره، می‌تونی با رمز جدید وارد حسابت بشی.
            </p>
        </div>

        <!-- ═══ Form ═══ -->
        <form method="post"
              class="woocommerce-ResetPassword lost_reset_password wcup-rp-form">

            <div class="wcup-rp-field">
                <label for="password_1" class="wcup-rp-label">
                    رمز عبور جدید <span class="wcup-rp-required">*</span>
                </label>
                <div class="wcup-rp-input-wrap">
                    <span class="wcup-rp-input-icon" aria-hidden="true">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.2"
                             stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                        </svg>
                    </span>
                    <input type="password"
                           class="wcup-rp-input woocommerce-Input woocommerce-Input--text input-text"
                           name="password_1"
                           id="password_1"
                           autocomplete="new-password"
                           placeholder="رمز عبور جدید خود را وارد کنید">
                    <button type="button"
                            class="wcup-rp-toggle-pass"
                            aria-label="نمایش رمز عبور"
                            data-target="password_1">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.2"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                    </button>
                </div>
            </div>

            <div class="wcup-rp-field">
                <label for="password_2" class="wcup-rp-label">
                    تکرار رمز عبور جدید <span class="wcup-rp-required">*</span>
                </label>
                <div class="wcup-rp-input-wrap">
                    <span class="wcup-rp-input-icon" aria-hidden="true">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.2"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path d="M9 12l2 2 4-4"></path>
                            <path d="M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9c1.51 0 2.93.37 4.18 1.02"></path>
                        </svg>
                    </span>
                    <input type="password"
                           class="wcup-rp-input woocommerce-Input woocommerce-Input--text input-text"
                           name="password_2"
                           id="password_2"
                           autocomplete="new-password"
                           placeholder="رمز عبور جدید را دوباره وارد کنید">
                    <button type="button"
                            class="wcup-rp-toggle-pass"
                            aria-label="نمایش رمز عبور"
                            data-target="password_2">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="2.2"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                    </button>
                </div>
            </div>

            <!-- ★ نشانگر قدرت رمز -->
            <div class="wcup-rp-strength" id="wcup-rp-strength" data-score="0">
                <div class="wcup-rp-strength-bars">
                    <span class="wcup-rp-strength-bar"></span>
                    <span class="wcup-rp-strength-bar"></span>
                    <span class="wcup-rp-strength-bar"></span>
                    <span class="wcup-rp-strength-bar"></span>
                </div>
                <div class="wcup-rp-strength-label" id="wcup-rp-strength-label">
                    قدرت رمز عبور
                </div>
            </div>

            <div class="wcup-rp-hint">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.2"
                     stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="16" x2="12" y2="12"></line>
                    <line x1="12" y1="8" x2="12.01" y2="8"></line>
                </svg>
                <span>پیشنهاد: حداقل ۸ کاراکتر، ترکیبی از حروف بزرگ و کوچک، عدد و علامت.</span>
            </div>

            <input type="hidden" name="reset_key" value="<?php echo esc_attr( $reset_key ); ?>" />
            <input type="hidden" name="reset_login" value="<?php echo esc_attr( $reset_login ); ?>" />

            <?php do_action( 'woocommerce_resetpassword_form' ); ?>

            <input type="hidden" name="wc_reset_password" value="true" />

            <?php wp_nonce_field( 'reset_password', 'woocommerce-reset-password-nonce' ); ?>

            <button type="submit"
                    class="wcup-rp-submit"
                    value="<?php esc_attr_e( 'Save', 'woocommerce' ); ?>">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                    <polyline points="17 21 17 13 7 13 7 21"></polyline>
                    <polyline points="7 3 7 8 15 8"></polyline>
                </svg>
                <span>ذخیره رمز عبور جدید</span>
            </button>

        </form>

        <!-- ═══ Footer ═══ -->
        <div class="wcup-rp-footer">
            <a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>"
               class="wcup-rp-back">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5"
                     stroke-linecap="round" stroke-linejoin="round">
                    <line x1="19" y1="12" x2="5" y2="12"></line>
                    <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                <span>بازگشت به صفحه ورود</span>
            </a>
        </div>

    </div>

</div>


<script>
/* ═══ نمایش/مخفی رمز ═══ */
(function () {
    document.querySelectorAll('.wcup-rp-toggle-pass').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var inputId = btn.getAttribute('data-target');
            var input   = document.getElementById(inputId);
            if (!input) return;

            var isPass = input.type === 'password';
            input.type = isPass ? 'text' : 'password';
            btn.classList.toggle('is-visible', isPass);
        });
    });
})();

/* ═══ نشانگر قدرت رمز ═══ */
(function () {
    var input  = document.getElementById('password_1');
    var meter  = document.getElementById('wcup-rp-strength');
    var label  = document.getElementById('wcup-rp-strength-label');
    var bars   = meter ? meter.querySelectorAll('.wcup-rp-strength-bar') : [];

    if (!input || !meter) return;

    var labels = ['خیلی ضعیف', 'ضعیف', 'متوسط', 'قوی', 'خیلی قوی'];
    var colors = ['#F34747', '#F34747', '#FBE83F', '#008869', '#008869'];

    function scorePassword(pass) {
        var score = 0;
        if (!pass) return 0;

        // طول
        if (pass.length >= 8)  score++;
        if (pass.length >= 12) score++;

        // تنوع کاراکتر
        if (/[a-z]/.test(pass) && /[A-Z]/.test(pass)) score++;
        if (/\d/.test(pass))                          score++;
        if (/[^A-Za-z0-9]/.test(pass))                score++;

        return Math.min(score, 5);
    }

    input.addEventListener('input', function () {
        var val   = input.value;
        var score = val ? Math.max(1, scorePassword(val)) : 0;

        meter.setAttribute('data-score', score);
        bars.forEach(function (bar, i) {
            bar.style.background = (i < score) ? colors[score - 1] : '#eef1f4';
        });

        if (label) {
            label.textContent = val ? labels[score - 1] : 'قدرت رمز عبور';
            label.style.color = val ? colors[score - 1] : '';
        }
    });
})();
</script>

<?php do_action( 'woocommerce_after_reset_password_form' ); ?>