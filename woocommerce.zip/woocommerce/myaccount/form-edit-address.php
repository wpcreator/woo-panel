<?php
/**
 * My Account > Edit Address (Custom Override)
 * ----------------------------------------------------------
 *  فرم ویرایش/افزودن آدرس صورتحساب یا ارسال
 *
 * @version 3.0.0
 */

defined( 'ABSPATH' ) || exit;

/* ★ نوع آدرس (billing یا shipping) */
$load_address = $load_address ?? 'billing';
$page_title   = ( 'billing' === $load_address ) ? 'آدرس صورتحساب' : 'آدرس ارسال';

$icon = ( 'billing' === $load_address )
    ? '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>'
    : '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>';

$back_url = wc_get_endpoint_url( 'edit-address', '', wc_get_page_permalink( 'myaccount' ) );

do_action( 'woocommerce_before_edit_address_form' );
?>

<div class="wcup-edit-addr" dir="rtl">

    <?php wc_print_notices(); ?>

    <!-- ═══ Header ═══ -->
    <div class="wcup-ead-header">
        <div class="wcup-ead-header-icon" aria-hidden="true">
            <?php echo $icon; // phpcs:ignore ?>
        </div>
        <div class="wcup-ead-header-body">
            <h2 class="wcup-ead-title"><?php echo esc_html( $page_title ); ?></h2>
            <p class="wcup-ead-sub">
                اطلاعات این آدرس رو کامل کن. فیلدهای ستاره‌دار الزامی هستن.
            </p>
        </div>
    </div>

    <!-- ═══ Form ═══ -->
    <form method="post"
          class="woocommerce-address-fields wcup-ead-form"
          novalidate>

        <?php do_action( "woocommerce_before_edit_address_form_{$load_address}" ); ?>

        <div class="wcup-ead-fields">

            <?php
            foreach ( $address as $key => $field ) :

                /* ★ کلاس دلخواه اضافه کن */
                $field['class'] = isset( $field['class'] ) ? (array) $field['class'] : array();
                $field['class'][] = 'wcup-ead-field';

                /* ★ برچسب فارسی (اختیاری) */
                $field['label'] = isset( $field['label'] ) ? $field['label'] : '';

                /* ★ placeholder رو از label بردار */
                if ( empty( $field['placeholder'] ) && ! empty( $field['label'] ) ) {
                    $field['placeholder'] = $field['label'];
                }

                woocommerce_form_field( $key, $field, wc_get_post_data_by_key( $key, $field['value'] ?? '' ) );

            endforeach;
            ?>
        </div>

        <?php do_action( "woocommerce_after_edit_address_form_{$load_address}" ); ?>

        <!-- ═══ Actions ═══ -->
        <div class="wcup-ead-actions">

            <button type="submit"
                    class="wcup-ead-submit"
                    name="save_address"
                    value="<?php esc_attr_e( 'Save address', 'woocommerce' ); ?>">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5"
                     stroke-linecap="round" stroke-linejoin="round">
                    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                    <polyline points="17 21 17 13 7 13 7 21"></polyline>
                    <polyline points="7 3 7 8 15 8"></polyline>
                </svg>
                <span>ذخیره آدرس</span>
            </button>

            <a href="<?php echo esc_url( $back_url ); ?>" class="wcup-ead-cancel">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2.5"
                     stroke-linecap="round" stroke-linejoin="round">
                    <line x1="19" y1="12" x2="5" y2="12"></line>
                    <polyline points="12 19 5 12 12 5"></polyline>
                </svg>
                <span>بازگشت</span>
            </a>

        </div>

        <?php wp_nonce_field( 'woocommerce-edit_address', 'woocommerce-edit-address-nonce' ); ?>
        <input type="hidden" name="action" value="edit_address" />
    </form>

</div>

<?php do_action( 'woocommerce_after_edit_address_form' ); ?>