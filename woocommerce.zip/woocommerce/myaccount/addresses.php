<?php
/**
 * My Account > Addresses (Multiple)
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

$user_id = get_current_user_id();

if ( ! $user_id || ! class_exists( 'wcup_addresses' ) ) {
    return;
}

$addresses = wcup_addresses::get_all( $user_id );
$max       = (int) wcup_settings::get( 'addresses_max', 10 );
$count     = count( $addresses );

/* کشورها */
$countries = WC()->countries->get_countries();
$ir_only   = true; /* فقط ایران */
if ( $ir_only ) {
    $countries = array( 'IR' => $countries['IR'] ?? 'ایران' );
}

/* استان‌های ایران */
$states_ir = WC()->countries->get_states( 'IR' );
if ( ! is_array( $states_ir ) ) {
    $states_ir = array();
}
?>

<div class="wcup-addresses-page" dir="rtl">

    <!-- ═══ Header ═══ -->
    <div class="wcup-ad-header">
        <div class="wcup-ad-header-icon">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                <circle cx="12" cy="10" r="3"></circle>
            </svg>
        </div>
        <div class="wcup-ad-header-body">
            <h2 class="wcup-ad-title">آدرس‌های من</h2>
            <p class="wcup-ad-sub">
                <?php if ( $count > 0 ) : ?>
                    <strong><?php echo esc_html( wcup_helpers::fa_num( $count ) ); ?></strong>
                    از <?php echo esc_html( wcup_helpers::fa_num( $max ) ); ?> آدرس
                <?php else : ?>
                    هنوز آدرسی ثبت نکردی
                <?php endif; ?>
            </p>
        </div>
        <?php if ( $count < $max ) : ?>
            <button type="button" class="wcup-ad-btn-add" id="wcup-ad-add">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                <span>افزودن آدرس</span>
            </button>
        <?php endif; ?>
    </div>

    <?php if ( empty( $addresses ) ) : ?>

        <!-- ═══ Empty ═══ -->
        <div class="wcup-ad-empty">
            <div class="wcup-ad-empty-icon">📍</div>
            <div class="wcup-ad-empty-title">هنوز آدرسی ثبت نکردی</div>
            <div class="wcup-ad-empty-desc">
                اولین آدرس رو اضافه کن تا توی تسویه‌حساب سریع‌تر باشی.
            </div>
            <button type="button" class="wcup-ad-empty-btn" id="wcup-ad-add-first">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                <span>افزودن اولین آدرس</span>
            </button>
        </div>

    <?php else : ?>

        <!-- ═══ Grid ═══ -->
        <div class="wcup-ad-grid">
            <?php foreach ( $addresses as $addr ) :

                $is_def_bill = ! empty( $addr['is_default_billing'] );
                $is_def_ship = ! empty( $addr['is_default_shipping'] );

                $state_label = '';
                if ( ! empty( $addr['state'] ) && isset( $states_ir[ $addr['state'] ] ) ) {
                    $state_label = $states_ir[ $addr['state'] ];
                } elseif ( ! empty( $addr['state'] ) ) {
                    $state_label = $addr['state'];
                }

                $country_label = isset( $countries[ $addr['country'] ] ) ? $countries[ $addr['country'] ] : $addr['country'];
            ?>
                <div class="wcup-ad-card <?php echo ( $is_def_bill || $is_def_ship ) ? 'is-default' : ''; ?>"
                     data-address-id="<?php echo esc_attr( $addr['id'] ); ?>">

                    <!-- Head -->
                    <div class="wcup-ad-card-head">
                        <div class="wcup-ad-card-label">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                <circle cx="12" cy="10" r="3"></circle>
                            </svg>
                            <span><?php echo esc_html( $addr['label'] ); ?></span>
                        </div>

                        <div class="wcup-ad-card-badges">
                            <?php if ( $is_def_bill ) : ?>
                                <span class="wcup-ad-badge wcup-ad-badge--billing">پیش‌فرض صورتحساب</span>
                            <?php endif; ?>
                            <?php if ( $is_def_ship ) : ?>
                                <span class="wcup-ad-badge wcup-ad-badge--shipping">پیش‌فرض ارسال</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Body -->
                    <div class="wcup-ad-card-body">
                        <div class="wcup-ad-card-name">
                            <?php echo esc_html( $addr['first_name'] . ' ' . $addr['last_name'] ); ?>
                        </div>

                        <?php if ( ! empty( $addr['company'] ) ) : ?>
                            <div class="wcup-ad-card-company">
                                🏢 <?php echo esc_html( $addr['company'] ); ?>
                            </div>
                        <?php endif; ?>

                        <div class="wcup-ad-card-address">
                            <?php
                            $parts = array_filter( array(
                                $addr['address_1'],
                                $addr['address_2'],
                                $addr['city'],
                                $state_label,
                                $country_label,
                            ) );
                            echo esc_html( implode( '، ', $parts ) );
                            ?>
                            <?php if ( ! empty( $addr['postcode'] ) ) : ?>
                                <br>
                                <span class="wcup-ad-card-postcode">
                                    کد پستی: <?php echo esc_html( wcup_helpers::fa_num( $addr['postcode'] ) ); ?>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="wcup-ad-card-contact">
                            <?php if ( ! empty( $addr['phone'] ) ) : ?>
                                <span>📞 <?php echo esc_html( wcup_helpers::fa_num( $addr['phone'] ) ); ?></span>
                            <?php endif; ?>
                            <?php if ( ! empty( $addr['email'] ) ) : ?>
                                <span>✉️ <?php echo esc_html( $addr['email'] ); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Foot -->
                    <div class="wcup-ad-card-foot">
                        <button type="button"
                                class="wcup-ad-card-btn wcup-ad-card-btn--edit"
                                data-address-id="<?php echo esc_attr( $addr['id'] ); ?>">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                            <span>ویرایش</span>
                        </button>

                        <button type="button"
                                class="wcup-ad-card-btn wcup-ad-card-btn--delete"
                                data-address-id="<?php echo esc_attr( $addr['id'] ); ?>">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="3 6 5 6 21 6"></polyline>
                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                            </svg>
                            <span>حذف</span>
                        </button>
                    </div>

                    <!-- Default Buttons -->
                    <?php if ( ! $is_def_bill || ! $is_def_ship ) : ?>
                        <div class="wcup-ad-card-defaults">
                            <?php if ( ! $is_def_bill ) : ?>
                                <button type="button"
                                        class="wcup-ad-default-btn wcup-ad-default-btn--billing"
                                        data-address-id="<?php echo esc_attr( $addr['id'] ); ?>"
                                        data-type="billing">
                                    پیش‌فرض صورتحساب
                                </button>
                            <?php endif; ?>
                            <?php if ( ! $is_def_ship ) : ?>
                                <button type="button"
                                        class="wcup-ad-default-btn wcup-ad-default-btn--shipping"
                                        data-address-id="<?php echo esc_attr( $addr['id'] ); ?>"
                                        data-type="shipping">
                                    پیش‌فرض ارسال
                                </button>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                </div>
            <?php endforeach; ?>
        </div>

    <?php endif; ?>

</div>

<!-- ═══════════════════════════════════════════════════════
     Modal: افزودن / ویرایش آدرس
═══════════════════════════════════════════════════════════ -->
<div class="wcup-ad-modal" id="wcup-ad-modal" style="display:none;">
    <div class="wcup-ad-modal-backdrop"></div>
    <div class="wcup-ad-modal-content">

        <div class="wcup-ad-modal-head">
            <h3 class="wcup-ad-modal-title" id="wcup-ad-modal-title">افزودن آدرس جدید</h3>
            <button type="button" class="wcup-ad-modal-close" id="wcup-ad-modal-close">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        </div>

        <form id="wcup-ad-form" class="wcup-ad-form" method="post" onsubmit="return false;">

            <input type="hidden" name="address_id" id="wcup-ad-field-id" value="">

            <!-- Label -->
            <div class="wcup-ad-field">
                <label for="wcup-ad-label" class="wcup-ad-label">نام آدرس (مثلاً خانه، محل کار)</label>
                <input type="text"
                       name="label"
                       id="wcup-ad-label"
                       class="wcup-ad-input"
                       placeholder="خانه"
                       maxlength="50">
            </div>

            <!-- Name Row -->
            <div class="wcup-ad-row">
                <div class="wcup-ad-field">
                    <label for="wcup-ad-first-name" class="wcup-ad-label">
                        نام <span class="wcup-ad-required">*</span>
                    </label>
                    <input type="text"
                           name="first_name"
                           id="wcup-ad-first-name"
                           class="wcup-ad-input"
                           required>
                </div>
                <div class="wcup-ad-field">
                    <label for="wcup-ad-last-name" class="wcup-ad-label">
                        نام خانوادگی <span class="wcup-ad-required">*</span>
                    </label>
                    <input type="text"
                           name="last_name"
                           id="wcup-ad-last-name"
                           class="wcup-ad-input"
                           required>
                </div>
            </div>

            <!-- Phone + Email -->
            <div class="wcup-ad-row">
                <div class="wcup-ad-field">
                    <label for="wcup-ad-phone" class="wcup-ad-label">
                        شماره موبایل <span class="wcup-ad-required">*</span>
                    </label>
                    <input type="tel"
                           name="phone"
                           id="wcup-ad-phone"
                           class="wcup-ad-input"
                           placeholder="09123456789"
                           required>
                </div>
                <div class="wcup-ad-field">
                    <label for="wcup-ad-email" class="wcup-ad-label">ایمیل (اختیاری)</label>
                    <input type="email"
                           name="email"
                           id="wcup-ad-email"
                           class="wcup-ad-input"
                           placeholder="example@email.com">
                </div>
            </div>

            <!-- Company -->
            <div class="wcup-ad-field">
                <label for="wcup-ad-company" class="wcup-ad-label">شرکت (اختیاری)</label>
                <input type="text"
                       name="company"
                       id="wcup-ad-company"
                       class="wcup-ad-input">
            </div>

            <!-- Country + State -->
            <div class="wcup-ad-row">
                <div class="wcup-ad-field">
                    <label for="wcup-ad-country" class="wcup-ad-label">
                        کشور <span class="wcup-ad-required">*</span>
                    </label>
                    <select name="country" id="wcup-ad-country" class="wcup-ad-input" required>
                        <?php foreach ( $countries as $code => $name ) : ?>
                            <option value="<?php echo esc_attr( $code ); ?>" <?php selected( $code, 'IR' ); ?>>
                                <?php echo esc_html( $name ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="wcup-ad-field">
                    <label for="wcup-ad-state" class="wcup-ad-label">
                        استان <span class="wcup-ad-required">*</span>
                    </label>
                    <select name="state" id="wcup-ad-state" class="wcup-ad-input" required>
                        <option value="">— انتخاب کنید —</option>
                        <?php foreach ( $states_ir as $code => $name ) : ?>
                            <option value="<?php echo esc_attr( $code ); ?>"><?php echo esc_html( $name ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <!-- City + Postcode -->
            <div class="wcup-ad-row">
                <div class="wcup-ad-field">
                    <label for="wcup-ad-city" class="wcup-ad-label">
                        شهر <span class="wcup-ad-required">*</span>
                    </label>
                    <input type="text"
                           name="city"
                           id="wcup-ad-city"
                           class="wcup-ad-input"
                           required>
                </div>
                <div class="wcup-ad-field">
                    <label for="wcup-ad-postcode" class="wcup-ad-label">کد پستی (۱۰ رقم)</label>
                    <input type="text"
                           name="postcode"
                           id="wcup-ad-postcode"
                           class="wcup-ad-input"
                           placeholder="1234567890"
                           maxlength="10"
                           inputmode="numeric"
                           pattern="[0-9]{10}">
                </div>
            </div>

            <!-- Address 1 -->
            <div class="wcup-ad-field">
                <label for="wcup-ad-address-1" class="wcup-ad-label">
                    آدرس <span class="wcup-ad-required">*</span>
                </label>
                <textarea name="address_1"
                          id="wcup-ad-address-1"
                          class="wcup-ad-input"
                          rows="2"
                          required></textarea>
            </div>

            <!-- Address 2 -->
            <div class="wcup-ad-field">
                <label for="wcup-ad-address-2" class="wcup-ad-label">آدرس تکمیلی (اختیاری)</label>
                <input type="text"
                       name="address_2"
                       id="wcup-ad-address-2"
                       class="wcup-ad-input"
                       placeholder="واحد، پلاک، طبقه">
            </div>

            <!-- Defaults -->
            <div class="wcup-ad-defaults-form">
                <label class="wcup-ad-check">
                    <input type="checkbox" name="is_default_billing" value="1" id="wcup-ad-def-bill">
                    <span>آدرس پیش‌فرض صورتحساب</span>
                </label>
                <label class="wcup-ad-check">
                    <input type="checkbox" name="is_default_shipping" value="1" id="wcup-ad-def-ship">
                    <span>آدرس پیش‌فرض ارسال</span>
                </label>
            </div>

            <!-- Actions -->
            <div class="wcup-ad-form-actions">
                <button type="submit" class="wcup-ad-submit" id="wcup-ad-submit">
                    <span>ذخیرهٔ آدرس</span>
                </button>
                <button type="button" class="wcup-ad-cancel" id="wcup-ad-cancel">
                    <span>انصراف</span>
                </button>
            </div>

        </form>

    </div>
	<!-- ═══════════════════════════════════════════════════════
     داده‌های آدرس‌ها برای JS (ویرایش)
═══════════════════════════════════════════════════════════ -->
<script>
window.wcupAddressesList = <?php echo wp_json_encode( array_values( $addresses ) ); ?>;
</script>
</div>