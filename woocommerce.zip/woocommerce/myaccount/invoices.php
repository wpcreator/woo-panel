<?php
/**
 * My Account > Invoices — آرشیو فاکتورها
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

$user_id = get_current_user_id();

if ( ! $user_id || ! class_exists( 'wcup_invoice' ) ) {
    return;
}

$invoice = wcup_invoice::instance();

/* صفحه‌بندی */
$current_page = max( 1, get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1 );
$per_page     = 15;
$offset       = ( $current_page - 1 ) * $per_page;

/* جستجو */
$search = isset( $_GET['search'] ) ? sanitize_text_field( $_GET['search'] ) : '';

/* گرفتن سفارشات قابل فاکتور */
$args = array(
    'customer' => $user_id,
    'limit'    => $per_page,
    'page'     => $current_page,
    'paginate' => true,
    'orderby'  => 'date',
    'order'    => 'DESC',
    'status'   => array( 'processing', 'completed' ),
);

$customer_orders = wc_get_orders( $args );
$orders          = $customer_orders->orders;
$total           = (int) $customer_orders->total;
$max_pages       = (int) $customer_orders->max_num_pages;

/* فیلتر جستجو */
if ( $search !== '' ) {
    $orders = array_filter( $orders, function( $order ) use ( $search, $invoice ) {
        if ( ! $order instanceof WC_Order ) return false;
        $inv_no = $order->get_meta( '_wcup_invoice_number' );
        $ord_no = $order->get_order_number();
        return (
            stripos( $inv_no, $search ) !== false ||
            stripos( $ord_no, $search ) !== false
        );
    } );
    $orders = array_values( $orders );
}

$base_url = wc_get_endpoint_url( 'invoices', '', wc_get_page_permalink( 'myaccount' ) );
?>

<div class="wcup-invoices-page" dir="rtl">

    <!-- ═══ Header ═══ -->
    <div class="wcup-inv-page-header">
        <div class="wcup-inv-page-header-icon">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14 2 14 8 20 8"></polyline>
                <line x1="16" y1="13" x2="8" y2="13"></line>
                <line x1="16" y1="17" x2="8" y2="17"></line>
            </svg>
        </div>
        <div class="wcup-inv-page-header-body">
            <h2 class="wcup-inv-page-title">فاکتورهای من</h2>
            <p class="wcup-inv-page-sub">
                <?php if ( $total > 0 ) : ?>
                    <strong><?php echo esc_html( wcup_fa_num( $total ) ); ?></strong>
                    فاکتور ثبت‌شده
                <?php else : ?>
                    هنوز فاکتوری صادر نشده
                <?php endif; ?>
            </p>
        </div>
    </div>

    <!-- ═══ Search ═══ -->
    <?php if ( $total > 0 ) : ?>
        <form method="get" action="<?php echo esc_url( $base_url ); ?>" class="wcup-inv-page-search">
            <div class="wcup-inv-page-search-wrap">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="wcup-inv-page-search-icon">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
                <input type="text"
                       name="search"
                       value="<?php echo esc_attr( $search ); ?>"
                       placeholder="جستجو با شمارهٔ فاکتور یا سفارش..."
                       class="wcup-inv-page-search-input"
                       autocomplete="off">
                <button type="submit" class="wcup-inv-page-search-btn">جستجو</button>
            </div>
            <?php if ( $search !== '' ) : ?>
                <a href="<?php echo esc_url( $base_url ); ?>" class="wcup-inv-page-search-clear">
                    ✕ پاک کردن
                </a>
            <?php endif; ?>
        </form>
    <?php endif; ?>

    <!-- ═══ List ═══ -->
    <?php if ( empty( $orders ) ) : ?>

        <div class="wcup-inv-page-empty">
            <div class="wcup-inv-page-empty-icon">🧾</div>
            <div class="wcup-inv-page-empty-title">
                <?php echo $search !== '' ? 'فاکتوری پیدا نشد' : 'هنوز فاکتوری نداری'; ?>
            </div>
            <div class="wcup-inv-page-empty-desc">
                <?php if ( $search !== '' ) : ?>
                    با این معیار جستجو، فاکتوری پیدا نشد.
                <?php else : ?>
                    وقتی سفارش شما به مرحلهٔ «در حال انجام» برسه، فاکتور صادر می‌شه.
                <?php endif; ?>
            </div>
            <?php if ( $search === '' ) : ?>
                <a href="<?php echo esc_url( wc_get_endpoint_url( 'orders', '', wc_get_page_permalink( 'myaccount' ) ) ); ?>"
                   class="wcup-inv-page-empty-btn">
                    📦 مشاهدهٔ سفارشات
                </a>
            <?php endif; ?>
        </div>

    <?php else : ?>

        <div class="wcup-inv-page-list">
            <?php foreach ( $orders as $order ) :

                if ( ! $order instanceof WC_Order ) continue;

                $invoice_no = $order->get_meta( '_wcup_invoice_number' );
                $invoice_dt = $order->get_meta( '_wcup_invoice_date' );

                if ( ! $invoice_no ) {
                    $invoice_no = $invoice->get_invoice_number( $order );
                }

                $order_date = $order->get_date_created();
                $date_str   = $invoice_dt
                    ? date_i18n( 'j F Y', strtotime( $invoice_dt ) )
                    : ( $order_date ? date_i18n( 'j F Y', $order_date->getTimestamp() ) : '—' );

                $invoice_url = $invoice->get_invoice_url( $order );
                $print_url   = add_query_arg( 'print', '1', $invoice_url );
                $total_fa    = $order->get_formatted_order_total();
            ?>

                <div class="wcup-inv-page-card">

                    <div class="wcup-inv-page-card-icon">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                        </svg>
                    </div>

                    <div class="wcup-inv-page-card-body">
                        <div class="wcup-inv-page-card-head">
                            <div class="wcup-inv-page-card-number">
                                <?php echo esc_html( $invoice_no ); ?>
                            </div>
                            <span class="wcup-inv-page-card-badge">
                                سفارش #<?php echo esc_html( wcup_fa_num( $order->get_order_number() ) ); ?>
                            </span>
                        </div>
                        <div class="wcup-inv-page-card-meta">
                            <span>📅 <?php echo esc_html( wcup_fa_num( $date_str ) ); ?></span>
                            <span class="wcup-inv-page-card-dot">●</span>
                            <span>💰 <?php echo wp_kses_post( $total_fa ); ?></span>
                        </div>
                    </div>

                    <div class="wcup-inv-page-card-actions">
                        <a href="<?php echo esc_url( $invoice_url ); ?>"
                           target="_blank"
                           rel="noopener"
                           class="wcup-inv-page-card-btn wcup-inv-page-card-btn--primary">
                            👁️ مشاهده
                        </a>
                        <a href="<?php echo esc_url( $print_url ); ?>"
                           target="_blank"
                           rel="noopener"
                           class="wcup-inv-page-card-btn">
                            🖨️ چاپ
                        </a>
                    </div>

                </div>

            <?php endforeach; ?>
        </div>

        <!-- Pagination -->
        <?php if ( $max_pages > 1 ) : ?>
            <div class="wcup-inv-page-pagination">
                <?php for ( $i = 1; $i <= $max_pages; $i++ ) :
                    $page_url = ( $i === 1 ) ? $base_url : add_query_arg( 'paged', $i, $base_url );
                    if ( $search !== '' ) {
                        $page_url = add_query_arg( 'search', $search, $page_url );
                    }
                    $is_cur = ( $i === $current_page );
                ?>
                    <a href="<?php echo esc_url( $page_url ); ?>"
                       class="wcup-inv-page-num <?php echo $is_cur ? 'is-active' : ''; ?>">
                        <?php echo esc_html( wcup_fa_num( $i ) ); ?>
                    </a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>

    <?php endif; ?>

</div>